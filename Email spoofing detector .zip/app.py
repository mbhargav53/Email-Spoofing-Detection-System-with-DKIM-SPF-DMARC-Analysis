#!/usr/bin/env python3
"""
Email Spoofing Detection System - Web Application
Flask backend with REST API endpoints
"""

import os
import json
import uuid
from datetime import datetime
from flask import Flask, request, jsonify, render_template, send_from_directory
from flask_cors import CORS
from werkzeug.utils import secure_filename
import tempfile

# Import our analysis modules
from src.dns_analyzer import DNSAnalyzer
from src.email_parser import EmailParser
from src.spf_validator import SPFValidator
from src.dkim_verifier import DKIMVerifier
from src.dmarc_analyzer import DMARCAnalyzer
from src.reporter import ReportGenerator

app = Flask(__name__)
CORS(app)

# Configuration
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16MB max file size
app.config['UPLOAD_FOLDER'] = 'uploads'
app.config['SECRET_KEY'] = 'your-secret-key-here'

# Allowed file extensions
ALLOWED_EXTENSIONS = {'eml', 'txt', 'msg'}

# Create upload directory
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

def allowed_file(filename):
    """Check if file extension is allowed"""
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def analyze_domain(domain):
    """Analyze domain for email authentication"""
    try:
        # Initialize components
        dns_analyzer = DNSAnalyzer()
        spf_validator = SPFValidator()
        dkim_verifier = DKIMVerifier()
        dmarc_analyzer = DMARCAnalyzer()
        
        # Get DNS records
        dns_records = dns_analyzer.get_all_records(domain)
        
        # Validate SPF
        spf_result = spf_validator.validate(domain, dns_records.get('spf'))
        
        # Verify DKIM
        dkim_result = dkim_verifier.verify(domain, dns_records.get('dkim'))
        
        # Analyze DMARC
        dmarc_result = dmarc_analyzer.analyze(domain, dns_records.get('dmarc'), spf_result, dkim_result)
        
        return {
            'success': True,
            'domain': domain,
            'dns_records': dns_records,
            'spf': spf_result,
            'dkim': dkim_result,
            'dmarc': dmarc_result,
            'timestamp': datetime.now().isoformat()
        }
    except Exception as e:
        return {
            'success': False,
            'error': str(e),
            'timestamp': datetime.now().isoformat()
        }

def analyze_email(file_path):
    """Analyze email file for spoofing indicators"""
    try:
        # Parse email
        email_parser = EmailParser()
        email_data = email_parser.parse_email_file(file_path)
        
        if not email_data:
            return {
                'success': False,
                'error': 'Could not parse email file',
                'timestamp': datetime.now().isoformat()
            }
        
        # Extract domain
        domain = email_data.get('from_domain')
        if not domain:
            return {
                'success': False,
                'error': 'Could not extract domain from email',
                'timestamp': datetime.now().isoformat()
            }
        
        # Analyze domain
        domain_analysis = analyze_domain(domain)
        
        if not domain_analysis['success']:
            return domain_analysis
        
        # Add email data to results
        domain_analysis['email_data'] = email_data
        
        return domain_analysis
        
    except Exception as e:
        return {
            'success': False,
            'error': str(e),
            'timestamp': datetime.now().isoformat()
        }

@app.route('/')
def index():
    """Serve the main dashboard"""
    return render_template('index.html')

@app.route('/api/analyze/domain', methods=['POST'])
def api_analyze_domain():
    """API endpoint for domain analysis"""
    try:
        data = request.get_json()
        domain = data.get('domain')
        
        if not domain:
            return jsonify({
                'success': False,
                'error': 'Domain is required'
            }), 400
        
        result = analyze_domain(domain)
        return jsonify(result)
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@app.route('/api/analyze/email', methods=['POST'])
def api_analyze_email():
    """API endpoint for email analysis"""
    try:
        if 'file' not in request.files:
            return jsonify({
                'success': False,
                'error': 'No file uploaded'
            }), 400
        
        file = request.files['file']
        
        if file.filename == '':
            return jsonify({
                'success': False,
                'error': 'No file selected'
            }), 400
        
        if file and allowed_file(file.filename):
            # Save uploaded file
            filename = secure_filename(file.filename)
            unique_filename = f"{uuid.uuid4()}_{filename}"
            file_path = os.path.join(app.config['UPLOAD_FOLDER'], unique_filename)
            file.save(file_path)
            
            try:
                # Analyze email
                result = analyze_email(file_path)
                return jsonify(result)
            finally:
                # Clean up uploaded file
                if os.path.exists(file_path):
                    os.remove(file_path)
        else:
            return jsonify({
                'success': False,
                'error': 'Invalid file type. Allowed: .eml, .txt, .msg'
            }), 400
            
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@app.route('/api/generate-report', methods=['POST'])
def api_generate_report():
    """API endpoint for generating detailed reports"""
    try:
        data = request.get_json()
        analysis_data = data.get('analysis_data')
        
        if not analysis_data:
            return jsonify({
                'success': False,
                'error': 'Analysis data is required'
            }), 400
        
        # Generate report
        reporter = ReportGenerator()
        report = reporter.generate_report(analysis_data)
        
        return jsonify({
            'success': True,
            'report': report,
            'timestamp': datetime.now().isoformat()
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@app.route('/api/health')
def api_health():
    """Health check endpoint"""
    return jsonify({
        'status': 'healthy',
        'timestamp': datetime.now().isoformat()
    })

@app.errorhandler(413)
def too_large(e):
    """Handle file too large error"""
    return jsonify({
        'success': False,
        'error': 'File too large. Maximum size is 16MB.'
    }), 413

@app.errorhandler(404)
def not_found(e):
    """Handle 404 errors"""
    return jsonify({
        'success': False,
        'error': 'Endpoint not found'
    }), 404

@app.errorhandler(500)
def internal_error(e):
    """Handle 500 errors"""
    return jsonify({
        'success': False,
        'error': 'Internal server error'
    }), 500

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=8080)
