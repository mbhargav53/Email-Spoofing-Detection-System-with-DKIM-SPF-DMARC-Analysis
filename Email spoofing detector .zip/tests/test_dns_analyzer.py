"""
Test cases for DNS Analyzer
"""

import unittest
from unittest.mock import patch, MagicMock
from src.dns_analyzer import DNSAnalyzer

class TestDNSAnalyzer(unittest.TestCase):
    def setUp(self):
        self.analyzer = DNSAnalyzer()
    
    @patch('src.dns_analyzer.dns.resolver.Resolver.resolve')
    def test_get_spf_record_success(self, mock_resolve):
        """Test successful SPF record retrieval"""
        mock_answer = MagicMock()
        mock_answer.__str__ = MagicMock(return_value='"v=spf1 include:_spf.google.com ~all"')
        mock_resolve.return_value = [mock_answer]
        
        result = self.analyzer.get_spf_record('example.com')
        
        self.assertEqual(result, 'v=spf1 include:_spf.google.com ~all')
        mock_resolve.assert_called_once_with('example.com', 'TXT')
    
    @patch('src.dns_analyzer.dns.resolver.Resolver.resolve')
    def test_get_spf_record_not_found(self, mock_resolve):
        """Test SPF record not found"""
        mock_resolve.side_effect = Exception("No answer")
        
        result = self.analyzer.get_spf_record('example.com')
        
        self.assertIsNone(result)
    
    @patch('src.dns_analyzer.dns.resolver.Resolver.resolve')
    def test_get_dkim_records_success(self, mock_resolve):
        """Test successful DKIM records retrieval"""
        mock_answer = MagicMock()
        mock_answer.__str__ = MagicMock(return_value='"v=DKIM1; k=rsa; p=MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQC..."')
        mock_resolve.return_value = [mock_answer]
        
        result = self.analyzer.get_dkim_records('example.com')
        
        self.assertIsInstance(result, list)
        if result:  # If any records found
            self.assertIn('selector', result[0])
            self.assertIn('record', result[0])
            self.assertIn('domain', result[0])
    
    @patch('src.dns_analyzer.dns.resolver.Resolver.resolve')
    def test_get_dmarc_record_success(self, mock_resolve):
        """Test successful DMARC record retrieval"""
        mock_answer = MagicMock()
        mock_answer.__str__ = MagicMock(return_value='"v=DMARC1; p=quarantine; rua=mailto:dmarc@example.com"')
        mock_resolve.return_value = [mock_answer]
        
        result = self.analyzer.get_dmarc_record('example.com')
        
        self.assertEqual(result, 'v=DMARC1; p=quarantine; rua=mailto:dmarc@example.com')
        mock_resolve.assert_called_once_with('_dmarc.example.com', 'TXT')

if __name__ == '__main__':
    unittest.main()
