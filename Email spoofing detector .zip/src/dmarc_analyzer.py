"""
DMARC Analyzer
Handles DMARC policy analysis and evaluation
"""

import re
from typing import Dict, List, Optional
from datetime import datetime, timedelta

class DMARCAnalyzer:
    def __init__(self):
        self.supported_policies = ['none', 'quarantine', 'reject']
        self.supported_alignment = ['r', 's']
        self.supported_formats = ['afrf', 'iodef']
    
    def analyze(self, domain: str, dmarc_record: Optional[str], spf_result: Dict = None, dkim_result: Dict = None) -> Dict:
        """Analyze DMARC record and return evaluation results"""
        result = {
            'valid': False,
            'record': dmarc_record,
            'policy': {},
            'alignment': {},
            'reporting': {},
            'errors': [],
            'warnings': [],
            'recommendations': [],
            'score': 0,
            'compliance': 'unknown'
        }
        
        if not dmarc_record:
            result['errors'].append("No DMARC record found")
            return result
        
        try:
            # Parse DMARC record
            dmarc_data = self._parse_dmarc_record(dmarc_record)
            result['policy'] = dmarc_data
            
            # Validate DMARC record
            self._validate_dmarc_record(dmarc_data, result)
            
            # Evaluate compliance
            self._evaluate_compliance(dmarc_data, spf_result, dkim_result, result)
            
            # Calculate score
            result['score'] = self._calculate_dmarc_score(result)
            result['valid'] = result['score'] > 0
            
            # Generate recommendations
            self._generate_recommendations(result, domain)
            
        except Exception as e:
            result['errors'].append(f"Error parsing DMARC record: {str(e)}")
        
        return result
    
    def _parse_dmarc_record(self, dmarc_record: str) -> Dict:
        """Parse DMARC record into components"""
        dmarc_data = {
            'version': '',
            'policy': 'none',
            'subdomain_policy': 'none',
            'rua': [],
            'ruf': [],
            'pct': 100,
            'adkim': 'r',
            'aspf': 'r',
            'fo': '0',
            'rf': 'afrf',
            'ri': 86400,
            'rua_aggregate': [],
            'ruf_forensic': []
        }
        
        # Parse DMARC record parameters
        params = re.findall(r'([a-z]+)=([^;]+)', dmarc_record)
        for param, value in params:
            value = value.strip()
            
            if param == 'v':
                dmarc_data['version'] = value
            elif param == 'p':
                dmarc_data['policy'] = value
            elif param == 'sp':
                dmarc_data['subdomain_policy'] = value
            elif param == 'rua':
                dmarc_data['rua'] = [v.strip() for v in value.split(',')]
            elif param == 'ruf':
                dmarc_data['ruf'] = [v.strip() for v in value.split(',')]
            elif param == 'pct':
                try:
                    dmarc_data['pct'] = int(value)
                except ValueError:
                    dmarc_data['pct'] = 100
            elif param == 'adkim':
                dmarc_data['adkim'] = value
            elif param == 'aspf':
                dmarc_data['aspf'] = value
            elif param == 'fo':
                dmarc_data['fo'] = value
            elif param == 'rf':
                dmarc_data['rf'] = value
            elif param == 'ri':
                try:
                    dmarc_data['ri'] = int(value)
                except ValueError:
                    dmarc_data['ri'] = 86400
        
        return dmarc_data
    
    def _validate_dmarc_record(self, dmarc_data: Dict, result: Dict):
        """Validate DMARC record parameters"""
        # Check version
        if dmarc_data['version'] != 'DMARC1':
            result['errors'].append(f"Unsupported DMARC version: {dmarc_data['version']}")
        
        # Check policy
        if dmarc_data['policy'] not in self.supported_policies:
            result['errors'].append(f"Invalid policy: {dmarc_data['policy']}")
        
        # Check subdomain policy
        if dmarc_data['subdomain_policy'] not in self.supported_policies:
            result['errors'].append(f"Invalid subdomain policy: {dmarc_data['subdomain_policy']}")
        
        # Check alignment
        if dmarc_data['adkim'] not in self.supported_alignment:
            result['errors'].append(f"Invalid DKIM alignment: {dmarc_data['adkim']}")
        
        if dmarc_data['aspf'] not in self.supported_alignment:
            result['errors'].append(f"Invalid SPF alignment: {dmarc_data['aspf']}")
        
        # Check percentage
        if not 0 <= dmarc_data['pct'] <= 100:
            result['errors'].append(f"Invalid percentage: {dmarc_data['pct']}")
        
        # Check reporting URIs
        for rua in dmarc_data['rua']:
            if not self._is_valid_uri(rua):
                result['warnings'].append(f"Invalid RUA URI: {rua}")
        
        for ruf in dmarc_data['ruf']:
            if not self._is_valid_uri(ruf):
                result['warnings'].append(f"Invalid RUF URI: {ruf}")
    
    def _is_valid_uri(self, uri: str) -> bool:
        """Check if URI is valid"""
        # Simple URI validation
        return uri.startswith(('mailto:', 'http://', 'https://'))
    
    def _evaluate_compliance(self, dmarc_data: Dict, spf_result: Dict, dkim_result: Dict, result: Dict):
        """Evaluate DMARC compliance based on SPF and DKIM results"""
        compliance = 'unknown'
        
        if not spf_result or not dkim_result:
            result['warnings'].append("Cannot evaluate compliance without SPF and DKIM results")
            return
        
        # Check if SPF and DKIM are aligned
        spf_aligned = self._check_spf_alignment(dmarc_data, spf_result)
        dkim_aligned = self._check_dkim_alignment(dmarc_data, dkim_result)
        
        if spf_aligned or dkim_aligned:
            compliance = 'pass'
        else:
            compliance = 'fail'
        
        result['compliance'] = compliance
        result['alignment'] = {
            'spf': spf_aligned,
            'dkim': dkim_aligned
        }
    
    def _check_spf_alignment(self, dmarc_data: Dict, spf_result: Dict) -> bool:
        """Check SPF alignment"""
        # Simplified SPF alignment check
        # In practice, you'd need to check domain alignment
        return spf_result.get('valid', False)
    
    def _check_dkim_alignment(self, dmarc_data: Dict, dkim_result: Dict) -> bool:
        """Check DKIM alignment"""
        # Simplified DKIM alignment check
        # In practice, you'd need to check domain alignment
        return dkim_result.get('valid', False)
    
    def _calculate_dmarc_score(self, result: Dict) -> int:
        """Calculate overall DMARC score"""
        score = 0
        
        # Base score for having DMARC record
        if result['record']:
            score += 10
        
        # Score based on policy strength
        policy = result['policy'].get('policy', 'none')
        if policy == 'reject':
            score += 20
        elif policy == 'quarantine':
            score += 15
        elif policy == 'none':
            score += 5
        
        # Score for reporting
        if result['policy'].get('rua'):
            score += 5
        
        if result['policy'].get('ruf'):
            score += 5
        
        # Score for alignment settings
        if result['policy'].get('adkim') == 's':
            score += 3
        
        if result['policy'].get('aspf') == 's':
            score += 3
        
        # Deduct points for errors
        score -= len(result.get('errors', [])) * 5
        
        # Deduct points for warnings
        score -= len(result.get('warnings', [])) * 1
        
        return max(0, score)
    
    def _generate_recommendations(self, result: Dict, domain: str):
        """Generate recommendations based on DMARC analysis"""
        recommendations = []
        
        if not result['record']:
            recommendations.append("Add a DMARC record to enable email authentication policy")
            return
        
        policy = result['policy'].get('policy', 'none')
        
        # Policy recommendations
        if policy == 'none':
            recommendations.append("Consider upgrading to 'quarantine' or 'reject' policy")
        elif policy == 'quarantine':
            recommendations.append("Consider upgrading to 'reject' policy for maximum protection")
        
        # Reporting recommendations
        if not result['policy'].get('rua'):
            recommendations.append("Add RUA (aggregate reporting) to monitor DMARC compliance")
        
        if not result['policy'].get('ruf'):
            recommendations.append("Add RUF (forensic reporting) for detailed failure analysis")
        
        # Alignment recommendations
        if result['policy'].get('adkim') == 'r':
            recommendations.append("Consider using strict DKIM alignment (adkim=s)")
        
        if result['policy'].get('aspf') == 'r':
            recommendations.append("Consider using strict SPF alignment (aspf=s)")
        
        # Percentage recommendations
        if result['policy'].get('pct', 100) < 100:
            recommendations.append("Consider increasing policy percentage to 100%")
        
        result['recommendations'] = recommendations
