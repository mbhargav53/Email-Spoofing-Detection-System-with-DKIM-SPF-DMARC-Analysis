"""
DKIM Verifier
Handles DKIM signature verification and analysis
"""

import base64
import hashlib
import re
from typing import Dict, List, Optional
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import rsa, padding
from cryptography.exceptions import InvalidSignature

class DKIMVerifier:
    def __init__(self):
        self.supported_algorithms = ['rsa-sha1', 'rsa-sha256']
        self.supported_hash_algorithms = ['sha1', 'sha256']
    
    def verify(self, domain: str, dkim_records: List[Dict], email_data: Dict = None) -> Dict:
        """Verify DKIM signatures and return analysis results"""
        result = {
            'valid': False,
            'signatures': [],
            'records': dkim_records,
            'errors': [],
            'warnings': [],
            'recommendations': [],
            'score': 0
        }
        
        if not dkim_records:
            result['errors'].append("No DKIM records found")
            return result
        
        if not email_data or 'dkim_signature' not in email_data:
            result['warnings'].append("No DKIM signature found in email headers")
            return result
        
        # Process each DKIM record
        for dkim_record in dkim_records:
            signature_result = self._verify_signature(dkim_record, email_data)
            result['signatures'].append(signature_result)
            
            if signature_result['valid']:
                result['valid'] = True
                result['score'] += 10
        
        # Generate recommendations
        self._generate_recommendations(result, domain)
        
        return result
    
    def _verify_signature(self, dkim_record: Dict, email_data: Dict) -> Dict:
        """Verify individual DKIM signature"""
        signature_result = {
            'valid': False,
            'selector': dkim_record.get('selector', ''),
            'domain': dkim_record.get('domain', ''),
            'record': dkim_record.get('record', ''),
            'errors': [],
            'warnings': []
        }
        
        try:
            # Parse DKIM record
            dkim_data = self._parse_dkim_record(dkim_record['record'])
            signature_result.update(dkim_data)
            
            # Get DKIM signature from email
            dkim_signature = email_data.get('dkim_signature', {})
            if not dkim_signature:
                signature_result['errors'].append("No DKIM signature in email headers")
                return signature_result
            
            # Verify signature
            if self._verify_dkim_signature(dkim_signature, dkim_data, email_data):
                signature_result['valid'] = True
            else:
                signature_result['errors'].append("DKIM signature verification failed")
                
        except Exception as e:
            signature_result['errors'].append(f"Error verifying signature: {str(e)}")
        
        return signature_result
    
    def _parse_dkim_record(self, dkim_record: str) -> Dict:
        """Parse DKIM record into components"""
        dkim_data = {
            'version': '',
            'algorithm': '',
            'public_key': '',
            'hash_algorithm': '',
            'key_type': '',
            'key_length': 0
        }
        
        # Parse DKIM record parameters
        params = re.findall(r'([a-z])=([^;]+)', dkim_record)
        for param, value in params:
            if param == 'v':
                dkim_data['version'] = value.strip()
            elif param == 'k':
                dkim_data['key_type'] = value.strip()
            elif param == 'p':
                dkim_data['public_key'] = value.strip()
            elif param == 'h':
                dkim_data['hash_algorithm'] = value.strip()
        
        # Determine algorithm from key type
        if dkim_data['key_type'] == 'rsa':
            dkim_data['algorithm'] = 'rsa-sha256'  # Default to SHA256
            if dkim_data['hash_algorithm']:
                dkim_data['algorithm'] = f"rsa-{dkim_data['hash_algorithm']}"
        
        # Calculate key length
        if dkim_data['public_key']:
            try:
                key_data = base64.b64decode(dkim_data['public_key'])
                dkim_data['key_length'] = len(key_data) * 8
            except Exception:
                dkim_data['key_length'] = 0
        
        return dkim_data
    
    def _verify_dkim_signature(self, dkim_signature: Dict, dkim_data: Dict, email_data: Dict) -> bool:
        """Verify DKIM signature using public key"""
        try:
            # Get public key
            public_key_pem = self._get_public_key_pem(dkim_data['public_key'])
            if not public_key_pem:
                return False
            
            # Load public key
            public_key = serialization.load_der_public_key(public_key_pem)
            
            # Get signature data
            signature = dkim_signature.get('b', '')
            if not signature:
                return False
            
            # Decode signature
            signature_bytes = base64.b64decode(signature)
            
            # Get canonicalized headers and body
            canonical_headers = self._get_canonical_headers(dkim_signature, email_data)
            canonical_body = self._get_canonical_body(email_data)
            
            # Create message to verify
            message = canonical_headers + canonical_body
            
            # Verify signature
            hash_algorithm = dkim_data.get('hash_algorithm', 'sha256')
            if hash_algorithm == 'sha1':
                hash_obj = hashes.SHA1()
            else:
                hash_obj = hashes.SHA256()
            
            public_key.verify(
                signature_bytes,
                message,
                padding.PKCS1v15(),
                hash_obj
            )
            
            return True
            
        except (InvalidSignature, Exception) as e:
            print(f"DKIM verification error: {e}")
            return False
    
    def _get_public_key_pem(self, public_key_b64: str) -> Optional[bytes]:
        """Convert base64 public key to DER format"""
        try:
            # Decode base64
            key_data = base64.b64decode(public_key_b64)
            
            # Add PEM headers
            pem_key = b"-----BEGIN PUBLIC KEY-----\n"
            pem_key += base64.b64encode(key_data)
            pem_key += b"\n-----END PUBLIC KEY-----\n"
            
            return pem_key
        except Exception:
            return None
    
    def _get_canonical_headers(self, dkim_signature: Dict, email_data: Dict) -> bytes:
        """Get canonicalized headers for DKIM verification"""
        # This is a simplified implementation
        # In practice, you'd need to implement proper DKIM canonicalization
        headers = []
        
        # Add required headers in order
        for header in ['From', 'To', 'Subject', 'Date', 'Message-ID']:
            if header in email_data.get('headers', {}):
                headers.append(f"{header}: {email_data['headers'][header]}")
        
        return '\r\n'.join(headers).encode('utf-8')
    
    def _get_canonical_body(self, email_data: Dict) -> bytes:
        """Get canonicalized body for DKIM verification"""
        # This is a simplified implementation
        # In practice, you'd need to implement proper DKIM canonicalization
        body = email_data.get('body', '')
        return body.encode('utf-8')
    
    def _generate_recommendations(self, result: Dict, domain: str):
        """Generate recommendations based on DKIM analysis"""
        recommendations = []
        
        if not result['records']:
            recommendations.append("Add DKIM records to enable email authentication")
            return
        
        if not result['valid']:
            recommendations.append("Fix DKIM signature verification issues")
        
        # Check key length
        for signature in result.get('signatures', []):
            if signature.get('key_length', 0) < 1024:
                recommendations.append("Consider using longer DKIM keys (2048+ bits)")
                break
        
        # Check algorithm
        for signature in result.get('signatures', []):
            if signature.get('algorithm') == 'rsa-sha1':
                recommendations.append("Consider upgrading to RSA-SHA256 for better security")
                break
        
        result['recommendations'] = recommendations
