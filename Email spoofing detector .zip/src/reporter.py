"""
Report Generator
Generates comprehensive reports for email spoofing analysis
"""

from typing import Dict, List
from datetime import datetime
from tabulate import tabulate
from colorama import Fore, Style, init

# Initialize colorama for colored output
init(autoreset=True)

class ReportGenerator:
    def __init__(self):
        self.colors = {
            'success': Fore.GREEN,
            'warning': Fore.YELLOW,
            'error': Fore.RED,
            'info': Fore.CYAN,
            'header': Fore.MAGENTA,
            'reset': Style.RESET_ALL
        }
    
    def generate_report(self, results: Dict) -> str:
        """Generate comprehensive analysis report"""
        report = []
        
        # Header
        report.append(self._generate_header())
        
        # Domain information
        if 'domain' in results:
            report.append(self._generate_domain_section(results['domain']))
        
        # Email information
        if 'email_data' in results:
            report.append(self._generate_email_section(results['email_data']))
        
        # DNS records
        if 'dns_records' in results:
            report.append(self._generate_dns_section(results['dns_records']))
        
        # SPF analysis
        if 'spf' in results:
            report.append(self._generate_spf_section(results['spf']))
        
        # DKIM analysis
        if 'dkim' in results:
            report.append(self._generate_dkim_section(results['dkim']))
        
        # DMARC analysis
        if 'dmarc' in results:
            report.append(self._generate_dmarc_section(results['dmarc']))
        
        # Overall assessment
        report.append(self._generate_assessment_section(results))
        
        # Recommendations
        report.append(self._generate_recommendations_section(results))
        
        # Footer
        report.append(self._generate_footer())
        
        return '\n'.join(report)
    
    def _generate_header(self) -> str:
        """Generate report header"""
        header = f"""
{self.colors['header']}{'='*80}
                    EMAIL SPOOFING DETECTION REPORT
{self.colors['header']}{'='*80}
{self.colors['info']}Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
{self.colors['info']}Tool: Email Spoofing Detection System v1.0
{self.colors['header']}{'='*80}
"""
        return header
    
    def _generate_domain_section(self, domain: str) -> str:
        """Generate domain information section"""
        section = f"""
{self.colors['header']}DOMAIN ANALYSIS
{self.colors['header']}{'-'*40}
{self.colors['info']}Domain: {domain}
"""
        return section
    
    def _generate_email_section(self, email_data: Dict) -> str:
        """Generate email information section"""
        section = f"""
{self.colors['header']}EMAIL INFORMATION
{self.colors['header']}{'-'*40}
{self.colors['info']}From: {email_data.get('from_email', 'N/A')}
{self.colors['info']}To: {email_data.get('to_email', 'N/A')}
{self.colors['info']}Subject: {email_data.get('subject', 'N/A')}
{self.colors['info']}Message-ID: {email_data.get('message_id', 'N/A')}
{self.colors['info']}Return-Path: {email_data.get('return_path', 'N/A')}
"""
        return section
    
    def _generate_dns_section(self, dns_records: Dict) -> str:
        """Generate DNS records section"""
        section = f"""
{self.colors['header']}DNS RECORDS
{self.colors['header']}{'-'*40}
"""
        
        # SPF record
        spf_record = dns_records.get('spf')
        if spf_record:
            section += f"{self.colors['success']}✓ SPF Record Found:\n{self.colors['info']}  {spf_record}\n"
        else:
            section += f"{self.colors['error']}✗ No SPF Record Found\n"
        
        # DKIM records
        dkim_records = dns_records.get('dkim', [])
        if dkim_records:
            section += f"{self.colors['success']}✓ DKIM Records Found ({len(dkim_records)}):\n"
            for i, dkim in enumerate(dkim_records, 1):
                section += f"{self.colors['info']}  {i}. {dkim.get('selector', 'N/A')} - {dkim.get('domain', 'N/A')}\n"
        else:
            section += f"{self.colors['error']}✗ No DKIM Records Found\n"
        
        # DMARC record
        dmarc_record = dns_records.get('dmarc')
        if dmarc_record:
            section += f"{self.colors['success']}✓ DMARC Record Found:\n{self.colors['info']}  {dmarc_record}\n"
        else:
            section += f"{self.colors['error']}✗ No DMARC Record Found\n"
        
        return section
    
    def _generate_spf_section(self, spf_result: Dict) -> str:
        """Generate SPF analysis section"""
        section = f"""
{self.colors['header']}SPF ANALYSIS
{self.colors['header']}{'-'*40}
"""
        
        # Status
        if spf_result.get('valid'):
            section += f"{self.colors['success']}✓ SPF Validation: PASSED\n"
        else:
            section += f"{self.colors['error']}✗ SPF Validation: FAILED\n"
        
        # Score
        score = spf_result.get('score', 0)
        section += f"{self.colors['info']}Score: {score}/100\n"
        
        # Mechanisms
        mechanisms = spf_result.get('mechanisms', [])
        if mechanisms:
            section += f"{self.colors['info']}Mechanisms Found:\n"
            for mech in mechanisms:
                qualifier = mech.get('qualifier', '+')
                mech_type = mech.get('type', 'unknown')
                value = mech.get('value', '')
                section += f"  {qualifier}{mech_type}: {value}\n"
        
        # Errors
        errors = spf_result.get('errors', [])
        if errors:
            section += f"{self.colors['error']}Errors:\n"
            for error in errors:
                section += f"  • {error}\n"
        
        # Warnings
        warnings = spf_result.get('warnings', [])
        if warnings:
            section += f"{self.colors['warning']}Warnings:\n"
            for warning in warnings:
                section += f"  • {warning}\n"
        
        return section
    
    def _generate_dkim_section(self, dkim_result: Dict) -> str:
        """Generate DKIM analysis section"""
        section = f"""
{self.colors['header']}DKIM ANALYSIS
{self.colors['header']}{'-'*40}
"""
        
        # Status
        if dkim_result.get('valid'):
            section += f"{self.colors['success']}✓ DKIM Verification: PASSED\n"
        else:
            section += f"{self.colors['error']}✗ DKIM Verification: FAILED\n"
        
        # Score
        score = dkim_result.get('score', 0)
        section += f"{self.colors['info']}Score: {score}/100\n"
        
        # Signatures
        signatures = dkim_result.get('signatures', [])
        if signatures:
            section += f"{self.colors['info']}Signatures Found:\n"
            for i, sig in enumerate(signatures, 1):
                status = "✓ PASSED" if sig.get('valid') else "✗ FAILED"
                section += f"  {i}. {sig.get('selector', 'N/A')} - {status}\n"
        
        # Errors
        errors = dkim_result.get('errors', [])
        if errors:
            section += f"{self.colors['error']}Errors:\n"
            for error in errors:
                section += f"  • {error}\n"
        
        # Warnings
        warnings = dkim_result.get('warnings', [])
        if warnings:
            section += f"{self.colors['warning']}Warnings:\n"
            for warning in warnings:
                section += f"  • {warning}\n"
        
        return section
    
    def _generate_dmarc_section(self, dmarc_result: Dict) -> str:
        """Generate DMARC analysis section"""
        section = f"""
{self.colors['header']}DMARC ANALYSIS
{self.colors['header']}{'-'*40}
"""
        
        # Status
        if dmarc_result.get('valid'):
            section += f"{self.colors['success']}✓ DMARC Policy: VALID\n"
        else:
            section += f"{self.colors['error']}✗ DMARC Policy: INVALID\n"
        
        # Score
        score = dmarc_result.get('score', 0)
        section += f"{self.colors['info']}Score: {score}/100\n"
        
        # Policy details
        policy = dmarc_result.get('policy', {})
        if policy:
            section += f"{self.colors['info']}Policy Details:\n"
            section += f"  Policy: {policy.get('policy', 'N/A')}\n"
            section += f"  Subdomain Policy: {policy.get('subdomain_policy', 'N/A')}\n"
            section += f"  Percentage: {policy.get('pct', 'N/A')}%\n"
            section += f"  DKIM Alignment: {policy.get('adkim', 'N/A')}\n"
            section += f"  SPF Alignment: {policy.get('aspf', 'N/A')}\n"
        
        # Compliance
        compliance = dmarc_result.get('compliance', 'unknown')
        if compliance == 'pass':
            section += f"{self.colors['success']}Compliance: PASS\n"
        elif compliance == 'fail':
            section += f"{self.colors['error']}Compliance: FAIL\n"
        else:
            section += f"{self.colors['warning']}Compliance: UNKNOWN\n"
        
        # Errors
        errors = dmarc_result.get('errors', [])
        if errors:
            section += f"{self.colors['error']}Errors:\n"
            for error in errors:
                section += f"  • {error}\n"
        
        # Warnings
        warnings = dmarc_result.get('warnings', [])
        if warnings:
            section += f"{self.colors['warning']}Warnings:\n"
            for warning in warnings:
                section += f"  • {warning}\n"
        
        return section
    
    def _generate_assessment_section(self, results: Dict) -> str:
        """Generate overall assessment section"""
        section = f"""
{self.colors['header']}OVERALL ASSESSMENT
{self.colors['header']}{'-'*40}
"""
        
        # Calculate overall score
        total_score = 0
        max_score = 0
        
        if 'spf' in results:
            total_score += results['spf'].get('score', 0)
            max_score += 100
        
        if 'dkim' in results:
            total_score += results['dkim'].get('score', 0)
            max_score += 100
        
        if 'dmarc' in results:
            total_score += results['dmarc'].get('score', 0)
            max_score += 100
        
        if max_score > 0:
            overall_score = (total_score / max_score) * 100
            section += f"{self.colors['info']}Overall Score: {overall_score:.1f}/100\n"
            
            if overall_score >= 80:
                section += f"{self.colors['success']}Status: EXCELLENT - Strong email authentication\n"
            elif overall_score >= 60:
                section += f"{self.colors['warning']}Status: GOOD - Some improvements needed\n"
            elif overall_score >= 40:
                section += f"{self.colors['warning']}Status: FAIR - Multiple issues found\n"
            else:
                section += f"{self.colors['error']}Status: POOR - Significant security risks\n"
        
        # Risk assessment
        section += f"\n{self.colors['info']}Risk Assessment:\n"
        
        # Check for critical issues
        critical_issues = []
        
        if 'spf' in results and not results['spf'].get('valid'):
            critical_issues.append("SPF validation failed")
        
        if 'dkim' in results and not results['dkim'].get('valid'):
            critical_issues.append("DKIM verification failed")
        
        if 'dmarc' in results and not results['dmarc'].get('valid'):
            critical_issues.append("DMARC policy invalid")
        
        if critical_issues:
            section += f"{self.colors['error']}  HIGH RISK: {', '.join(critical_issues)}\n"
        else:
            section += f"{self.colors['success']}  LOW RISK: All authentication mechanisms working\n"
        
        return section
    
    def _generate_recommendations_section(self, results: Dict) -> str:
        """Generate recommendations section"""
        section = f"""
{self.colors['header']}RECOMMENDATIONS
{self.colors['header']}{'-'*40}
"""
        
        all_recommendations = []
        
        # Collect recommendations from all components
        for component in ['spf', 'dkim', 'dmarc']:
            if component in results:
                recommendations = results[component].get('recommendations', [])
                all_recommendations.extend(recommendations)
        
        if all_recommendations:
            for i, rec in enumerate(all_recommendations, 1):
                section += f"{self.colors['info']}{i}. {rec}\n"
        else:
            section += f"{self.colors['success']}No specific recommendations - configuration looks good!\n"
        
        return section
    
    def _generate_footer(self) -> str:
        """Generate report footer"""
        footer = f"""
{self.colors['header']}{'='*80}
{self.colors['info']}Report generated by Email Spoofing Detection System
{self.colors['info']}For more information, visit: https://github.com/your-repo/email-spoofing-detector
{self.colors['header']}{'='*80}
"""
        return footer
