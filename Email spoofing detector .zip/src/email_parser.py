"""
Email Parser
Handles parsing of email files and extracting relevant information
"""

import email
import re
from typing import Dict, Optional, List
from email.header import decode_header

class EmailParser:
    def __init__(self):
        self.email_data = {}
    
    def parse_email_file(self, file_path: str) -> Optional[Dict]:
        """Parse email file and extract relevant information"""
        try:
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                email_content = f.read()
            return self.parse_email_content(email_content)
        except Exception as e:
            print(f"Error reading email file: {e}")
            return None
    
    def parse_email_content(self, email_content: str) -> Dict:
        """Parse email content and extract headers"""
        msg = email.message_from_string(email_content)
        
        email_data = {
            'headers': {},
            'from_email': None,
            'from_domain': None,
            'to_email': None,
            'to_domain': None,
            'subject': None,
            'message_id': None,
            'return_path': None,
            'dkim_signature': None,
            'received_headers': [],
            'spf_results': [],
            'authentication_results': None
        }
        
        # Extract basic headers
        for header in ['From', 'To', 'Subject', 'Message-ID', 'Return-Path']:
            value = msg.get(header)
            if value:
                email_data['headers'][header] = self._decode_header(value)
        
        # Extract From information
        from_header = msg.get('From', '')
        if from_header:
            email_data['from_email'] = self._extract_email(from_header)
            email_data['from_domain'] = self._extract_domain(email_data['from_email'])
        
        # Extract To information
        to_header = msg.get('To', '')
        if to_header:
            email_data['to_email'] = self._extract_email(to_header)
            email_data['to_domain'] = self._extract_domain(email_data['to_email'])
        
        # Extract subject
        email_data['subject'] = self._decode_header(msg.get('Subject', ''))
        
        # Extract Message-ID
        email_data['message_id'] = msg.get('Message-ID', '')
        
        # Extract Return-Path
        email_data['return_path'] = msg.get('Return-Path', '')
        
        # Extract DKIM signature
        dkim_signature = msg.get('DKIM-Signature', '')
        if dkim_signature:
            email_data['dkim_signature'] = self._parse_dkim_signature(dkim_signature)
        
        # Extract Received headers
        email_data['received_headers'] = msg.get_all('Received', [])
        
        # Extract Authentication-Results
        email_data['authentication_results'] = msg.get('Authentication-Results', '')
        
        return email_data
    
    def _decode_header(self, header_value: str) -> str:
        """Decode email header value"""
        if not header_value:
            return ''
        
        decoded_parts = decode_header(header_value)
        decoded_string = ''
        
        for part, encoding in decoded_parts:
            if isinstance(part, bytes):
                if encoding:
                    try:
                        decoded_string += part.decode(encoding)
                    except (UnicodeDecodeError, LookupError):
                        decoded_string += part.decode('utf-8', errors='ignore')
                else:
                    decoded_string += part.decode('utf-8', errors='ignore')
            else:
                decoded_string += part
        
        return decoded_string
    
    def _extract_email(self, header_value: str) -> Optional[str]:
        """Extract email address from header value"""
        email_pattern = r'<([^>]+@[^>]+)>|([a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,})'
        match = re.search(email_pattern, header_value)
        if match:
            return match.group(1) or match.group(2)
        return None
    
    def _extract_domain(self, email_address: str) -> Optional[str]:
        """Extract domain from email address"""
        if email_address and '@' in email_address:
            return email_address.split('@')[1].lower()
        return None
    
    def _parse_dkim_signature(self, dkim_header: str) -> Dict[str, str]:
        """Parse DKIM signature header"""
        dkim_data = {}
        
        # Parse DKIM signature parameters
        params = re.findall(r'([a-z])=([^;]+)', dkim_header)
        for param, value in params:
            dkim_data[param] = value.strip()
        
        return dkim_data
    
    def get_spf_results_from_headers(self, email_data: Dict) -> List[str]:
        """Extract SPF results from email headers"""
        spf_results = []
        
        # Look for SPF results in Received headers
        for received in email_data.get('received_headers', []):
            if 'spf=' in received.lower():
                spf_results.append(received)
        
        # Look for SPF results in Authentication-Results
        auth_results = email_data.get('authentication_results', '')
        if 'spf=' in auth_results.lower():
            spf_results.append(auth_results)
        
        return spf_results
