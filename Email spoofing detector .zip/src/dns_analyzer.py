"""
DNS Record Analyzer
Handles DNS queries for SPF, DKIM, and DMARC records
"""

import dns.resolver
import dns.exception
from typing import Dict, List, Optional, Tuple

class DNSAnalyzer:
    def __init__(self):
        self.resolver = dns.resolver.Resolver()
        self.resolver.timeout = 10
        self.resolver.lifetime = 10
    
    def get_all_records(self, domain: str) -> Dict[str, any]:
        """Get all relevant DNS records for email authentication"""
        records = {
            'spf': self.get_spf_record(domain),
            'dkim': self.get_dkim_records(domain),
            'dmarc': self.get_dmarc_record(domain)
        }
        return records
    
    def get_spf_record(self, domain: str) -> Optional[str]:
        """Get SPF record for domain"""
        try:
            answers = self.resolver.resolve(domain, 'TXT')
            for answer in answers:
                txt_record = str(answer).strip('"')
                if txt_record.startswith('v=spf1'):
                    return txt_record
        except (dns.resolver.NXDOMAIN, dns.resolver.NoAnswer, dns.exception.DNSException):
            pass
        return None
    
    def get_dkim_records(self, domain: str) -> List[Dict[str, str]]:
        """Get DKIM records for domain"""
        dkim_records = []
        
        # Common DKIM selectors
        selectors = ['default', 'google', 'k1', 'selector1', 'selector2', 'mail']
        
        for selector in selectors:
            dkim_domain = f"{selector}._domainkey.{domain}"
            try:
                answers = self.resolver.resolve(dkim_domain, 'TXT')
                for answer in answers:
                    txt_record = str(answer).strip('"')
                    if txt_record.startswith('v=DKIM1'):
                        dkim_records.append({
                            'selector': selector,
                            'record': txt_record,
                            'domain': dkim_domain
                        })
            except (dns.resolver.NXDOMAIN, dns.resolver.NoAnswer, dns.exception.DNSException):
                continue
        
        return dkim_records
    
    def get_dmarc_record(self, domain: str) -> Optional[str]:
        """Get DMARC record for domain"""
        dmarc_domain = f"_dmarc.{domain}"
        try:
            answers = self.resolver.resolve(dmarc_domain, 'TXT')
            for answer in answers:
                txt_record = str(answer).strip('"')
                if txt_record.startswith('v=DMARC1'):
                    return txt_record
        except (dns.resolver.NXDOMAIN, dns.resolver.NoAnswer, dns.exception.DNSException):
            pass
        return None
    
    def get_mx_records(self, domain: str) -> List[Tuple[str, int]]:
        """Get MX records for domain"""
        try:
            answers = self.resolver.resolve(domain, 'MX')
            mx_records = []
            for answer in answers:
                mx_records.append((str(answer.exchange), answer.preference))
            return sorted(mx_records, key=lambda x: x[1])
        except (dns.resolver.NXDOMAIN, dns.resolver.NoAnswer, dns.exception.DNSException):
            return []
    
    def get_a_records(self, domain: str) -> List[str]:
        """Get A records for domain"""
        try:
            answers = self.resolver.resolve(domain, 'A')
            return [str(answer) for answer in answers]
        except (dns.resolver.NXDOMAIN, dns.resolver.NoAnswer, dns.exception.DNSException):
            return []
