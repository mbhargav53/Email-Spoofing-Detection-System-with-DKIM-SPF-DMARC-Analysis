"""
SPF Validator
Handles SPF record validation and analysis
"""

import re
import ipaddress
from typing import Dict, List, Optional, Tuple
from urllib.parse import urlparse

class SPFValidator:
    def __init__(self):
        self.spf_mechanisms = {
            'ip4': self._validate_ip4,
            'ip6': self._validate_ip6,
            'a': self._validate_a,
            'mx': self._validate_mx,
            'include': self._validate_include,
            'redirect': self._validate_redirect,
            'exists': self._validate_exists,
            'all': self._validate_all
        }
    
    def validate(self, domain: str, spf_record: Optional[str], sender_ip: str = None) -> Dict:
        """Validate SPF record and return analysis results"""
        result = {
            'valid': False,
            'record': spf_record,
            'mechanisms': [],
            'errors': [],
            'warnings': [],
            'recommendations': [],
            'score': 0
        }
        
        if not spf_record:
            result['errors'].append("No SPF record found")
            return result
        
        # Parse SPF record
        try:
            mechanisms = self._parse_spf_record(spf_record)
            result['mechanisms'] = mechanisms
            
            # Validate each mechanism
            for mechanism in mechanisms:
                self._validate_mechanism(mechanism, result, domain, sender_ip)
            
            # Calculate score
            result['score'] = self._calculate_spf_score(result)
            result['valid'] = result['score'] > 0
            
            # Generate recommendations
            self._generate_recommendations(result, domain)
            
        except Exception as e:
            result['errors'].append(f"Error parsing SPF record: {str(e)}")
        
        return result
    
    def _parse_spf_record(self, spf_record: str) -> List[Dict]:
        """Parse SPF record into individual mechanisms"""
        mechanisms = []
        
        # Remove version prefix
        if spf_record.startswith('v=spf1 '):
            spf_record = spf_record[7:]
        
        # Split by spaces and parse each mechanism
        parts = spf_record.split()
        for part in parts:
            if not part:
                continue
            
            mechanism = {
                'type': 'unknown',
                'value': part,
                'qualifier': '+',
                'raw': part
            }
            
            # Extract qualifier
            if part.startswith(('+', '-', '~', '?')):
                mechanism['qualifier'] = part[0]
                part = part[1:]
            
            # Determine mechanism type
            if ':' in part:
                mech_type, value = part.split(':', 1)
                mechanism['type'] = mech_type
                mechanism['value'] = value
            else:
                mechanism['type'] = part
                mechanism['value'] = ''
            
            mechanisms.append(mechanism)
        
        return mechanisms
    
    def _validate_mechanism(self, mechanism: Dict, result: Dict, domain: str, sender_ip: str = None):
        """Validate individual SPF mechanism"""
        mech_type = mechanism['type']
        
        if mech_type in self.spf_mechanisms:
            try:
                self.spf_mechanisms[mech_type](mechanism, result, domain, sender_ip)
            except Exception as e:
                result['errors'].append(f"Error validating {mech_type}: {str(e)}")
        else:
            result['warnings'].append(f"Unknown mechanism type: {mech_type}")
    
    def _validate_ip4(self, mechanism: Dict, result: Dict, domain: str, sender_ip: str = None):
        """Validate IP4 mechanism"""
        try:
            ip = ipaddress.IPv4Network(mechanism['value'], strict=False)
            if sender_ip and ipaddress.IPv4Address(sender_ip) in ip:
                result['score'] += 10
        except ValueError:
            result['errors'].append(f"Invalid IPv4 address: {mechanism['value']}")
    
    def _validate_ip6(self, mechanism: Dict, result: Dict, domain: str, sender_ip: str = None):
        """Validate IP6 mechanism"""
        try:
            ip = ipaddress.IPv6Network(mechanism['value'], strict=False)
            if sender_ip and ipaddress.IPv6Address(sender_ip) in ip:
                result['score'] += 10
        except ValueError:
            result['errors'].append(f"Invalid IPv6 address: {mechanism['value']}")
    
    def _validate_a(self, mechanism: Dict, result: Dict, domain: str, sender_ip: str = None):
        """Validate A mechanism"""
        target_domain = mechanism['value'] or domain
        result['score'] += 5  # Basic score for having A mechanism
        result['warnings'].append(f"A mechanism requires DNS lookup for {target_domain}")
    
    def _validate_mx(self, mechanism: Dict, result: Dict, domain: str, sender_ip: str = None):
        """Validate MX mechanism"""
        target_domain = mechanism['value'] or domain
        result['score'] += 5  # Basic score for having MX mechanism
        result['warnings'].append(f"MX mechanism requires DNS lookup for {target_domain}")
    
    def _validate_include(self, mechanism: Dict, result: Dict, domain: str, sender_ip: str = None):
        """Validate include mechanism"""
        include_domain = mechanism['value']
        if not include_domain:
            result['errors'].append("Include mechanism missing domain")
            return
        
        result['score'] += 3  # Basic score for include
        result['warnings'].append(f"Include mechanism requires SPF lookup for {include_domain}")
    
    def _validate_redirect(self, mechanism: Dict, result: Dict, domain: str, sender_ip: str = None):
        """Validate redirect mechanism"""
        redirect_domain = mechanism['value']
        if not redirect_domain:
            result['errors'].append("Redirect mechanism missing domain")
            return
        
        result['score'] += 2  # Basic score for redirect
        result['warnings'].append(f"Redirect mechanism requires SPF lookup for {redirect_domain}")
    
    def _validate_exists(self, mechanism: Dict, result: Dict, domain: str, sender_ip: str = None):
        """Validate exists mechanism"""
        exists_domain = mechanism['value']
        if not exists_domain:
            result['errors'].append("Exists mechanism missing domain")
            return
        
        result['score'] += 1  # Basic score for exists
        result['warnings'].append(f"Exists mechanism requires DNS lookup for {exists_domain}")
    
    def _validate_all(self, mechanism: Dict, result: Dict, domain: str, sender_ip: str = None):
        """Validate all mechanism"""
        result['score'] += 1  # Basic score for having all mechanism
    
    def _calculate_spf_score(self, result: Dict) -> int:
        """Calculate overall SPF score"""
        score = result.get('score', 0)
        
        # Deduct points for errors
        score -= len(result.get('errors', [])) * 5
        
        # Deduct points for warnings
        score -= len(result.get('warnings', [])) * 1
        
        return max(0, score)
    
    def _generate_recommendations(self, result: Dict, domain: str):
        """Generate recommendations based on SPF analysis"""
        recommendations = []
        
        if not result['record']:
            recommendations.append("Add an SPF record to prevent email spoofing")
            return
        
        # Check for common issues
        mechanisms = result.get('mechanisms', [])
        
        # Check for hard fail
        has_hard_fail = any(m['type'] == 'all' and m['qualifier'] == '-' for m in mechanisms)
        if not has_hard_fail:
            recommendations.append("Consider using '~all' or '-all' for better protection")
        
        # Check for include mechanisms
        has_includes = any(m['type'] == 'include' for m in mechanisms)
        if not has_includes:
            recommendations.append("Consider including SPF records from email service providers")
        
        # Check for IP mechanisms
        has_ip_mechs = any(m['type'] in ['ip4', 'ip6'] for m in mechanisms)
        if not has_ip_mechs:
            recommendations.append("Consider adding specific IP addresses for better control")
        
        result['recommendations'] = recommendations
