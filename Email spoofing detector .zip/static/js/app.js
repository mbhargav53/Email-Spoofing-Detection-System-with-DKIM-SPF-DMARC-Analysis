// Email Spoofing Detection System - Frontend JavaScript

class EmailAnalyzer {
    constructor() {
        this.currentAnalysis = null;
        this.init();
    }

    init() {
        this.setupEventListeners();
        this.setupFileUpload();
    }

    setupEventListeners() {
        // Navigation smooth scrolling
        document.querySelectorAll('.nav-link').forEach(link => {
            link.addEventListener('click', (e) => {
                e.preventDefault();
                const targetId = link.getAttribute('href').substring(1);
                this.scrollToSection(targetId);
            });
        });

        // Domain input enter key
        document.getElementById('domain-input').addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                this.analyzeDomain();
            }
        });
    }

    setupFileUpload() {
        const fileInput = document.getElementById('email-file');
        const fileLabel = document.querySelector('.file-label');

        fileInput.addEventListener('change', (e) => {
            const file = e.target.files[0];
            if (file) {
                fileLabel.innerHTML = `
                    <i class="fas fa-check-circle"></i>
                    <span>${file.name}</span>
                `;
                fileLabel.style.borderColor = '#28a745';
                fileLabel.style.backgroundColor = '#d4edda';
            }
        });
    }

    scrollToSection(sectionId) {
        const section = document.getElementById(sectionId);
        if (section) {
            section.scrollIntoView({ behavior: 'smooth' });
        }
    }

    switchTab(tabName) {
        // Remove active class from all tabs and contents
        document.querySelectorAll('.tab-btn').forEach(btn => btn.classList.remove('active'));
        document.querySelectorAll('.tab-content').forEach(content => content.classList.remove('active'));

        // Add active class to selected tab and content
        document.querySelector(`[onclick="switchTab('${tabName}')"]`).classList.add('active');
        document.getElementById(`${tabName}-tab`).classList.add('active');
    }

    showLoading() {
        document.getElementById('loading').style.display = 'flex';
    }

    hideLoading() {
        document.getElementById('loading').style.display = 'none';
    }

    async analyzeDomain() {
        const domain = document.getElementById('domain-input').value.trim();
        
        if (!domain) {
            this.showAlert('Please enter a domain name', 'error');
            return;
        }

        this.showLoading();
        
        try {
            const response = await fetch('/api/analyze/domain', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ domain: domain })
            });

            const data = await response.json();
            
            if (data.success) {
                this.currentAnalysis = data;
                this.displayResults(data);
                this.scrollToSection('results');
            } else {
                this.showAlert(data.error || 'Analysis failed', 'error');
            }
        } catch (error) {
            this.showAlert('Network error: ' + error.message, 'error');
        } finally {
            this.hideLoading();
        }
    }

    async analyzeEmail() {
        const fileInput = document.getElementById('email-file');
        const file = fileInput.files[0];
        
        if (!file) {
            this.showAlert('Please select an email file', 'error');
            return;
        }

        this.showLoading();
        
        try {
            const formData = new FormData();
            formData.append('file', file);

            const response = await fetch('/api/analyze/email', {
                method: 'POST',
                body: formData
            });

            const data = await response.json();
            
            if (data.success) {
                this.currentAnalysis = data;
                this.displayResults(data);
                this.scrollToSection('results');
            } else {
                this.showAlert(data.error || 'Analysis failed', 'error');
            }
        } catch (error) {
            this.showAlert('Network error: ' + error.message, 'error');
        } finally {
            this.hideLoading();
        }
    }

    displayResults(data) {
        // Update overall score
        const overallScore = this.calculateOverallScore(data);
        document.getElementById('overall-score').textContent = overallScore;
        document.getElementById('score-status').textContent = this.getScoreStatus(overallScore);
        document.getElementById('score-description').textContent = this.getScoreDescription(overallScore);

        // Update SPF analysis
        this.updateAnalysisCard('spf', data.spf);
        
        // Update DKIM analysis
        this.updateAnalysisCard('dkim', data.dkim);
        
        // Update DMARC analysis
        this.updateAnalysisCard('dmarc', data.dmarc);

        // Generate detailed report
        this.generateDetailedReport(data);

        // Show results section
        document.getElementById('results').style.display = 'block';
    }

    updateAnalysisCard(type, analysis) {
        const status = analysis.valid ? 'pass' : 'fail';
        const score = analysis.score || 0;
        
        // Update status badge
        const statusBadge = document.getElementById(`${type}-status`);
        statusBadge.textContent = status.toUpperCase();
        statusBadge.className = `status-badge ${status}`;
        
        // Update score
        document.getElementById(`${type}-score`).textContent = score;
        document.getElementById(`${type}-score-fill`).style.width = `${score}%`;
        
        // Update details
        const details = document.getElementById(`${type}-details`);
        details.innerHTML = this.formatAnalysisDetails(analysis);
    }

    formatAnalysisDetails(analysis) {
        let html = '';
        
        if (analysis.errors && analysis.errors.length > 0) {
            html += '<div class="error-details">';
            html += '<strong>Errors:</strong><ul>';
            analysis.errors.forEach(error => {
                html += `<li>${error}</li>`;
            });
            html += '</ul></div>';
        }
        
        if (analysis.warnings && analysis.warnings.length > 0) {
            html += '<div class="warning-details">';
            html += '<strong>Warnings:</strong><ul>';
            analysis.warnings.forEach(warning => {
                html += `<li>${warning}</li>`;
            });
            html += '</ul></div>';
        }
        
        if (analysis.recommendations && analysis.recommendations.length > 0) {
            html += '<div class="recommendation-details">';
            html += '<strong>Recommendations:</strong><ul>';
            analysis.recommendations.forEach(rec => {
                html += `<li>${rec}</li>`;
            });
            html += '</ul></div>';
        }
        
        return html || '<p>No additional details available</p>';
    }

    calculateOverallScore(data) {
        let totalScore = 0;
        let maxScore = 0;
        
        ['spf', 'dkim', 'dmarc'].forEach(type => {
            if (data[type]) {
                totalScore += data[type].score || 0;
                maxScore += 100;
            }
        });
        
        return maxScore > 0 ? Math.round((totalScore / maxScore) * 100) : 0;
    }

    getScoreStatus(score) {
        if (score >= 80) return 'EXCELLENT';
        if (score >= 60) return 'GOOD';
        if (score >= 40) return 'FAIR';
        return 'POOR';
    }

    getScoreDescription(score) {
        if (score >= 80) return 'Strong email authentication configuration';
        if (score >= 60) return 'Good security with some improvements needed';
        if (score >= 40) return 'Multiple security issues found';
        return 'Significant security risks detected';
    }

    async generateDetailedReport(data) {
        try {
            const response = await fetch('/api/generate-report', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ analysis_data: data })
            });

            const result = await response.json();
            
            if (result.success) {
                document.getElementById('detailed-report').textContent = result.report;
            } else {
                document.getElementById('detailed-report').textContent = 'Error generating detailed report: ' + result.error;
            }
        } catch (error) {
            document.getElementById('detailed-report').textContent = 'Error generating detailed report: ' + error.message;
        }
    }

    downloadReport() {
        if (!this.currentAnalysis) {
            this.showAlert('No analysis data available for download', 'error');
            return;
        }

        const reportContent = document.getElementById('detailed-report').textContent;
        const blob = new Blob([reportContent], { type: 'text/plain' });
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `email-security-report-${new Date().toISOString().split('T')[0]}.txt`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        window.URL.revokeObjectURL(url);
    }

    printReport() {
        const reportContent = document.getElementById('detailed-report').textContent;
        const printWindow = window.open('', '_blank');
        printWindow.document.write(`
            <html>
                <head>
                    <title>Email Security Report</title>
                    <style>
                        body { font-family: Arial, sans-serif; margin: 20px; }
                        pre { white-space: pre-wrap; }
                    </style>
                </head>
                <body>
                    <h1>Email Security Analysis Report</h1>
                    <pre>${reportContent}</pre>
                </body>
            </html>
        `);
        printWindow.document.close();
        printWindow.print();
    }

    showAlert(message, type = 'info') {
        // Create alert element
        const alert = document.createElement('div');
        alert.className = `alert alert-${type}`;
        alert.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            padding: 15px 20px;
            border-radius: 5px;
            color: white;
            font-weight: 600;
            z-index: 10000;
            max-width: 400px;
            word-wrap: break-word;
        `;
        
        // Set background color based on type
        switch (type) {
            case 'error':
                alert.style.backgroundColor = '#dc3545';
                break;
            case 'success':
                alert.style.backgroundColor = '#28a745';
                break;
            case 'warning':
                alert.style.backgroundColor = '#ffc107';
                alert.style.color = '#333';
                break;
            default:
                alert.style.backgroundColor = '#17a2b8';
        }
        
        alert.textContent = message;
        document.body.appendChild(alert);
        
        // Remove alert after 5 seconds
        setTimeout(() => {
            if (alert.parentNode) {
                alert.parentNode.removeChild(alert);
            }
        }, 5000);
    }

    showDemo() {
        // Fill in demo data
        document.getElementById('domain-input').value = 'google.com';
        this.analyzeDomain();
    }
}

// Initialize the application when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    window.emailAnalyzer = new EmailAnalyzer();
});

// Global functions for HTML onclick handlers
function switchTab(tabName) {
    window.emailAnalyzer.switchTab(tabName);
}

function analyzeDomain() {
    window.emailAnalyzer.analyzeDomain();
}

function analyzeEmail() {
    window.emailAnalyzer.analyzeEmail();
}

function downloadReport() {
    window.emailAnalyzer.downloadReport();
}

function printReport() {
    window.emailAnalyzer.printReport();
}

function showDemo() {
    window.emailAnalyzer.showDemo();
}

function scrollToSection(sectionId) {
    window.emailAnalyzer.scrollToSection(sectionId);
}
