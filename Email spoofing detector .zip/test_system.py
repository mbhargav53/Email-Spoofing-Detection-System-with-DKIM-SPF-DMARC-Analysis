#!/usr/bin/env python3
"""
Test script for Email Spoofing Detection System
"""

import sys
import os
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from src.dns_analyzer import DNSAnalyzer
from src.spf_validator import SPFValidator
from src.dkim_verifier import DKIMVerifier
from src.dmarc_analyzer import DMARCAnalyzer
from src.reporter import ReportGenerator

def test_domain_analysis():
    """Test domain analysis functionality"""
    print("Testing domain analysis...")
    
    # Test with a real domain
    domain = "google.com"
    
    # Initialize components
    dns_analyzer = DNSAnalyzer()
    spf_validator = SPFValidator()
    dkim_verifier = DKIMVerifier()
    dmarc_analyzer = DMARCAnalyzer()
    reporter = ReportGenerator()
    
    print(f"Analyzing domain: {domain}")
    
    # Get DNS records
    print("Fetching DNS records...")
    dns_records = dns_analyzer.get_all_records(domain)
    
    # Validate SPF
    print("Validating SPF...")
    spf_result = spf_validator.validate(domain, dns_records.get('spf'))
    
    # Verify DKIM
    print("Verifying DKIM...")
    dkim_result = dkim_verifier.verify(domain, dns_records.get('dkim'))
    
    # Analyze DMARC
    print("Analyzing DMARC...")
    dmarc_result = dmarc_analyzer.analyze(domain, dns_records.get('dmarc'), spf_result, dkim_result)
    
    # Generate report
    print("Generating report...")
    results = {
        'domain': domain,
        'dns_records': dns_records,
        'spf': spf_result,
        'dkim': dkim_result,
        'dmarc': dmarc_result
    }
    
    report = reporter.generate_report(results)
    print("\n" + "="*80)
    print(report)

def test_email_analysis():
    """Test email analysis functionality"""
    print("\nTesting email analysis...")
    
    email_file = "samples/test_emails/sample_email.eml"
    
    if not os.path.exists(email_file):
        print(f"Email file not found: {email_file}")
        return
    
    from src.email_parser import EmailParser
    
    # Parse email
    email_parser = EmailParser()
    email_data = email_parser.parse_email_file(email_file)
    
    if email_data:
        print("Email parsed successfully!")
        print(f"From: {email_data.get('from_email')}")
        print(f"To: {email_data.get('to_email')}")
        print(f"Subject: {email_data.get('subject')}")
        print(f"DKIM Signature: {'Yes' if email_data.get('dkim_signature') else 'No'}")
    else:
        print("Failed to parse email")

if __name__ == "__main__":
    print("Email Spoofing Detection System - Test Suite")
    print("=" * 50)
    
    try:
        test_domain_analysis()
        test_email_analysis()
        print("\nTest completed successfully!")
    except Exception as e:
        print(f"Test failed with error: {e}")
        import traceback
        traceback.print_exc()
