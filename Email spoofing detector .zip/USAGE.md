# Email Spoofing Detection System - Usage Guide

## Quick Start

### 1. Install Dependencies
```bash
pip install -r requirements.txt
```

### 2. Analyze a Domain
```bash
python main.py --domain example.com
```

### 3. Analyze an Email File
```bash
python main.py --email path/to/email.eml
```

### 4. Save Report to File
```bash
python main.py --domain example.com --output report.txt
```

## Command Line Options

- `--domain`: Analyze a specific domain's email authentication records
- `--email`: Analyze an email file (.eml format)
- `--output`: Save the report to a file
- `--verbose`: Enable verbose output
- `--help`: Show help message

## Examples

### Analyze Google's Email Security
```bash
python main.py --domain google.com --verbose
```

### Analyze a Suspicious Email
```bash
python main.py --email suspicious_email.eml --output analysis_report.txt
```

### Test with Sample Email
```bash
python main.py --email samples/test_emails/sample_email.eml
```

## Understanding the Output

### Color Coding
- 🟢 **Green**: Success/Pass
- 🟡 **Yellow**: Warning
- 🔴 **Red**: Error/Fail
- 🔵 **Blue**: Information
- 🟣 **Magenta**: Headers

### Score Interpretation
- **80-100**: Excellent - Strong email authentication
- **60-79**: Good - Some improvements needed
- **40-59**: Fair - Multiple issues found
- **0-39**: Poor - Significant security risks

### Risk Assessment
- **LOW RISK**: All authentication mechanisms working
- **HIGH RISK**: Critical authentication failures detected

## Components Analyzed

### 1. SPF (Sender Policy Framework)
- Validates sender IP addresses
- Checks for proper SPF record configuration
- Analyzes SPF mechanisms and qualifiers

### 2. DKIM (DomainKeys Identified Mail)
- Verifies cryptographic signatures
- Checks DKIM record configuration
- Validates signature authenticity

### 3. DMARC (Domain-based Message Authentication, Reporting, and Conformance)
- Analyzes DMARC policy configuration
- Evaluates policy compliance
- Checks reporting settings

## Troubleshooting

### Common Issues

1. **"No SPF record found"**
   - Add an SPF record to your domain's DNS
   - Example: `v=spf1 include:_spf.google.com ~all`

2. **"No DKIM records found"**
   - Configure DKIM for your email service
   - Add DKIM records to your DNS

3. **"No DMARC record found"**
   - Add a DMARC record to your domain's DNS
   - Example: `v=DMARC1; p=quarantine; rua=mailto:dmarc@example.com`

### DNS Issues
- Ensure DNS records are properly configured
- Check for typos in domain names
- Verify DNS propagation (can take up to 48 hours)

### Email Parsing Issues
- Ensure email file is in .eml format
- Check file permissions
- Verify email file is not corrupted

## Advanced Usage

### Programmatic Usage
```python
from src.dns_analyzer import DNSAnalyzer
from src.spf_validator import SPFValidator
from src.dkim_verifier import DKIMVerifier
from src.dmarc_analyzer import DMARCAnalyzer

# Initialize components
dns_analyzer = DNSAnalyzer()
spf_validator = SPFValidator()
dkim_verifier = DKIMVerifier()
dmarc_analyzer = DMARCAnalyzer()

# Analyze domain
domain = "example.com"
dns_records = dns_analyzer.get_all_records(domain)
spf_result = spf_validator.validate(domain, dns_records.get('spf'))
dkim_result = dkim_verifier.verify(domain, dns_records.get('dkim'))
dmarc_result = dmarc_analyzer.analyze(domain, dns_records.get('dmarc'))
```

### Custom Testing
```python
# Run the test suite
python test_system.py

# Run specific tests
python -m unittest tests.test_dns_analyzer
```

## Security Considerations

1. **Never run on untrusted email files** without proper sandboxing
2. **Be cautious with DNS queries** - they can reveal your analysis activities
3. **Validate all inputs** before processing
4. **Use HTTPS** for any web-based reporting endpoints

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests for new functionality
5. Submit a pull request

## License

MIT License - see LICENSE file for details
