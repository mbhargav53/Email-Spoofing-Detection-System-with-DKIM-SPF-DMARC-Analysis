# Email Spoofing Detection System

A comprehensive email spoofing detection system that analyzes DMARC, DKIM, and SPF records to identify potential email spoofing attempts.

## Features

- **SPF Analysis**: Validates sender IP addresses against SPF records
- **DKIM Verification**: Verifies cryptographic signatures in email headers
- **DMARC Policy Evaluation**: Analyzes DMARC policies and compliance
- **Comprehensive Reporting**: Detailed analysis reports with recommendations
- **Real-time Detection**: Live email analysis capabilities

## Installation

1. Clone the repository
2. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```

## Usage

```bash
python main.py --email sample_email.eml
python main.py --domain example.com
```

## Project Structure

```
email_spoofing_detector/
├── main.py                 # Main entry point
├── src/
│   ├── __init__.py
│   ├── dns_analyzer.py     # DNS record analysis
│   ├── email_parser.py     # Email header parsing
│   ├── spf_validator.py    # SPF validation logic
│   ├── dkim_verifier.py    # DKIM verification
│   ├── dmarc_analyzer.py   # DMARC policy analysis
│   └── reporter.py         # Report generation
├── tests/
│   ├── __init__.py
│   └── test_*.py
├── samples/
│   └── test_emails/
└── requirements.txt
```

## License

MIT License
