#!/usr/bin/env python3
"""
Email Spoofing Detection System
Main entry point for analyzing email authentication records
"""

import argparse
import sys
from pathlib import Path
from src.email_parser import EmailParser
from src.dns_analyzer import DNSAnalyzer
from src.spf_validator import SPFValidator
from src.dkim_verifier import DKIMVerifier
from src.dmarc_analyzer import DMARCAnalyzer
from src.reporter import ReportGenerator

def main():
    parser = argparse.ArgumentParser(description='Email Spoofing Detection System')
    parser.add_argument('--email', type=str, help='Path to email file (.eml)')
    parser.add_argument('--domain', type=str, help='Domain to analyze')
    parser.add_argument('--output', type=str, help='Output file for report')
    parser.add_argument('--verbose', '-v', action='store_true', help='Verbose output')
    
    args = parser.parse_args()
    
    if not args.email and not args.domain:
        print("Error: Please provide either --email or --domain")
        parser.print_help()
        sys.exit(1)
    
    # Initialize components
    dns_analyzer = DNSAnalyzer()
    spf_validator = SPFValidator()
    dkim_verifier = DKIMVerifier()
    dmarc_analyzer = DMARCAnalyzer()
    reporter = ReportGenerator()
    
    results = {}
    
    if args.email:
        print(f"Analyzing email: {args.email}")
        # Parse email
        email_parser = EmailParser()
        email_data = email_parser.parse_email_file(args.email)
        
        if not email_data:
            print("Error: Could not parse email file")
            sys.exit(1)
        
        # Extract domain from email
        domain = email_data.get('from_domain')
        if not domain:
            print("Error: Could not extract domain from email")
            sys.exit(1)
        
        # Analyze authentication records
        results['email_data'] = email_data
        results['domain'] = domain
        
    elif args.domain:
        print(f"Analyzing domain: {args.domain}")
        results['domain'] = args.domain
    
    # Get DNS records
    print("Fetching DNS records...")
    dns_records = dns_analyzer.get_all_records(results['domain'])
    results['dns_records'] = dns_records
    
    # Validate SPF
    print("Validating SPF...")
    spf_result = spf_validator.validate(results['domain'], dns_records.get('spf'))
    results['spf'] = spf_result
    
    # Verify DKIM
    print("Verifying DKIM...")
    dkim_result = dkim_verifier.verify(results['domain'], dns_records.get('dkim'))
    results['dkim'] = dkim_result
    
    # Analyze DMARC
    print("Analyzing DMARC...")
    dmarc_result = dmarc_analyzer.analyze(results['domain'], dns_records.get('dmarc'))
    results['dmarc'] = dmarc_result
    
    # Generate report
    print("Generating report...")
    report = reporter.generate_report(results)
    
    if args.output:
        with open(args.output, 'w') as f:
            f.write(report)
        print(f"Report saved to: {args.output}")
    else:
        print(report)

if __name__ == "__main__":
    main()
