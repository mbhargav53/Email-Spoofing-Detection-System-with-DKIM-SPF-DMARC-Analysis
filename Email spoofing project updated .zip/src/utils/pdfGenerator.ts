import { jsPDF } from "jspdf";
import { DomainAnalysis, HeaderAnalysis } from "../types";

export function generateDomainReport(analysis: DomainAnalysis) {
  const doc = new jsPDF({
    orientation: "portrait",
    unit: "mm",
    format: "a4",
  });

  const pageWidth = 210;
  const pageHeight = 297;
  const margin = 15;
  const contentWidth = pageWidth - 2 * margin; // 180mm
  let pageNum = 1;
  let y = 22;

  // Header and Footer drawer for subsequent pages
  const drawPageBorderDecoration = (pNum: number) => {
    // Header
    doc.setDrawColor(228, 228, 231); // zinc-200
    doc.setLineWidth(0.2);
    doc.line(margin, 12, pageWidth - margin, 12);

    doc.setFont("helvetica", "normal");
    doc.setFontSize(7.5);
    doc.setTextColor(120, 120, 120);
    doc.text("UNIVERSITY THESIS DELIVERABLE • EMAIL SPOOFING DETECTION SYSTEM", margin, 9);
    doc.text(`REPORT PAGE ${pNum}`, pageWidth - margin, 9, { align: "right" });

    // Footer
    doc.line(margin, pageHeight - 15, pageWidth - margin, pageHeight - 15);
    doc.text(`CONFIDENTIAL VERIFICATION RECORD FOR: ${analysis.domain.toUpperCase()}`, margin, pageHeight - 10);
    doc.text(`GENERATED: ${new Date().toLocaleString()}`, pageWidth - margin, pageHeight - 10, { align: "right" });
  };

  const checkPageOverflow = (neededHeight: number) => {
    if (y + neededHeight > pageHeight - 20) {
      doc.addPage();
      pageNum++;
      y = 22;
      drawPageBorderDecoration(pageNum);
    }
  };

  // --- INITIAL PAGE ---
  drawPageBorderDecoration(pageNum);

  // Title Box
  doc.setFillColor(24, 24, 27); // Zinc-900 (Dark background)
  doc.rect(margin, y, contentWidth, 24, "F");

  doc.setFont("helvetica", "bold");
  doc.setFontSize(13);
  doc.setTextColor(255, 255, 255);
  doc.text("DNS SECURITY PROTOCOL ANALYSIS REPORT", margin + 6, y + 9);

  doc.setFont("helvetica", "normal");
  doc.setFontSize(8.5);
  doc.setTextColor(161, 161, 170); // Zinc-400
  doc.text(`Target Domain Assessment: ${analysis.domain} | Audited on Selector: ${analysis.dkim.selector}`, margin + 6, y + 17);
  y += 30;

  // Overview / Status Section
  checkPageOverflow(30);
  doc.setDrawColor(228, 228, 231);
  doc.setFillColor(248, 250, 252); // light slate gray background
  doc.rect(margin, y, contentWidth, 24, "FD");

  // Choose colors dependent on rating
  let ratingLabel = "LOW RISK (SAFE)";
  let ratingColor = [16, 185, 129]; // Emerald 500
  if (analysis.score >= 35 && analysis.score < 75) {
    ratingLabel = "MEDIUM RISK (SUSPICIOUS)";
    ratingColor = [245, 158, 11]; // Amber 500
  } else if (analysis.score >= 75) {
    ratingLabel = "CRITICAL RISK (IMPERSONATOR / SPOOFABLE)";
    ratingColor = [239, 68, 68]; // Red 500
  }

  doc.setFont("helvetica", "bold");
  doc.setFontSize(9);
  doc.setTextColor(63, 63, 70); // zinc-600
  doc.text("EXECUTIVE AUDIT CLASSIFICATION:", margin + 5, y + 8);

  doc.setFontSize(11);
  doc.setTextColor(ratingColor[0], ratingColor[1], ratingColor[2]);
  doc.text(`${ratingLabel}   [Score: ${analysis.score}/100]`, margin + 5, y + 15);

  doc.setFont("helvetica", "normal");
  doc.setFontSize(8);
  doc.setTextColor(113, 113, 122);
  doc.text(`ML Predictive Verdict: ${analysis.classification}`, margin + 5, y + 20);
  y += 30;

  // Section 1: Detailed Protocol Specifications
  checkPageOverflow(12);
  doc.setFont("helvetica", "bold");
  doc.setFontSize(10);
  doc.setTextColor(24, 24, 27);
  doc.text("1. REGISTERED PROTOCOL ANALYSIS", margin, y);
  
  doc.setDrawColor(39, 39, 42); // Zinc-800
  doc.setLineWidth(0.4);
  doc.line(margin, y + 2, margin + 45, y + 2);
  y += 7;

  // Protocol details table-like drawing
  const drawProtocolModule = (title: string, status: string, raw: string, details: string[]) => {
    checkPageOverflow(25 + details.length * 5);
    
    // Module title
    doc.setFont("helvetica", "bold");
    doc.setFontSize(9);
    doc.setTextColor(24, 24, 27);
    doc.text(title, margin, y);

    y += 4.5;

    const isPass = status === "Pass";
    const statusCol = isPass ? [16, 185, 129] : [239, 68, 68];
    doc.setFont("helvetica", "bold");
    doc.setFontSize(8);
    doc.setTextColor(statusCol[0], statusCol[1], statusCol[2]);
    doc.text(`[ STATUS: ${isPass ? "ACTIVE / DEPLOYED" : "MISSING OR FAILING"} ]`, margin, y);

    y += 4.5;

    // Raw record codeblock
    doc.setDrawColor(228, 228, 231);
    doc.setFillColor(250, 250, 250);
    
    // Split raw record to wrap nicely
    const rawWrapped = doc.splitTextToSize(raw || "No valid DNS record found in public zone lookups.", contentWidth - 8);
    const boxHeight = Math.max(8, rawWrapped.length * 4.5 + 4);
    
    checkPageOverflow(boxHeight + 10);
    doc.rect(margin, y, contentWidth, boxHeight, "FD");
    
    doc.setFont("courier", "bold");
    doc.setFontSize(7.5);
    doc.setTextColor(39, 39, 42);
    doc.text(rawWrapped, margin + 4, y + 4.5);
    y += boxHeight + 4;

    // Detailed lists
    doc.setFont("helvetica", "normal");
    doc.setFontSize(8);
    doc.setTextColor(82, 82, 91); // zinc-600
    
    details.forEach((pDetail) => {
      checkPageOverflow(6);
      const detailWrapped = doc.splitTextToSize(`• ${pDetail}`, contentWidth - 6);
      doc.text(detailWrapped, margin + 2, y);
      y += detailWrapped.length * 4 + 1;
    });

    y += 5; // spacing
  };

  // SPF Protocol
  drawProtocolModule(
    "Sender Policy Framework (SPF Record)",
    analysis.spf.status,
    analysis.spf.raw,
    analysis.spf.details
  );

  // DKIM Protocol
  drawProtocolModule(
    `DomainKeys Identified Mail (DKIM Record - Key: ${analysis.dkim.selector})`,
    analysis.dkim.status,
    analysis.dkim.raw,
    analysis.dkim.details
  );

  // DMARC Protocol
  drawProtocolModule(
    "Domain Message Authentication Alignment (DMARC Policy)",
    analysis.dmarc.status,
    analysis.dmarc.raw,
    analysis.dmarc.details
  );

  // MX record section
  checkPageOverflow(25);
  doc.setFont("helvetica", "bold");
  doc.setFontSize(9);
  doc.setTextColor(24, 24, 27);
  doc.text("Outbound Mail Exchange (MX Server Routing)", margin, y);
  y += 4;

  if (analysis.mx.hasMx) {
    const mxText = `Domain maps emails to: ${analysis.mx.records.join(", ")}`;
    const mxWrapped = doc.splitTextToSize(mxText, contentWidth - 4);
    doc.setFont("helvetica", "medium");
    doc.setFontSize(8);
    doc.setTextColor(63, 63, 70);
    doc.text(mxWrapped, margin, y);
    y += mxWrapped.length * 4 + 4;
  } else {
    doc.setFont("helvetica", "normal");
    doc.setFontSize(8);
    doc.setTextColor(239, 68, 68);
    doc.text("• WARNING: No valid active MX records found. Outgoing client transmission could fail standard validation checks.", margin, y);
    y += 5;
  }

  // Section 2: Machine Learning Classification Telemetry
  checkPageOverflow(40);
  y += 4;
  doc.setFont("helvetica", "bold");
  doc.setFontSize(10);
  doc.setTextColor(24, 24, 27);
  doc.text("2. COMPILER FEATURE MATRIX & MACHINE LEARNING TELEMETRY", margin, y);
  
  doc.setDrawColor(39, 39, 42);
  doc.setLineWidth(0.4);
  doc.line(margin, y + 2, margin + 98, y + 2);
  y += 7;

  doc.setFont("helvetica", "normal");
  doc.setFontSize(8);
  doc.setTextColor(82, 82, 91);
  doc.text("These parsed binary/discrete feature coordinates align parameters directly into classification decision trees during academic modeling.", margin, y);
  y += 5;

  // Draw ML Features Table
  checkPageOverflow(30);
  const mlBoxWidth = contentWidth / 4;
  const colHeads = ["Feature Identifier", "Value", "Feature Identifier", "Value"];
  
  // Header row
  doc.setFillColor(244, 244, 245); // zinc-100
  doc.rect(margin, y, contentWidth, 6, "F");
  
  doc.setFont("helvetica", "bold");
  doc.setFontSize(7.5);
  doc.setTextColor(39, 39, 42);
  doc.text("Feature Name", margin + 2, y + 4.5);
  doc.text("Vector Value", margin + 45, y + 4.5);
  doc.text("Feature Name", margin + 90, y + 4.5);
  doc.text("Vector Value", margin + 135, y + 4.5);
  y += 6;

  const fList = [
    { name: "spf_present", val: analysis.mlFeatures.spf_present },
    { name: "spf_qualifier_code", val: analysis.mlFeatures.spf_qualifier_code },
    { name: "dkim_present", val: analysis.mlFeatures.dkim_present },
    { name: "dmarc_present", val: analysis.mlFeatures.dmarc_present },
    { name: "dmarc_policy_strength", val: analysis.mlFeatures.dmarc_policy_strength },
    { name: "mx_present", val: analysis.mlFeatures.mx_present },
    { name: "spf_dkim_alignment", val: analysis.mlFeatures.spf_dkim_alignment },
    { name: "calculated_risk_score", val: `${analysis.mlFeatures.calculated_risk_score}%` },
  ];

  // Draw pairs
  for (let i = 0; i < 4; i++) {
    const f1 = fList[i];
    const f2 = fList[i + 4];

    // Zebra striping
    if (i % 2 === 1) {
      doc.setFillColor(250, 250, 250);
      doc.rect(margin, y, contentWidth, 6, "F");
    }

    doc.setFont("courier", "normal");
    doc.setFontSize(7);
    doc.setTextColor(63, 63, 70);
    doc.text(f1.name, margin + 2, y + 4.5);
    doc.text(String(f1.val), margin + 45, y + 4.5);

    doc.text(f2.name, margin + 90, y + 4.5);
    doc.text(String(f2.val), margin + 135, y + 4.5);
    
    // Draw cells lines
    doc.setDrawColor(240, 240, 240);
    doc.setLineWidth(0.1);
    doc.line(margin, y + 6, margin + contentWidth, y + 6);
    y += 6;
  }
  y += 8;

  // Final document save
  const safeFilename = `${analysis.domain.replace(/[^a-z0-9]/gi, "_")}_security_audit_report.pdf`;
  doc.save(safeFilename);
}

export function generateHeaderReport(analysis: HeaderAnalysis) {
  const doc = new jsPDF({
    orientation: "portrait",
    unit: "mm",
    format: "a4",
  });

  const pageWidth = 210;
  const pageHeight = 297;
  const margin = 15;
  const contentWidth = pageWidth - 2 * margin; // 180mm
  let pageNum = 1;
  let y = 22;

  // Header and Footer drawer for subsequent pages
  const drawPageBorderDecoration = (pNum: number) => {
    // Header
    doc.setDrawColor(228, 228, 231); // zinc-200
    doc.setLineWidth(0.2);
    doc.line(margin, 12, pageWidth - margin, 12);

    doc.setFont("helvetica", "normal");
    doc.setFontSize(7.5);
    doc.setTextColor(120, 120, 120);
    doc.text("UNIVERSITY THESIS DELIVERABLE • EMAIL SPOOFING DETECTION SYSTEM", margin, 9);
    doc.text(`REPORT PAGE ${pNum}`, pageWidth - margin, 9, { align: "right" });

    // Footer
    doc.line(margin, pageHeight - 15, pageWidth - margin, pageHeight - 15);
    doc.text(`CONFIDENTIAL VERIFICATION RECORD FOR: ${(analysis.fromDomain || "UNKNOWN").toUpperCase()}`, margin, pageHeight - 10);
    doc.text(`GENERATED: ${new Date().toLocaleString()}`, pageWidth - margin, pageHeight - 10, { align: "right" });
  };

  const checkPageOverflow = (neededHeight: number) => {
    if (y + neededHeight > pageHeight - 20) {
      doc.addPage();
      pageNum++;
      y = 22;
      drawPageBorderDecoration(pageNum);
    }
  };

  // --- INITIAL PAGE ---
  drawPageBorderDecoration(pageNum);

  // Title Box
  doc.setFillColor(24, 24, 27); // Zinc-900 (Dark background)
  doc.rect(margin, y, contentWidth, 24, "F");

  doc.setFont("helvetica", "bold");
  doc.setFontSize(13);
  doc.setTextColor(255, 255, 255);
  doc.text("EMAIL HEADER SECURITY ASSESSMENT REPORT", margin + 6, y + 9);

  doc.setFont("helvetica", "normal");
  doc.setFontSize(8.5);
  doc.setTextColor(161, 161, 170); // Zinc-400
  const subTitleText = `Analyzed Sender: ${analysis.from || "Unknown"}`;
  doc.text(subTitleText, margin + 6, y + 17);
  y += 30;

  // Overview / Status Section
  checkPageOverflow(30);
  doc.setDrawColor(228, 228, 231);
  doc.setFillColor(248, 250, 252); // light slate gray background
  doc.rect(margin, y, contentWidth, 24, "FD");

  // Choose colors dependent on rating
  let ratingLabel = "LOW RISK (SAFE)";
  let ratingColor = [16, 185, 129]; // Emerald 500
  if (analysis.riskLevel === "Suspicious" || (analysis.score > 15 && analysis.score <= 40)) {
    ratingLabel = "MEDIUM RISK (SUSPICIOUS)";
    ratingColor = [245, 158, 11]; // Amber 500
  } else if (analysis.riskLevel === "Spoofed" || analysis.score > 40) {
    ratingLabel = "CRITICAL RISK (SPOOFED / FRAUDULENT)";
    ratingColor = [239, 68, 68]; // Red 500
  }

  doc.setFont("helvetica", "bold");
  doc.setFontSize(9);
  doc.setTextColor(63, 63, 70); // zinc-600
  doc.text("EXECUTIVE AUDIT CLASSIFICATION:", margin + 5, y + 8);

  doc.setFontSize(11);
  doc.setTextColor(ratingColor[0], ratingColor[1], ratingColor[2]);
  doc.text(`${ratingLabel}   [Score: ${analysis.score}/100]`, margin + 5, y + 15);

  doc.setFont("helvetica", "normal");
  doc.setFontSize(8);
  doc.setTextColor(113, 113, 122);
  doc.text(`Threat Level: ${analysis.riskLevel.toUpperCase()}`, margin + 5, y + 20);
  y += 30;

  // Section 1: Parsed Headers Information
  checkPageOverflow(15);
  doc.setFont("helvetica", "bold");
  doc.setFontSize(10);
  doc.setTextColor(24, 24, 27);
  doc.text("1. PARSED ENVELOPE PARAMETERS", margin, y);
  
  doc.setDrawColor(39, 39, 42); // Zinc-800
  doc.setLineWidth(0.4);
  doc.line(margin, y + 2, margin + 45, y + 2);
  y += 7;

  // Header params table
  const drawHeaderParamRow = (label: string, value: string) => {
    checkPageOverflow(10);
    doc.setFont("helvetica", "bold");
    doc.setFontSize(8);
    doc.setTextColor(82, 82, 91);
    doc.text(label, margin + 2, y);

    doc.setFont("courier", "normal");
    doc.setFontSize(8);
    doc.setTextColor(24, 24, 27);
    const valueWrapped = doc.splitTextToSize(value || "NONE", contentWidth - 45);
    doc.text(valueWrapped, margin + 42, y);
    y += valueWrapped.length * 4 + 2;

    // Draw solid subtle divider line
    doc.setDrawColor(240, 240, 240);
    doc.setLineWidth(0.1);
    doc.line(margin, y - 1, margin + contentWidth, y - 1);
  };

  drawHeaderParamRow("From Header:", analysis.from);
  drawHeaderParamRow("From Domain:", analysis.fromDomain);
  drawHeaderParamRow("Return-Path:", analysis.returnPath);
  drawHeaderParamRow("Return-Path Domain:", analysis.returnPathDomain);
  drawHeaderParamRow("Reply-To Resolver:", analysis.replyTo || "Not configured");
  drawHeaderParamRow("Subject Line:", analysis.subject);
  drawHeaderParamRow("Unique Message-ID:", analysis.messageId);

  y += 6;

  // Section 2: Cryptographic Alignment Checks
  checkPageOverflow(15);
  doc.setFont("helvetica", "bold");
  doc.setFontSize(10);
  doc.setTextColor(24, 24, 27);
  doc.text("2. CRYPTOGRAPHIC TRUST VERIFICATIONS", margin, y);
  
  doc.setDrawColor(39, 39, 42); // Zinc-800
  doc.setLineWidth(0.4);
  doc.line(margin, y + 2, margin + 65, y + 2);
  y += 7;

  // Helper for drawing alignment status cards
  const drawAlignmentCard = (label: string, isAligned: boolean, details: string) => {
    checkPageOverflow(30);
    doc.setDrawColor(228, 228, 231);
    doc.setFillColor(250, 250, 250);
    doc.rect(margin, y, contentWidth, 22, "FD");

    doc.setFont("helvetica", "bold");
    doc.setFontSize(8.5);
    doc.setTextColor(82, 82, 91);
    doc.text(label, margin + 4, y + 6);

    const alignmentCol = isAligned ? [16, 185, 129] : [239, 68, 68];
    doc.setFont("helvetica", "bold");
    doc.setFontSize(8.5);
    doc.setTextColor(alignmentCol[0], alignmentCol[1], alignmentCol[2]);
    doc.text(`[ STATUS: ${isAligned ? "ALIGNED PASS" : "ALIGNMENT MISMATCH"} ]`, margin + 115, y + 6);

    y += 10;

    doc.setFont("helvetica", "normal");
    doc.setFontSize(8);
    doc.setTextColor(113, 113, 122);
    const detailText = doc.splitTextToSize(details, contentWidth - 10);
    doc.text(detailText, margin + 4, y);
    y += detailText.length * 4 - 4;

    y += 11; // spacing
  };

  drawAlignmentCard(
    "SPF ALIGNMENT INTEGRITY",
    analysis.spfAligned,
    `Authenticating domain (${analysis.fromDomain || "none"}) comparison against Return-Path domain (${analysis.returnPathDomain || "none"}). Received SPF Status: ${analysis.receivedSpf || "NONE DETECTED"}`
  );

  drawAlignmentCard(
    "CRYPTOGRAPHIC DKIM SIGN ALIGNMENT",
    analysis.dkimAligned,
    `DKIM Sign Header Present: ${analysis.hasDkimHeader ? "YES" : "NO"}. Verification status: ${analysis.dkimStatus || "NOT RUN"}. Matches From field domain: ${analysis.dkimAligned ? "YES" : "NO"}`
  );

  y += 4;

  // Section 3: Detection Signals & Discrepancies reasons
  if (analysis.reasons && analysis.reasons.length > 0) {
    checkPageOverflow(20);
    doc.setFont("helvetica", "bold");
    doc.setFontSize(10);
    doc.setTextColor(24, 24, 27);
    doc.text("3. DETECTION SIGNALS & DISCREPANCY REASONS", margin, y);
    
    doc.setDrawColor(39, 39, 42); // Zinc-800
    doc.setLineWidth(0.4);
    doc.line(margin, y + 2, margin + 70, y + 2);
    y += 7;

    analysis.reasons.forEach((reason) => {
      checkPageOverflow(8);
      doc.setFont("helvetica", "normal");
      doc.setFontSize(8);
      
      const isRedAlert = reason.toLowerCase().includes("fail") || reason.toLowerCase().includes("alert") || reason.toLowerCase().includes("missing");
      const dotCol = isRedAlert ? [239, 68, 68] : [16, 185, 129];
      
      doc.setFillColor(dotCol[0], dotCol[1], dotCol[2]);
      doc.circle(margin + 2.5, y - 1, 1, "F");

      doc.setTextColor(63, 63, 70);
      const reasonWrapped = doc.splitTextToSize(reason, contentWidth - 8);
      doc.text(reasonWrapped, margin + 6, y);
      y += reasonWrapped.length * 4 + 1.5;
    });
  }

  // Final document save
  const safeFilename = `${(analysis.fromDomain || "header_scan").replace(/[^a-z0-9]/gi, "_")}_email_header_report.pdf`;
  doc.save(safeFilename);
}
