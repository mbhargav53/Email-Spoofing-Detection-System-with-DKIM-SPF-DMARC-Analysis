import React, { useState } from "react";
import { Shield, Globe, Mail, Brain, BookOpen, Trash2, Github, Cpu, FileText } from "lucide-react";
import DnsDashboard from "./components/DnsDashboard";
import HeaderAnalyzer from "./components/HeaderAnalyzer";
import MachineLearningHub from "./components/MachineLearningHub";
import AcademicDeliverables from "./components/AcademicDeliverables";
import HistoryLedger from "./components/HistoryLedger";

export default function App() {
  const [activeTab, setActiveTab] = useState<"dns" | "headers" | "ml" | "academic" | "history">("dns");
  const [refreshHistoryTrigger, setRefreshHistoryTrigger] = useState(0);

  const handleScanSuccess = () => {
    setRefreshHistoryTrigger((prev) => prev + 1);
  };

  return (
    <div className="min-h-screen animate-sliding-bg text-zinc-200 flex flex-col font-sans relative overflow-x-hidden" id="app-root">
      
      {/* Drifting Background Ambient Theme Orbs */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden z-0" id="ambient-theme-orbs">
        <div className="absolute top-[5%] left-[10%] w-[35vw] h-[35vw] max-w-[450px] max-h-[450px] rounded-full bg-indigo-500/[0.05] blur-[100px] animate-float-slow" />
        <div className="absolute bottom-[15%] right-[10%] w-[45vw] h-[45vw] max-w-[550px] max-h-[550px] rounded-full bg-purple-500/[0.04] blur-[120px] animate-float-medium" />
        <div className="absolute top-[45%] right-[25%] w-[30vw] h-[30vw] max-w-[380px] max-h-[380px] rounded-full bg-emerald-500/[0.02] blur-[90px] animate-float-slow" style={{ animationDelay: "-8s" }} />
      </div>

      {/* GLORIOUS BENTO GRID CYBERSECURITY SYSTEM HEADER */}
      <header className="bg-zinc-950/40 backdrop-blur-md border-b border-zinc-800/60 py-5 px-6 shrink-0 relative z-10 animate-entrance" id="main-header">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          
          {/* Title & Badge */}
          <div className="flex items-center gap-3">
            <div className="p-3 bg-zinc-900/80 border border-zinc-800 rounded-xl">
              <Shield className="w-7 h-7 text-indigo-400 rotate-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-2xl font-bold tracking-tight text-white font-sans">
                  Email Spoofing Detection & Analysis System
                </h1>
                <span className="px-2 py-0.5 bg-zinc-900/60 border border-zinc-800 text-zinc-400 text-[10px] font-mono uppercase rounded tracking-wider">
                  B.Tech Project
                </span>
              </div>
              <p className="text-xs text-zinc-500 mt-1 font-sans">
                Advanced SPF, DKIM, and DMARC Analysis
              </p>
            </div>
          </div>

          {/* Active status pulse and Metadata */}
          <div className="flex flex-wrap items-center gap-4">
            <div className="flex items-center gap-2 bg-zinc-900/65 border border-zinc-800 px-3 py-1.5 rounded-lg">
              <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></div>
              <span className="text-[10px] font-mono tracking-wider text-zinc-300">SCANNER ACTIVE</span>
            </div>

            {/* Supervisor / Author Credits */}
            <div className="text-xxs text-left bg-zinc-900/50 p-2.5 rounded-lg border border-zinc-800 space-y-0.5 font-mono">
              <div><span className="text-zinc-500">Student Name:</span> <strong className="text-zinc-300">M Bhargav</strong></div>
              <div><span className="text-zinc-500">Student ID:</span> <strong className="text-zinc-300">2200039111</strong></div>
              <div><span className="text-zinc-500">Department:</span> <strong className="text-zinc-300">CSE</strong></div>
              <div><span className="text-zinc-500">Batch No:</span> <strong className="text-zinc-300">333</strong></div>
              <div><span className="text-zinc-500">Project guide:</span> <strong className="text-zinc-300">V Chandra Prakash Sir</strong></div>
              <div><span className="text-zinc-500">college:</span> <strong className="text-zinc-300">KL University</strong></div>
            </div>
          </div>
        </div>
      </header>

      {/* CORE FRAMEWORK WORKSPACE */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 md:p-6 grid grid-cols-1 lg:grid-cols-4 gap-6 items-start relative z-10 animate-entrance animation-delay-75" id="main-workspace-container">
        
        {/* SIDE BAR NAVIGATION styled as a Bento Card */}
        <aside className="bg-zinc-900/50 border border-zinc-800 rounded-xl p-4 lg:col-span-1 space-y-4 shadow-sm animate-entrance animation-delay-150" id="navigation-sidebar">
          <span className="text-[10px] uppercase tracking-widest text-zinc-500 font-bold block pl-2">Defensive Modules</span>
          
          <nav className="space-y-1">
            {[
              { id: "dns", label: "DNS Security Scan", icon: Globe, desc: "Audits live domain TXT registers" },
              { id: "headers", label: "Header Verification", icon: Mail, desc: "Reviews RFC alignment checks" },
              { id: "ml", label: "Classification Verdict", icon: Brain, desc: "Simulates classification vectors" },
              { id: "academic", label: "Submission Hub", icon: BookOpen, desc: "Spring Boot, MySQL & UML files" },
              { id: "history", label: "Scan History Ledger", icon: Cpu, desc: "Review past session caches" },
            ].map((tab) => {
              const Icon = tab.icon;
              return (
                <button
                  id={`tab-nav-${tab.id}`}
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id as any)}
                  className={`w-full flex items-start gap-3 p-3 rounded-lg text-left transition duration-150 ${
                    activeTab === tab.id
                      ? "bg-zinc-100 text-zinc-950 font-bold shadow-md"
                      : "text-zinc-400 hover:text-zinc-200 hover:bg-zinc-900/40"
                  }`}
                >
                  <Icon className="w-5 h-5 mt-0.5 shrink-0" />
                  <div>
                    <span className="text-xs font-semibold block">{tab.label}</span>
                    <span className="text-[10px] block opacity-75 mt-0.5 leading-none">{tab.desc}</span>
                  </div>
                </button>
              );
            })}
          </nav>

          {/* Academic Notes Indicator */}
          <div className="p-3.5 bg-zinc-950 border border-zinc-800 rounded-lg space-y-1">
            <span className="text-xxs font-bold text-zinc-400 uppercase tracking-widest block">Viva Note</span>
            <p className="text-[11px] text-zinc-500 leading-relaxed font-sans">
              All SPF, DKIM, and DMARC analyses perform live DNS Queries server-side. Real-world testing can be initiated using standard corporate domain selectors.
            </p>
          </div>
        </aside>

        {/* PRIMARY ACTIVE CONTEXT BLOCK */}
        <section className="lg:col-span-3 space-y-6 animate-entrance animation-delay-225" id="primary-content-block">
          
          {/* Active module view router */}
          {activeTab === "dns" && <DnsDashboard onScanSuccess={handleScanSuccess} />}
          {activeTab === "headers" && <HeaderAnalyzer onScanSuccess={handleScanSuccess} />}
          {activeTab === "ml" && <MachineLearningHub />}
          {activeTab === "academic" && <AcademicDeliverables />}
          {activeTab === "history" && <HistoryLedger refreshTrigger={refreshHistoryTrigger} />}

        </section>
      </main>

      {/* FOOTER */}
      <footer className="bg-zinc-900/20 border-t border-zinc-800/80 py-4 px-6 text-zinc-600 text-xs mt-auto shrink-0 relative z-10" id="main-footer">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-3 text-[10px] uppercase tracking-widest">
          <div className="flex gap-6 font-bold text-zinc-500">
            <span onClick={() => setActiveTab("dns")} className="cursor-pointer hover:text-white transition">Dashboard</span>
            <span onClick={() => setActiveTab("history")} className="cursor-pointer hover:text-white transition">Scan History</span>
            <span onClick={() => setActiveTab("ml")} className="cursor-pointer hover:text-white transition">Classification Verdict</span>
            <span onClick={() => setActiveTab("academic")} className="cursor-pointer hover:text-white transition">Report Export</span>
          </div>
          <div className="flex gap-4 font-mono">
            <span>SECURE ENGINE: ALPHA-7</span>
            <span>NODE-ID: NYC-04</span>
          </div>
        </div>
      </footer>

    </div>
  );
}
