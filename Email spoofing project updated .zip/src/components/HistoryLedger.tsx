import React, { useState, useEffect } from "react";
import { History, Trash2, Calendar, FileText, AlertCircle, RefreshCw } from "lucide-react";
import { ScanItem } from "../types";
import { generateDomainReport, generateHeaderReport } from "../utils/pdfGenerator";

interface HistoryLedgerProps {
  refreshTrigger: number;
}

export default function HistoryLedger({ refreshTrigger }: HistoryLedgerProps) {
  const [history, setHistory] = useState<ScanItem[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const fetchHistory = async () => {
    setLoading(true);
    try {
      const response = await fetch("/api/history");
      const data = await response.json();
      if (!response.ok) throw new Error("Failed to load history.");
      setHistory(data.history || []);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchHistory();
  }, [refreshTrigger]);

  const handleDelete = async (id: string) => {
    try {
      const response = await fetch(`/api/history/${id}`, { method: "DELETE" });
      const data = await response.json();
      if (!response.ok) throw new Error("Deletion failed.");
      setHistory(history.filter(item => item.id !== id));
    } catch (e: any) {
      alert("Error deleting record");
    }
  };

  const clearAll = async () => {
    if (!confirm("Are you sure you want to clear your entire scan history?")) return;
    try {
      const response = await fetch("/api/history/clear", { method: "POST" });
      if (response.ok) {
        setHistory([]);
      }
    } catch (e: any) {
      alert("Error clearing history");
    }
  };

  const getScoreBadgeColor = (score: number) => {
    if (score < 35) return "bg-zinc-950 text-emerald-400 border border-zinc-800";
    if (score < 75) return "bg-zinc-950 text-amber-400 border border-zinc-800";
    return "bg-zinc-950 text-red-500 border border-zinc-800 animate-pulse";
  };

  return (
    <div className="bg-zinc-900/50 border border-zinc-800 rounded-xl p-6 space-y-4 shadow-sm animate-fade-in" id="history-ledger-root">
      <div className="flex items-center justify-between">
        <h2 className="text-lg font-bold text-white flex items-center gap-2">
          <History className="w-4 h-4 text-zinc-400" />
          Durable Cryptographic Scan History
        </h2>
        
        <div className="flex gap-2">
          <button
            onClick={fetchHistory}
            className="p-1.5 bg-zinc-950 border border-zinc-800 text-zinc-400 hover:text-white rounded transition"
            title="Refresh logs"
          >
            <RefreshCw className="w-3.5 h-3.5" />
          </button>
          
          {history.length > 0 && (
            <button
              onClick={clearAll}
              className="px-3 py-1.5 bg-red-950/20 hover:bg-red-900/20 text-red-400 border border-red-900/30 text-xs font-bold font-mono rounded transition flex items-center gap-1.5"
            >
              <Trash2 className="w-3.5 h-3.5" />
              CLEAR ALL
            </button>
          )}
        </div>
      </div>

      <p className="text-xs text-zinc-400 leading-relaxed font-sans">
        Locally cached database indexing previous audits. Scan histories allow cybersecurity engineers to observe drift in domain validation records and maintain persistent records.
      </p>

      {loading && history.length === 0 ? (
        <div className="py-8 text-center text-zinc-500 text-xs font-mono">
          SYNCING RECORDS WITH SERVER...
        </div>
      ) : error ? (
        <div className="p-3 bg-red-950/20 text-red-400 rounded text-xs flex items-center gap-2 font-mono">
          <AlertCircle className="w-4 h-4" />
          Error matching records: {error}
        </div>
      ) : history.length === 0 ? (
        <div className="py-12 border border-dashed border-zinc-800 rounded-lg text-center bg-zinc-900/10">
          <History className="w-8 h-8 text-zinc-600 mx-auto mb-2" />
          <p className="text-zinc-500 text-xs font-sans">No active scan logs found. Run a domain security audit or inspect headers to populate the history ledger.</p>
        </div>
      ) : (
        <div className="space-y-3 max-h-96 overflow-y-auto pr-1">
          {history.map((scan) => (
            <div 
              key={scan.id} 
              className="p-4 bg-zinc-950 border border-zinc-800 rounded-xl flex items-center justify-between hover:border-zinc-700 transition duration-150"
            >
              <div className="space-y-1.5 flex-1 min-w-0 pr-4">
                <div className="flex items-center gap-2 flex-wrap">
                  <span className={`px-2 py-0.5 rounded text-[9px] font-bold font-mono tracking-wider ${
                    scan.type === "domain" ? "bg-zinc-900 text-zinc-300 border border-zinc-800" : "bg-zinc-900 text-zinc-400 border border-zinc-800"
                  }`}>
                    {scan.type === "domain" ? "DOMAIN ANALYSIS" : "HEADER SCAN"}
                  </span>
                  <span className="font-bold text-white text-xs truncate max-w-xs font-mono">{scan.target}</span>
                </div>

                <div className="flex items-center gap-3 text-[10px] text-zinc-500 font-medium">
                  <span className="flex items-center gap-1 font-mono">
                    <Calendar className="w-3 h-3 text-zinc-600" />
                    {new Date(scan.timestamp).toLocaleString()}
                  </span>
                  <span>| Verdict: <strong className="text-zinc-400 font-mono">{scan.classification}</strong></span>
                </div>
              </div>

              <div className="flex items-center gap-3">
                <span className={`px-2.5 py-1 text-xs font-mono font-bold rounded ${getScoreBadgeColor(scan.score)}`}>
                  Score: {scan.score}%
                </span>

                {scan.type === "domain" && (
                  <button
                    onClick={() => generateDomainReport(scan.data)}
                    className="p-1.5 text-zinc-400 hover:text-white hover:bg-zinc-800 rounded transition cursor-pointer"
                    title="Download Report PDF"
                  >
                    <FileText className="w-3.5 h-3.5" />
                  </button>
                )}

                {scan.type === "header" && (
                  <button
                    onClick={() => generateHeaderReport(scan.data)}
                    className="p-1.5 text-zinc-400 hover:text-white hover:bg-zinc-800 rounded transition cursor-pointer"
                    title="Download Header Report PDF"
                  >
                    <FileText className="w-3.5 h-3.5" />
                  </button>
                )}

                <button
                  onClick={() => handleDelete(scan.id)}
                  className="p-1.5 text-zinc-500 hover:text-red-400 hover:bg-red-950/20 rounded transition cursor-pointer"
                  title="Remove record"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
