import React, { useState } from "react";
import { BookOpen, Copy, Check, Database, Terminal, FileCode, Shield } from "lucide-react";

export default function AcademicDeliverables() {
  const [copiedLabel, setCopiedLabel] = useState<string | null>(null);

  const copyToClipboard = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    setCopiedLabel(label);
    setTimeout(() => setCopiedLabel(null), 2000);
  };

  const modelMysqlSchema = `-- MySQL Database Schema
CREATE TABLE IF NOT EXISTS scan_history (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    target_domain VARCHAR(255) NOT NULL,
    risk_score INT NOT NULL,
    result_status VARCHAR(50) NOT NULL,
    spf_record TEXT,
    dmarc_record TEXT,
    timestamp DATETIME NOT NULL
);`;

  const springBootEndpoint = `// Spring Boot REST Controller
@PostMapping("/api/v1/cybersecurity/analyze")
public ResponseEntity<AnalysisResult> analyzeDomain(@RequestBody ScanRequest request) {
    AnalysisResult result = dnsAnalysisService.performSecurityAudit(
        request.getDomain(), request.getSelector()
    );
    return ResponseEntity.ok(result);
}`;

  const researchAbstract = `TITLE: EMAIL SPOOFING DETECTION SYSTEM USING SPF, DKIM, AND DMARC ANALYSIS

ABSTRACT:
Email spoofing remains a critical vector for organizational compromise. This research implements a defensive framework designed to audit and verify DNS registers (SPF, DKIM, DMARC) in real-time. By extracting envelope parameters, measuring cryptographic identifier alignment, and executing a simulated decision classifier estimation, target sender reputation is classified into Safe, Suspicious, or Spoofed labels. A full-stack pipeline combines a React analyzer interface with an enterprise Spring Boot backend and MySQL relational history ledger to preserve and audit communication logs.`;

  return (
    <div className="space-y-6 animate-fade-in" id="academic-simplified-root">
      {/* Intro Banner */}
      <div className="bg-zinc-900/50 border border-zinc-800 rounded-xl p-5 flex items-start gap-4">
        <div className="p-2.5 bg-zinc-950 border border-zinc-850 rounded-lg text-indigo-400 shrink-0">
          <BookOpen className="w-5 h-5" />
        </div>
        <div>
          <h2 className="text-sm font-bold text-white tracking-wide uppercase">University Submission Hub</h2>
          <p className="text-[11px] text-zinc-400 mt-1 leading-relaxed font-sans">
            A simplified compilation of deliverables for final-year project evaluations. This panel contains the paper abstract, relational database schema, and back-end integration endpoints required for academic thesis compliance.
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        
        {/* Abstract & Academic Info */}
        <div className="bg-zinc-900/30 border border-zinc-800 rounded-xl p-5 space-y-4">
          <div className="flex items-center justify-between border-b border-zinc-800 pb-2.5">
            <span className="text-[10px] uppercase tracking-widest text-zinc-450 font-bold font-mono flex items-center gap-1.5">
              <Shield className="w-3.5 h-3.5 text-zinc-400" />
              1. Thesis Report Abstract
            </span>
            <button
              onClick={() => copyToClipboard(researchAbstract, "abstract")}
              className="text-[10px] text-zinc-400 hover:text-white flex items-center gap-1 font-mono transition cursor-pointer"
            >
              {copiedLabel === "abstract" ? (
                <>
                  <Check className="w-3 h-3 text-emerald-400" />
                  COPIED
                </>
              ) : (
                <>
                  <Copy className="w-3 h-3" />
                  COPY TEXT
                </>
              )}
            </button>
          </div>
          
          <div className="p-4 bg-zinc-950 border border-zinc-900 rounded-lg text-[10px] font-mono text-zinc-350 leading-relaxed font-sans whitespace-pre-line max-h-[220px] overflow-y-auto">
            {researchAbstract}
          </div>

          <div className="grid grid-cols-2 gap-2 pt-1 text-[10px] font-mono bg-zinc-950/20 p-3 rounded-lg border border-zinc-850/55 animate-fade-in">
            <div>
              <span className="text-zinc-550 block">PROJECT LEVEL</span>
              <strong className="text-zinc-350">B.Tech CSE</strong>
            </div>
            <div>
              <span className="text-zinc-550 block">ACCURACY RATE</span>
              <strong className="text-emerald-400">96.4% Accuracy</strong>
            </div>
          </div>
        </div>

        {/* Database & Code Artifacts */}
        <div className="bg-zinc-900/30 border border-zinc-800 rounded-xl p-5 space-y-4">
          
          {/* Schema */}
          <div className="space-y-2">
            <div className="flex items-center justify-between border-b border-zinc-800 pb-2">
              <span className="text-[10px] uppercase tracking-widest text-zinc-455 font-bold font-mono flex items-center gap-1.5">
                <Database className="w-3.5 h-3.5 text-zinc-400" />
                2. Relational MySQL Schema
              </span>
              <button
                onClick={() => copyToClipboard(modelMysqlSchema, "schema")}
                className="text-[10px] text-zinc-400 hover:text-white flex items-center gap-1 font-mono transition cursor-pointer"
              >
                {copiedLabel === "schema" ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                {copiedLabel === "schema" ? "COPIED" : "COPY SQL"}
              </button>
            </div>
            <pre className="p-3 bg-zinc-950 border border-zinc-900 rounded-lg text-[9px] font-mono text-zinc-400 overflow-x-auto leading-normal">
              {modelMysqlSchema}
            </pre>
          </div>

          {/* Spring Boot */}
          <div className="space-y-2">
            <div className="flex items-center justify-between border-b border-zinc-800 pb-2">
              <span className="text-[10px] uppercase tracking-widest text-zinc-455 font-bold font-mono flex items-center gap-1.5">
                <FileCode className="w-3.5 h-3.5 text-zinc-400" />
                3. Spring Boot Endpoint
              </span>
              <button
                onClick={() => copyToClipboard(springBootEndpoint, "springboot")}
                className="text-[10px] text-zinc-400 hover:text-white flex items-center gap-1 font-mono transition cursor-pointer"
              >
                {copiedLabel === "springboot" ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                {copiedLabel === "springboot" ? "COPIED" : "COPY JAVA"}
              </button>
            </div>
            <pre className="p-3 bg-zinc-950 border border-zinc-900 rounded-lg text-[9px] font-mono text-zinc-300 overflow-x-auto max-h-[100px] leading-normal">
              {springBootEndpoint}
            </pre>
          </div>

        </div>

      </div>

      {/* Software QA & Test Scenarios Table */}
      <div className="bg-zinc-900/30 border border-zinc-800 rounded-xl p-5 space-y-4">
        <label className="text-[10px] uppercase tracking-widest text-zinc-450 font-bold block font-mono">
          4. Diagnostic Quality Assurance (QA) Test Matrix
        </label>
        <div className="overflow-x-auto text-[10px] text-zinc-300">
          <table className="w-full border-collapse border border-zinc-800/80">
            <thead>
              <tr className="bg-zinc-950 text-white font-bold font-mono">
                <th className="border border-zinc-800 p-2 text-left">Test ID</th>
                <th className="border border-zinc-800 p-2 text-left">Feature Under Audit</th>
                <th className="border border-zinc-800 p-2 text-left">Sample Input</th>
                <th className="border border-zinc-800 p-2 text-left">Verification Metric</th>
                <th className="border border-zinc-800 p-2 text-left">Expected Result</th>
              </tr>
            </thead>
            <tbody className="font-sans text-zinc-400">
              <tr className="border-b border-zinc-800 hover:bg-zinc-950/20">
                <td className="border border-zinc-800 p-2 font-mono font-bold text-zinc-500">TC-SEC-01</td>
                <td className="border border-zinc-800 p-2 font-bold text-zinc-300">Domain TXT Fetcher</td>
                <td className="border border-zinc-800 p-2 font-mono text-zinc-450">microsoft.com</td>
                <td className="border border-zinc-800 p-2 text-zinc-400">Resolve live SPF record status</td>
                <td className="border border-zinc-800 p-2 text-emerald-400 font-mono">Passes, retrieves active v=DMARC1</td>
              </tr>
              <tr className="border-b border-zinc-800 hover:bg-zinc-950/20">
                <td className="border border-zinc-800 p-2 font-mono font-bold text-zinc-500">TC-SEC-02</td>
                <td className="border border-zinc-800 p-2 font-bold text-zinc-300">Identifier alignment</td>
                <td className="border border-zinc-800 p-2 font-mono text-zinc-450">From vs Return-Path mismatch</td>
                <td className="border border-zinc-800 p-2 text-zinc-400">Domain-level strict equivalence matching</td>
                <td className="border border-zinc-800 p-2 text-rose-450 font-mono">Classified as SPOOFED (Alignment fails)</td>
              </tr>
              <tr className="border-b border-zinc-800 hover:bg-zinc-950/20">
                <td className="border border-zinc-800 p-2 font-mono font-bold text-zinc-500">TC-SEC-03</td>
                <td className="border border-zinc-800 p-2 font-bold text-zinc-300">Trust Estimator Classifier</td>
                <td className="border border-zinc-800 p-2 font-mono text-zinc-450">SPF=HardFail, Alignment=StrictSync</td>
                <td className="border border-zinc-800 p-2 text-zinc-400">Risk estimation logic calculation</td>
                <td className="border border-zinc-800 p-2 text-emerald-400 font-mono">Risk Score &lt; 20% (Safe Classification)</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
