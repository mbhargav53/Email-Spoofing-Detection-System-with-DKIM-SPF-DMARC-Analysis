import React, { useState } from "react";
import { Mail, ShieldAlert, ShieldCheck, Sparkles, AlertTriangle, Loader2, Copy, FileText, Check } from "lucide-react";
import { HeaderAnalysis } from "../types";
import { generateHeaderReport } from "../utils/pdfGenerator";

const SAMPLE_SECURE_HEADER = `Delivered-To: testuser@college.edu
Received: by 2002:a05:6a10:ab05:b0:53e:ce84:f167 with SMTP id s5csp1148721pxy;
        Thu, 11 Jun 2026 04:15:22 -0700 (PDT)
X-Google-Smtp-Source: AGHTonfIeNoeD8z9U9K8hS70V/kNo66KzE7fWmxo3H4=
X-Received: by 2002:a17:902:cc0c:b0:1f0:92e0:10ec with SMTP id r12mr2931481plg.0;
        Thu, 11 Jun 2026 04:15:22 -0700 (PDT)
ARC-Seal: i=1; a=rsa-sha256; t=1614214; cv=none; d=google.com;
ARC-Message-Signature: i=1; a=rsa-sha256; c=relaxed/relaxed; d=google.com;
Return-Path: <security@paypal.com>
Received: from mail-send.paypal.com (mail-send.paypal.com. [173.224.12.11])
        by mx.google.com with ESMTPS id o10si4582846plq.349.2023.06.10.14.05.00
        for <testuser@college.edu>;
        Thu, 11 Jun 2026 04:15:21 -0700 (PDT)
Received-SPF: pass (google.com: domain of security@paypal.com designates 173.224.12.11 as permitted sender) client-ip=173.224.12.11;
DKIM-Signature: v=1; a=rsa-sha256; c=relaxed/relaxed; d=paypal.com; s=s2023; h=from:to:subject:message-id:date; bh=abc123DxFgHz=; b=YtWqePvO...
From: "PayPal Security" <security@paypal.com>
To: <testuser@college.edu>
Subject: Security Verification Alert - Critical Update
Message-ID: <msgid-29410192410-paypal@paypal.com>
Date: Thu, 11 Jun 2026 11:15:10 +0000
Content-Type: text/html; charset="UTF-8"`;

const SAMPLE_SPOOFED_HEADER = `Delivered-To: targetvictim@corporate.com
Received: by 2002:a02:ab05:1204:b0:1f2:92e0:10ec with SMTP id p5mr293148plg.0;
        Thu, 11 Jun 2026 08:30:11 -0700 (PDT)
Return-Path: <attacker@spoofdns-malicious-node.xyz>
Received: from smtp-attacker-server.xyz (smtp-attacker-server.xyz. [45.132.89.20])
        by mx.google.com with ESMTPS id o10si4582846plq.349
        for <targetvictim@corporate.com>;
        Thu, 11 Jun 2026 08:30:10 -0700 (PDT)
Received-SPF: softfail (google.com: domain of transition attacker@spoofdns-malicious-node.xyz does not designate 45.132.89.20 as permitted sender)
DKIM-Signature: v=1; a=rsa-sha256; c=relaxed/relaxed; d=spoofdns-malicious-node.xyz; s=vulnerable-key; h=from:to:subject;
From: "Corporate IT Support Helpline" <itsupport@corporate.com>
Reply-To: <itsupport-resolver-service@phish-node.net>
To: <targetvictim@corporate.com>
Subject: Action Required: Mandatory Server Password Reset Now
Message-ID: <9241-7510-it-admin@corporate.com>`;

interface HeaderAnalyzerProps {
  onScanSuccess: () => void;
}

export default function HeaderAnalyzer({ onScanSuccess }: HeaderAnalyzerProps) {
  const [headersText, setHeadersText] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<HeaderAnalysis | null>(null);
  
  const [scanProgress, setScanProgress] = useState(0);
  const [activeLog, setActiveLog] = useState("Awaiting MIME header input stream...");

  const handleAnalyze = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!headersText.trim()) return;

    setLoading(true);
    setError(null);
    setResult(null);
    setScanProgress(0);
    setActiveLog("Activating MIME header lexer...");

    let progress = 0;
    let pendingResult: HeaderAnalysis | null = null;
    let apiError: string | null = null;
    let isFetchFinished = false;

    // Start progress simulator
    const progressInterval = setInterval(() => {
      progress += Math.floor(Math.random() * 8) + 4;
      
      if (progress >= 100) {
        progress = 100;
        setScanProgress(100);
        
        // Check if fetch is done
        if (isFetchFinished) {
          clearInterval(progressInterval);
          setLoading(false);
          if (apiError) {
            setError(apiError);
          } else if (pendingResult) {
            setResult(pendingResult);
            onScanSuccess();
          }
        } else {
          // If fetch isn't finished yet, clamp at 99%
          progress = 99;
          setScanProgress(99);
          setActiveLog("Consolidating response payloads...");
        }
        return;
      }

      setScanProgress(progress);
        
      // Log updates based on progress percentage
      if (progress < 25) {
        setActiveLog("MIME_LEXER: Initializing lexical parser stream...");
      } else if (progress < 50) {
        setActiveLog("ENVELOPE: Auditing Return-Path address authenticity...");
      } else if (progress < 75) {
        setActiveLog("FROM_CHECK: Correlating display address with envelope origin...");
      } else {
        setActiveLog("DKIM_SIG: Verifying integrity signature hashes...");
      }
    }, 80);

    try {
      const response = await fetch("/api/analyze-headers", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ headersText }),
      });

      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "Failed to parse headers.");
      pendingResult = data.findings;
    } catch (err: any) {
      apiError = err.message || "An unexpected parser error occurred.";
    } finally {
      isFetchFinished = true;
      // If progress is already at 99 or 100, let's trigger completion!
      if (progress >= 99) {
        clearInterval(progressInterval);
        setScanProgress(100);
        setLoading(false);
        if (apiError) {
          setError(apiError);
        } else if (pendingResult) {
          setResult(pendingResult);
          onScanSuccess();
        }
      }
    }
  };

  const loadSample = (sample: string) => {
    setHeadersText(sample);
    setError(null);
    setResult(null);
  };



  const getRiskColor = (level: string) => {
    switch (level?.toLowerCase()) {
      case "safe":
        return { text: "text-emerald-400", bg: "bg-emerald-950/20", border: "border-emerald-900/30", label: "SAFE LEGITIMATE EMAIL" };
      case "suspicious":
        return { text: "text-amber-400", bg: "bg-amber-950/20", border: "border-amber-900/30", label: "SUSPICIOUS FLAG" };
      default:
        return { text: "text-rose-400", bg: "bg-rose-950/20", border: "border-rose-900/30", label: "SPOOFED / MALICIOUS ATTACK" };
    }
  };

  const riskDetails = result ? getRiskColor(result.riskLevel) : { text: "text-slate-400", bg: "bg-slate-900", border: "border-slate-800", label: "" };

  return (
    <div className="space-y-6 animate-fade-in" id="header-analyzer-root">
      {/* Intro Header */}
      <div className="bg-zinc-900/50 border border-zinc-800 rounded-xl p-6 shadow-sm">
        <h2 className="text-lg font-bold text-white flex items-center gap-2">
          <Mail className="w-4 h-4 text-zinc-400" />
          Email RFC Header Spoofing Detector
        </h2>
        <p className="text-xs text-zinc-400 mt-2 leading-relaxed">
          Paste MIME e-mail structural headers to verify alignment safety. The parsing daemon reviews the internal <strong className="text-zinc-300">Return-Path</strong>, compares it against the display <strong className="text-zinc-300">From</strong> address, extracts auxiliary hops, evaluates DKIM signature tags, and flags discrepancy attack patterns.
        </p>

        {/* Form */}
        <form onSubmit={handleAnalyze} className="mt-5 space-y-4">
          <div>
            <div className="flex justify-between items-center mb-1.5 flex-wrap gap-2">
              <label className="block text-[10px] uppercase tracking-widest text-zinc-500 font-bold">Paste Raw Headers Text</label>
              
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => loadSample(SAMPLE_SECURE_HEADER)}
                  className="px-2.5 py-1 bg-zinc-950 border border-zinc-800 rounded text-[10px] text-emerald-400 hover:bg-zinc-900 transition font-mono font-bold"
                >
                  LOAD SECURE SAMPLE
                </button>
                <button
                  type="button"
                  onClick={() => loadSample(SAMPLE_SPOOFED_HEADER)}
                  className="px-2.5 py-1 bg-zinc-950 border border-zinc-800 rounded text-[10px] text-red-400 hover:bg-zinc-900 transition font-mono font-bold"
                >
                  LOAD SPOOF SAMPLE
                </button>
              </div>
            </div>

            <textarea
              id="raw-headers-textarea"
              rows={10}
              value={headersText}
              onChange={(e) => setHeadersText(e.target.value)}
              placeholder="Paste RFC 5322 header block here... (To get headers in Gmail: Click 'More' (three dots) -> 'Show original' and copy-paste)"
              className="w-full bg-zinc-950 border border-zinc-800 rounded-lg p-3.5 text-xs text-white placeholder-zinc-650 font-mono focus:outline-none focus:border-zinc-700 block leading-normal"
              required
            />
          </div>

          <div className="flex justify-end">
            <button
              id="submit-header-analyzer-btn"
              type="submit"
              disabled={loading}
              className="px-5 py-2 bg-zinc-100 text-zinc-950 hover:bg-zinc-200 text-xs font-bold rounded transition duration-150 flex items-center gap-2 disabled:opacity-50 font-mono tracking-wider"
            >
              {loading ? (
                <>
                  <Loader2 className="w-3.5 h-3.5 animate-spin" />
                  ANALYZING HEADERS...
                </>
              ) : (
                <>
                  <Mail className="w-3.5 h-3.5" />
                  VERIFY HEADER METRICS
                </>
              )}
            </button>
          </div>
        </form>

        {error && (
          <div className="mt-4 p-4 bg-red-500/5 border border-red-500/20 text-red-00 rounded-lg text-xs flex items-start gap-2.5" id="header-analysis-error-banner">
            <AlertTriangle className="w-4 h-4 text-red-500 shrink-0 mt-0.5" />
            <div>
              <span className="font-bold">Parsing Issue:</span> {error}. Please ensure the string consists of standard text lines key/value pairs delineated by colons.
            </div>
          </div>
        )}
      </div>

      {loading && (
        <div className="bg-zinc-900/50 border border-indigo-500/20 rounded-xl p-6 shadow-sm animate-entrance space-y-6" id="header-scanning-diagnostic-box">
          {/* Header block with animation */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="relative flex items-center justify-center">
                <span className="absolute inline-flex h-6 w-6 rounded-full bg-indigo-500/15 animate-radar"></span>
                <span className="relative inline-flex rounded-full h-3.5 w-3.5 bg-indigo-500"></span>
              </div>
              <div>
                <h3 className="text-xs font-bold text-white uppercase tracking-wider font-mono">
                  ACTIVE PACKET ANALYSIS UNDERWAY
                </h3>
                <span className="text-[10px] text-zinc-500 font-mono">MIME Header Lexer active • Parsing envelope paths</span>
              </div>
            </div>
            
            <div className="text-right">
              <span className="text-sm font-black font-mono text-indigo-400">{scanProgress}%</span>
            </div>
          </div>

          {/* Progress bar */}
          <div className="w-full bg-zinc-950 h-3 rounded-full border border-zinc-850 overflow-hidden relative p-0.5">
            <div 
              className="bg-indigo-500 h-full rounded-full transition-all duration-150 relative overflow-hidden" 
              style={{ width: `${scanProgress}%` }}
            >
              <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent animate-pulse" />
            </div>
          </div>

          {/* Scrolling diagnostic output screen */}
          <div className="bg-zinc-950 p-4 rounded-lg border border-zinc-850/80 font-mono text-[10px] space-y-2 select-none relative overflow-hidden">
            
            {/* Terminal Grid Background lines */}
            <div className="space-y-1.5 text-zinc-400">
              <div className="flex gap-2">
                <span className="text-zinc-650">[0.000s]</span>
                <span className="text-zinc-500">MIME_INIT: Active scanner thread listening for Raw SMTP logs...</span>
              </div>
              <div className="flex gap-2">
                <span className="text-zinc-650">[0.120s]</span>
                <span className="text-indigo-450">REGEX_AUDIT: Splitting headers into structured token maps... [SUCCESS]</span>
              </div>
              
              {scanProgress >= 25 && (
                <div className="flex gap-2 animate-entrance">
                  <span className="text-zinc-650">[0.380s]</span>
                  <span className="text-emerald-400">ENVELOPE_CHECK: Inspecting RFC 5321 'Return-Path' for spoofs...</span>
                </div>
              )}

              {scanProgress >= 50 && (
                <div className="flex gap-2 animate-entrance">
                  <span className="text-zinc-650">[0.720s]</span>
                  <span className="text-emerald-400">ALIGNMENT_CHECK: Evaluating DISPLAY 'From' vs Sender Domain indices...</span>
                </div>
              )}

              {scanProgress >= 75 && (
                <div className="flex gap-2 animate-entrance">
                  <span className="text-zinc-650">[1.100s]</span>
                  <span className="text-amber-400">DKIM_HEADER: Isolating signature selector tags and cryptographic bits...</span>
                </div>
              )}

              {scanProgress >= 90 && (
                <div className="flex gap-2 animate-entrance font-bold text-indigo-300">
                  <span className="text-zinc-650">[1.420s]</span>
                  <span>HEURISTICS: Processing threat evaluation metrics... [SAFE]</span>
                </div>
              )}
            </div>

            {/* Current rolling status line flashing */}
            <div className="pt-2 border-t border-zinc-900 flex items-center justify-between text-white font-bold animate-pulse text-[11px]">
              <span className="flex items-center gap-1.5 text-indigo-400 uppercase">
                <Loader2 className="w-3.5 h-3.5 animate-spin" />
                {activeLog}
              </span>
              <span className="text-zinc-500 text-[9px]">DIAG_PORT_3000</span>
            </div>
            
          </div>

        </div>
      )}

      {result && (
        <>
          {/* Download & Action Banner */}
          <div className="flex flex-wrap items-center justify-between gap-4 bg-zinc-900/50 border border-zinc-800 p-4 rounded-xl shadow-sm animate-fade-in mb-6" id="header-actions-bar">
            <div className="flex items-center gap-2.5">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse shrink-0"></span>
              <span className="text-xs text-zinc-300 font-sans">
                Verification complete for target envelope from: <strong className="text-white font-mono">{result.from}</strong>
              </span>
            </div>
            <button
              onClick={() => generateHeaderReport(result)}
              className="px-4 py-1.5 bg-zinc-100 text-zinc-950 hover:bg-zinc-200 text-xs font-bold rounded transition duration-150 flex items-center gap-1.5 font-mono tracking-wider cursor-pointer"
            >
              <FileText className="w-3.5 h-3.5" />
              DOWNLOAD PDF REPORT
            </button>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 animate-fade-in" id="header-scan-results">
          {/* Alignment Alert Card */}
          <div className={`border p-6 rounded-xl flex flex-col items-center justify-between shadow-sm relative overflow-hidden bg-zinc-900/50 ${result.score > 40 ? "border-red-900/30 text-rose-400" : "border-emerald-900/30 text-emerald-400"}`}>
            <label className="text-[10px] uppercase tracking-widest text-zinc-500 font-bold text-center w-full z-10 block">Threat Risk Level</label>
            
            <div className="my-8 text-center z-10">
              <span className={`text-6xl font-black block tracking-tight ${result.score > 40 ? "text-red-400" : "text-emerald-400"}`}>{result.score}%</span>
              <span className="text-zinc-500 text-[10px] tracking-wider uppercase block mt-1 font-mono">Vulnerability Level</span>
            </div>

            <div className="text-center w-full z-10">
              <span className={`inline-block px-3 py-1 rounded-full text-xs font-semibold uppercase tracking-wider bg-zinc-950 border border-zinc-800 ${result.score > 40 ? "text-red-400" : "text-emerald-400"}`}>
                {result.score > 40 ? "HIGH RISK SPOOFED" : "LOW RISK LEGIT"}
              </span>
            </div>
          </div>

          {/* Mapped Headers Extraction */}
          <div className="bg-zinc-900/50 border border-zinc-800 rounded-xl p-6 lg:col-span-2 space-y-4 shadow-sm">
            <label className="text-[10px] uppercase tracking-widest text-zinc-500 font-bold block">Extracted Meta Parameters</label>
            
            <div className="space-y-3.5 text-xs">
              <div className="grid grid-cols-3 border-b border-zinc-800/50 pb-2">
                <span className="text-zinc-500 font-semibold uppercase text-[10px]">Authentication From:</span>
                <span className="col-span-2 text-white font-mono font-medium truncate" title={result.from}>{result.from}</span>
              </div>

              <div className="grid grid-cols-3 border-b border-zinc-800/50 pb-2">
                <span className="text-zinc-500 font-semibold uppercase text-[10px]">Return-Path Sender:</span>
                <span className="col-span-2 text-indigo-400 font-mono font-medium truncate" title={result.returnPath}>{result.returnPath || "NONE"}</span>
              </div>

              <div className="grid grid-cols-3 border-b border-zinc-800/50 pb-2">
                <span className="text-zinc-500 font-semibold uppercase text-[10px]">SPF Result Trace:</span>
                <span className="col-span-2 font-mono font-bold text-zinc-300 truncate">{result.receivedSpf || "NONE DETECTED"}</span>
              </div>

              <div className="grid grid-cols-3 border-b border-zinc-800/50 pb-2">
                <span className="text-zinc-500 font-semibold uppercase text-[10px]">DKIM Signature:</span>
                <span className="col-span-2 font-mono text-zinc-300 truncate">{result.dkimHeader ? "DKIM-Signature Present" : "NOT DETECTED (MISSING HEADER)"}</span>
              </div>

              <div className="grid grid-cols-3 border-b border-zinc-800/50 pb-2">
                <span className="text-zinc-500 font-semibold uppercase text-[10px]">Subject Line:</span>
                <span className="col-span-2 text-white italic truncate">{result.subject}</span>
              </div>

              <div className="grid grid-cols-3 pb-1">
                <span className="text-zinc-500 font-semibold uppercase text-[10px]">Unique Message-ID:</span>
                <span className="col-span-2 text-zinc-400 font-mono select-all truncate">{result.messageId}</span>
              </div>
            </div>
          </div>

          {/* Warning checklist items */}
          <div className="bg-zinc-900/50 border border-zinc-800 rounded-xl p-6 lg:col-span-3 space-y-4 shadow-sm">
            <label className="text-[10px] uppercase tracking-widest text-zinc-500 font-bold block mb-2 underline underline-offset-4">Alignment Audit Checklist Findings</label>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="p-4 bg-zinc-950 border border-zinc-800 rounded-lg space-y-1.5">
                <span className="text-[10px] font-bold text-zinc-500 tracking-wider block uppercase">SPF Alignment Integrity</span>
                <div className="flex items-center gap-2">
                  {result.spfAligned ? (
                    <span className="text-emerald-400 font-extrabold flex items-center gap-1 text-xs">
                      <ShieldCheck className="w-4 h-4" /> ALIGNED PASS
                    </span>
                  ) : (
                    <span className="text-red-400 font-extrabold flex items-center gap-1 text-xs">
                      <ShieldAlert className="w-4 h-4" /> ALIGNMENT MISMATCH
                    </span>
                  )}
                </div>
                <p className="text-zinc-500 text-[10px] leading-relaxed">
                  From Domain (<code className="text-zinc-300">{result.fromDomain || "none"}</code>) aligned with Return-Path Domain (<code className="text-zinc-300">{result.returnPathDomain || "none"}</code>).
                </p>
              </div>

              <div className="p-4 bg-zinc-950 border border-zinc-800 rounded-lg space-y-1.5">
                <span className="text-[10px] font-bold text-zinc-500 tracking-wider block uppercase">Cryptographic DKIM Sign Alignment</span>
                <div className="flex items-center gap-2">
                  {result.dkimAligned ? (
                    <span className="text-emerald-400 font-extrabold flex items-center gap-1 text-xs">
                      <ShieldCheck className="w-4 h-4" /> ALIGNED PASS
                    </span>
                  ) : (
                    <span className="text-red-400 font-extrabold flex items-center gap-1 text-xs">
                      <ShieldAlert className="w-4 h-4" /> NOT ALIGNED / REMOVED
                    </span>
                  )}
                </div>
                <p className="text-zinc-500 text-[10px] leading-relaxed">
                  Verifies if the cryptographically signed `d=` domain parameter in DKIM matches the From field domain.
                </p>
              </div>
            </div>

            <div className="bg-zinc-950 border border-zinc-800 p-4 rounded-xl">
              <span className="text-xs font-bold text-zinc-300 block mb-3 font-mono">Spoofing Detection Engine Audits:</span>
              <ul className="space-y-2.5 font-sans">
                {result.reasons.map((reason, idx) => (
                  <li key={idx} className="flex items-start gap-2.5 text-xs text-zinc-400 leading-relaxed">
                    {reason.toLowerCase().includes("fail") || reason.toLowerCase().includes("alert") || reason.toLowerCase().includes("missing") ? (
                      <span className="w-1.5 h-1.5 rounded-full bg-red-500 shrink-0 mt-2"></span>
                    ) : (
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 shrink-0 mt-2"></span>
                    )}
                    <span>{reason}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>

        </div>
        </>
      )}
    </div>
  );
}
