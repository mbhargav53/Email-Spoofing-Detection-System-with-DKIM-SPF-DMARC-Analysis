import React, { useState } from "react";
import { Play, Sliders, ShieldCheck, ShieldAlert, AlertTriangle, RotateCcw, Info } from "lucide-react";

export default function MachineLearningHub() {
  // Simulator input state features (simulated training parameters)
  const [spfPresent, setSpfPresent] = useState<number>(1);
  const [spfQualifier, setSpfQualifier] = useState<number>(2); // 1: Neutral, 2: Soft Fail, 3: Hard Fail
  const [dkimPresent, setDkimPresent] = useState<number>(1);
  const [dmarcPresent, setDmarcPresent] = useState<number>(1);
  const [dmarcStrength, setDmarcStrength] = useState<number>(1); // 1: None, 2: Quarantine, 3: Reject
  const [alignment, setAlignment] = useState<number>(2); // 0: None, 1: Partial Alignment, 2: Full Alignment
  const [mxPresent, setMxPresent] = useState<number>(1); // 1: Valid/Present, 0: None

  // Quick Preset Handlers
  const applyPreset = (type: "safe" | "spoof" | "suspicious") => {
    switch (type) {
      case "safe":
        setSpfPresent(1);
        setSpfQualifier(3); // Hard Fail
        setDkimPresent(1);
        setDmarcPresent(1);
        setDmarcStrength(3); // Reject
        setAlignment(2); // Full
        setMxPresent(1);
        break;
      case "spoof":
        setSpfPresent(0);
        setSpfQualifier(1);
        setDkimPresent(0);
        setDmarcPresent(0);
        setDmarcStrength(1);
        setAlignment(0); // None
        setMxPresent(1);
        break;
      case "suspicious":
        setSpfPresent(1);
        setSpfQualifier(2); // Soft Fail
        setDkimPresent(1);
        setDmarcPresent(1);
        setDmarcStrength(1); // None
        setAlignment(1); // Partial
        setMxPresent(1);
        break;
    }
  };

  const handleReset = () => {
    setSpfPresent(1);
    setSpfQualifier(2);
    setDkimPresent(1);
    setDmarcPresent(1);
    setDmarcStrength(1);
    setAlignment(2);
    setMxPresent(1);
  };

  // Run decision-tree logical prediction based on current interactive values
  const runPrediction = () => {
    let score = 100;

    if (spfPresent === 1) {
      score -= 20;
      if (spfQualifier === 3) score -= 10;
      if (spfQualifier === 2) score -= 5;
    }
    if (dkimPresent === 1) score -= 20;
    if (dmarcPresent === 1) {
      score -= 15;
      if (dmarcStrength === 3) score -= 25;
      if (dmarcStrength === 2) score -= 15;
    }
    if (alignment === 2) score -= 15;
    if (alignment === 1) score -= 5;
    if (mxPresent === 1) score -= 5;

    score = Math.max(0, Math.min(100, score));

    let prediction = "Spoofed";
    let color = "text-rose-400 bg-rose-950/20 border-rose-900/40";
    let desc = "MODEL PREDICTION: Spoofed / Malicious Impersonation Campaign detected.";
    let icon = <ShieldAlert className="w-8 h-8 text-rose-500 mx-auto mb-2" />;

    if (score < 35) {
      prediction = "Safe (Legitimate)";
      color = "text-emerald-400 bg-emerald-950/20 border-emerald-900/40";
      desc = "MODEL PREDICTION: Legitimate corporate mail. Core cryptographic checks align fully.";
      icon = <ShieldCheck className="w-8 h-8 text-emerald-500 mx-auto mb-2" />;
    } else if (score < 70) {
      prediction = "Suspicious Profile";
      color = "text-amber-400 bg-amber-950/20 border-amber-900/40";
      desc = "MODEL PREDICTION: Structural weaknesses detected. Recommended to quarantine.";
      icon = <AlertTriangle className="w-8 h-8 text-amber-500 mx-auto mb-2" />;
    }

    // Class probabilities simulation
    const pSafe = Math.round(Math.max(0, 100 - score));
    const pSpoofed = Math.round(score);
    const pSuspicious = Math.round(100 - Math.abs(pSafe - pSpoofed));

    return { score, prediction, color, desc, icon, pSafe, pSpoofed, pSuspicious };
  };

  const { prediction, color, desc, icon, pSafe, pSpoofed, pSuspicious } = runPrediction();

  return (
    <div className="max-w-5xl mx-auto space-y-6 animate-fade-in" id="ml-hub-root">
      
      {/* Title block with helper details */}
      <div className="bg-zinc-900/30 border border-zinc-800 rounded-xl p-5 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <h2 className="text-sm font-bold text-white tracking-wide uppercase flex items-center gap-2">
            <Sliders className="w-4 h-4 text-zinc-400" />
            Interactive Trust Estimator Playground
          </h2>
          <p className="text-[11px] text-zinc-400 mt-1 max-w-xl leading-relaxed">
            Adjust the training features and validation weights below to see how a Decision Forest Model categorizes sending reputation scores and evaluates risk in real-time.
          </p>
        </div>

        {/* Action presets */}
        <div className="flex flex-wrap gap-2">
          <button
            onClick={() => applyPreset("safe")}
            className="px-2.5 py-1 text-[10px] uppercase font-bold tracking-wider rounded bg-zinc-900 border border-emerald-900/30 text-emerald-400 hover:bg-emerald-950/10 transition cursor-pointer"
          >
            Preset: Safe Mail
          </button>
          <button
            onClick={() => applyPreset("suspicious")}
            className="px-2.5 py-1 text-[10px] uppercase font-bold tracking-wider rounded bg-zinc-900 border border-amber-900/30 text-amber-400 hover:bg-amber-950/10 transition cursor-pointer"
          >
            Preset: Weak Align
          </button>
          <button
            onClick={() => applyPreset("spoof")}
            className="px-2.5 py-1 text-[10px] uppercase font-bold tracking-wider rounded bg-zinc-900 border border-rose-900/30 text-rose-400 hover:bg-rose-950/10 transition cursor-pointer"
          >
            Preset: Spoofed Attack
          </button>
          <button
            onClick={handleReset}
            className="p-1 text-zinc-500 hover:text-white rounded border border-zinc-800 bg-zinc-900 transition cursor-pointer"
            title="Reset Defaults"
          >
            <RotateCcw className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
        
        {/* Left column: Feature Configuration (7 cols) */}
        <div className="md:col-span-7 bg-zinc-900/20 border border-zinc-800 rounded-xl p-6 space-y-5" id="feature-tuner-panel">
          <div className="border-b border-zinc-800 pb-3 flex items-center justify-between">
            <span className="text-[10px] uppercase tracking-widest text-zinc-450 font-bold font-mono">
              Model Input Features (Simulator)
            </span>
            <span className="text-[10px] text-zinc-500 font-mono">Status Values</span>
          </div>

          {/* 1. SPF Record */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <label className="text-[11px] font-bold text-zinc-300 flex items-center gap-1.5">
                <span>SPF Record Presence</span>
              </label>
              <div className="flex bg-zinc-950 rounded-lg border border-zinc-850 p-0.5">
                <button
                  onClick={() => setSpfPresent(1)}
                  className={`px-3 py-1 text-[10px] font-bold rounded transition cursor-pointer ${spfPresent === 1 ? "bg-zinc-800 text-white" : "text-zinc-500 hover:text-zinc-300"}`}
                >
                  YES
                </button>
                <button
                  onClick={() => setSpfPresent(0)}
                  className={`px-3 py-1 text-[10px] font-bold rounded transition cursor-pointer ${spfPresent === 0 ? "bg-zinc-800 text-white" : "text-zinc-500 hover:text-zinc-300"}`}
                >
                  NO
                </button>
              </div>
            </div>
            
            {spfPresent === 1 && (
              <div className="bg-zinc-950/40 p-2.5 rounded-lg border border-zinc-850/60 flex items-center justify-between gap-4 animate-fade-in">
                <span className="text-[10px] text-zinc-400 font-mono flex items-center gap-1">
                  <Info className="w-3 h-3 text-zinc-500" />
                  SPF Qualifier Policy:
                </span>
                <div className="flex gap-1.5">
                  {[
                    { val: 1, label: "?all (Neutral)" },
                    { val: 2, label: "~all (Soft Fail)" },
                    { val: 3, label: "-all (Hard Fail)" }
                  ].map((opt) => (
                    <button
                      key={opt.val}
                      onClick={() => setSpfQualifier(opt.val)}
                      className={`px-2 py-0.5 text-[9px] font-mono border rounded transition cursor-pointer ${spfQualifier === opt.val ? "bg-zinc-800 border-zinc-700 text-white" : "bg-transparent border-transparent text-zinc-500 hover:text-zinc-400"}`}
                    >
                      {opt.label}
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>

          <div className="h-[1px] bg-zinc-800/40" />

          {/* 2. DKIM Signature */}
          <div className="flex items-center justify-between">
            <div>
              <label className="text-[11px] font-bold text-zinc-300 block">DKIM Cryptographic Signature</label>
              <span className="text-[9px] text-zinc-500">Signs header hash to check non-tampering</span>
            </div>
            <div className="flex bg-zinc-950 rounded-lg border border-zinc-850 p-0.5">
              <button
                onClick={() => setDkimPresent(1)}
                className={`px-3 py-1 text-[10px] font-bold rounded transition cursor-pointer ${dkimPresent === 1 ? "bg-zinc-800 text-white" : "text-zinc-500 hover:text-zinc-300"}`}
              >
                PRESENT
              </button>
              <button
                onClick={() => setDkimPresent(0)}
                className={`px-3 py-1 text-[10px] font-bold rounded transition cursor-pointer ${dkimPresent === 0 ? "bg-zinc-800 text-white" : "text-zinc-500 hover:text-zinc-300"}`}
              >
                ABSENT
              </button>
            </div>
          </div>

          <div className="h-[1px] bg-zinc-800/40" />

          {/* 3. DMARC Policy */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <div>
                <label className="text-[11px] font-bold text-zinc-300 block">DMARC Record Setup</label>
                <span className="text-[9px] text-zinc-500">Defines the domain policy actions</span>
              </div>
              <div className="flex bg-zinc-950 rounded-lg border border-zinc-850 p-0.5">
                <button
                  onClick={() => setDmarcPresent(1)}
                  className={`px-3 py-1 text-[10px] font-bold rounded transition cursor-pointer ${dmarcPresent === 1 ? "bg-zinc-800 text-white" : "text-zinc-500 hover:text-zinc-300"}`}
                >
                  YES
                </button>
                <button
                  onClick={() => setDmarcPresent(0)}
                  className={`px-3 py-1 text-[10px] font-bold rounded transition cursor-pointer ${dmarcPresent === 0 ? "bg-zinc-800 text-white" : "text-zinc-500 hover:text-zinc-300"}`}
                >
                  NO
                </button>
              </div>
            </div>

            {dmarcPresent === 1 && (
              <div className="bg-zinc-950/40 p-2.5 rounded-lg border border-zinc-850/60 flex items-center justify-between gap-4 animate-fade-in">
                <span className="text-[10px] text-zinc-400 font-mono flex items-center gap-1">
                  <Info className="w-3 h-3 text-zinc-500" />
                  Policy Level (p=):
                </span>
                <div className="flex gap-1.5">
                  {[
                    { val: 1, label: "none" },
                    { val: 2, label: "quarantine" },
                    { val: 3, label: "reject" }
                  ].map((opt) => (
                    <button
                      key={opt.val}
                      onClick={() => setDmarcStrength(opt.val)}
                      className={`px-2 py-0.5 text-[9px] font-mono border rounded transition cursor-pointer ${dmarcStrength === opt.val ? "bg-zinc-800 border-zinc-700 text-white" : "bg-transparent border-transparent text-zinc-500 hover:text-zinc-400"}`}
                    >
                      {opt.label}
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>

          <div className="h-[1px] bg-zinc-800/40" />

          {/* 4. Alignment */}
          <div className="space-y-1.5">
            <div className="flex justify-between items-center">
              <label className="text-[11px] font-bold text-zinc-300 block">Identifier Alignment Trust Level</label>
              <span className="text-[10px] text-zinc-500 font-mono">
                {alignment === 2 ? "Full Sync" : alignment === 1 ? "Partial Alias" : "Mismatch"}
              </span>
            </div>
            <div className="grid grid-cols-3 gap-2">
              {[
                { val: 0, label: "0: Unaligned / Fake", desc: "No core header match" },
                { val: 1, label: "1: Partial Alignment", desc: "Unaligned subdomains" },
                { val: 2, label: "2: Strict Matching", desc: "Identical domain paths" }
              ].map((item) => (
                <button
                  key={item.val}
                  onClick={() => setAlignment(item.val)}
                  className={`p-2 border rounded-lg text-left transition cursor-pointer flex flex-col justify-between ${alignment === item.val ? "bg-zinc-950 border-zinc-650 text-white ring-1 ring-zinc-700" : "bg-zinc-900/10 border-zinc-850 text-zinc-500 hover:text-zinc-400 hover:border-zinc-800"}`}
                >
                  <span className="text-[9px] font-mono font-bold leading-none">{item.label}</span>
                  <span className="text-[8px] opacity-70 mt-1 block leading-tight leading-none">{item.desc}</span>
                </button>
              ))}
            </div>
          </div>

          <div className="h-[1px] bg-zinc-800/40" />

          {/* 5. MX Records */}
          <div className="flex items-center justify-between">
            <div>
              <label className="text-[11px] font-bold text-zinc-300 block">MX Records (Mail Exchanger Lookup)</label>
              <span className="text-[9px] text-zinc-500">Checks if sending server is configured to collect mail</span>
            </div>
            <div className="flex bg-zinc-950 rounded-lg border border-zinc-850 p-0.5">
              <button
                onClick={() => setMxPresent(1)}
                className={`px-3 py-1 text-[10px] font-bold rounded transition cursor-pointer ${mxPresent === 1 ? "bg-zinc-800 text-white" : "text-zinc-500 hover:text-zinc-300"}`}
              >
                CONFIGURED
              </button>
              <button
                onClick={() => setMxPresent(0)}
                className={`px-3 py-1 text-[10px] font-bold rounded transition cursor-pointer ${mxPresent === 0 ? "bg-zinc-800 text-white" : "text-zinc-500 hover:text-zinc-300"}`}
              >
                MISSING
              </button>
            </div>
          </div>

        </div>

        {/* Right column: Beautiful Simulated Estimator Classification Verdict Box (5 cols) */}
        <div className="md:col-span-5 flex flex-col gap-6">
          <div className="bg-zinc-900/50 border border-zinc-800 rounded-xl p-6 flex flex-col justify-between shadow-sm h-full" id="classification-verdict-box">
            <div>
              <label className="text-[10px] uppercase tracking-widest text-zinc-400 font-bold flex items-center gap-2 mb-2">
                <Play className="w-3.5 h-3.5 text-zinc-450 animate-pulse" />
                Simulated Estimator Classification Verdict
              </label>
              <p className="text-[11px] text-zinc-500 font-sans leading-relaxed">
                Live calculated outcome of current training vector features. Score weighs missing cryptographic alignments and flags anomalous behavior.
              </p>

              {/* Huge verdict shield display */}
              <div className={`mt-6 p-6 rounded-xl border text-center transition-all duration-350 ${color}`}>
                {icon}
                <span className="text-[9px] uppercase tracking-widest block font-bold opacity-75">Classification Verdict</span>
                <span className="text-2xl font-black mt-1 block tracking-tight uppercase">{prediction}</span>
                <span className="text-[11px] block mt-3 leading-relaxed font-sans">{desc}</span>
              </div>
            </div>

            {/* Probabilities progress indicators */}
            <div className="space-y-4 mt-6 pt-5 border-t border-zinc-800/40">
              <span className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest block">Class Probability Confidence</span>
              
              <div className="space-y-3.5 text-[10px] font-mono">
                <div>
                  <div className="flex justify-between mb-1">
                    <span className="text-zinc-300 font-sans">Class 0: Legitimate (Safe)</span>
                    <span className="text-zinc-300 font-bold">{pSafe}%</span>
                  </div>
                  <div className="w-full bg-zinc-950 h-2 rounded-full overflow-hidden border border-zinc-850">
                    <div className="bg-emerald-500 h-full transition-all duration-350" style={{ width: `${pSafe}%` }}></div>
                  </div>
                </div>

                <div>
                  <div className="flex justify-between mb-1">
                    <span className="text-zinc-200 font-sans">Class 1: Suspicious / Weak Profile</span>
                    <span className="text-zinc-300 font-bold">{pSuspicious}%</span>
                  </div>
                  <div className="w-full bg-zinc-950 h-2 rounded-full overflow-hidden border border-zinc-850">
                    <div className="bg-amber-500 h-full transition-all duration-350" style={{ width: `${pSuspicious}%` }}></div>
                  </div>
                </div>

                <div>
                  <div className="flex justify-between mb-1">
                    <span className="text-zinc-200 font-sans">Class 2: Spoofed / Malicious Sender IP</span>
                    <span className="text-zinc-300 font-bold">{pSpoofed}%</span>
                  </div>
                  <div className="w-full bg-zinc-950 h-2 rounded-full overflow-hidden border border-zinc-850">
                    <div className="bg-red-500 h-full transition-all duration-350" style={{ width: `${pSpoofed}%` }}></div>
                  </div>
                </div>
              </div>
              
              <div className="text-[9px] text-zinc-500 font-sans leading-relaxed text-center mt-3 pt-2">
                * Indicators computed using linear regression confidence intervals over simulated training matrices.
              </div>
            </div>
          </div>
        </div>
        
      </div>
    </div>
  );
}
