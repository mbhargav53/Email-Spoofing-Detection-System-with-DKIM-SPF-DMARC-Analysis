import React, { useState } from "react";
import { ShieldCheck, ShieldAlert, Sparkles, Loader2, AlertCircle, Copy, Check, Globe, HelpCircle, Key, FileText } from "lucide-react";
import { DomainAnalysis } from "../types";
import { generateDomainReport } from "../utils/pdfGenerator";

interface DnsDashboardProps {
  onScanSuccess: () => void;
}

export default function DnsDashboard({ onScanSuccess }: DnsDashboardProps) {
  const [domain, setDomain] = useState("");
  const [selector, setSelector] = useState("default");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<DomainAnalysis | null>(null);
  
  const [copiedRecord, setCopiedRecord] = useState<string | null>(null);
  const [scanProgress, setScanProgress] = useState(0);
  const [activeLog, setActiveLog] = useState("Establishing connection with DNS registry...");

  const handleScan = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!domain.trim()) return;

    setLoading(true);
    setError(null);
    setResult(null);
    setScanProgress(0);
    setActiveLog("Starting audit packet socket...");

    let progress = 0;
    let pendingResult: DomainAnalysis | null = null;
    let apiError: string | null = null;
    let isFetchFinished = false;

    // Start progress simulator that ticks every 80ms
    const progressInterval = setInterval(() => {
      progress += Math.floor(Math.random() * 8) + 4;
      
      if (progress >= 100) {
        progress = 100;
        setScanProgress(100);
        
        // Check if fetch is done
        if (isFetchFinished) {
          clearInterval(progressInterval);
          setLoading(false);
          if (apiError) {
            setError(apiError);
          } else if (pendingResult) {
            setResult(pendingResult);
            onScanSuccess();
          }
        } else {
          // If fetch isn't finished yet, clamp at 99%
          progress = 99;
          setScanProgress(99);
          setActiveLog("Consolidating remote responses...");
        }
        return;
      }

      setScanProgress(progress);

      // Log updates based on progress percentage
      if (progress < 25) {
        setActiveLog("QUERYING Live SPF (TXT v=spf1) registers...");
      } else if (progress < 50) {
        setActiveLog(`RESOLVING Selector '${selector}' for public DKIM keys...`);
      } else if (progress < 75) {
        setActiveLog("LOCATING authoritative DMARC security policy directives...");
      } else {
        setActiveLog("COMPUTING mathematical vector features via decision estimators...");
      }
    }, 80);

    try {
      const response = await fetch("/api/analyze-domain", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ domain, selector }),
      });

      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "Failed to scan domain.");
      pendingResult = data.analysis;
    } catch (err: any) {
      apiError = err.message || "An unexpected error occurred.";
    } finally {
      isFetchFinished = true;
      // If progress is already at 99 or 100, let's trigger completion!
      if (progress >= 99) {
        clearInterval(progressInterval);
        setScanProgress(100);
        setLoading(false);
        if (apiError) {
          setError(apiError);
        } else if (pendingResult) {
          setResult(pendingResult);
          onScanSuccess();
        }
      }
    }
  };



  const copyToClipboard = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    setCopiedRecord(label);
    setTimeout(() => setCopiedRecord(null), 2000);
  };

  // Safe color scale
  const getScoreColor = (score: number) => {
    if (score < 35) return { stroke: "stroke-emerald-500", text: "text-emerald-400", bg: "bg-emerald-950/20", border: "border-emerald-900/30", status: "Low Risk (Safe)" };
    if (score < 75) return { stroke: "stroke-amber-500", text: "text-amber-400", bg: "bg-amber-950/20", border: "border-amber-900/30", status: "Medium Risk (Suspicious)" };
    return { stroke: "stroke-rose-500", text: "text-rose-400", bg: "bg-rose-950/20", border: "border-rose-900/30", status: "High Risk (Spoofable)" };
  };

  const indicator = result ? getScoreColor(result.score) : { stroke: "stroke-slate-500", text: "text-slate-400", bg: "bg-slate-900", border: "border-slate-800", status: "" };

  return (
    <div className="space-y-6 animate-fade-in" id="dns-dashboard-root">
      {/* Search/Form Bento Box */}
      <div className="bg-zinc-900/50 border border-zinc-800 rounded-xl p-6 shadow-sm">
        <h2 className="text-lg font-bold text-white flex items-center gap-2">
          <Globe className="w-4 h-4 text-zinc-400" />
          Live SPF, DKIM, and DMARC Analyzer
        </h2>
        <p className="text-xs text-zinc-400 mt-2 leading-relaxed">
          Retrieves active DNS records for any target domain instantly. The system validates syntax parameters, verifies key length selectors, calculates security risk indicators, and generates simulated machine-learning feature vectors.
        </p>

        {/* Input Form */}
        <form onSubmit={handleScan} className="mt-5 grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="md:col-span-2">
            <label className="block text-[10px] uppercase tracking-widest text-zinc-500 font-bold mb-1.5">Target Domain</label>
            <div className="relative">
              <input
                id="target-domain-input"
                type="text"
                placeholder="e.g. google.com, microsoft.com, yourcollegedomain.edu"
                value={domain}
                onChange={(e) => setDomain(e.target.value)}
                required
                className="w-full bg-zinc-950 border border-zinc-800 rounded-lg px-4 py-2 text-xs text-white placeholder-zinc-600 focus:outline-none focus:border-zinc-700 font-mono"
              />
            </div>
          </div>
          <div>
            <label className="block text-[10px] uppercase tracking-widest text-zinc-500 font-bold mb-1.5 flex items-center gap-1">
              DKIM Selector 
              <span className="group relative">
                <HelpCircle className="w-3.5 h-3.5 text-zinc-600 hover:text-zinc-400 cursor-pointer" />
                <span className="absolute bottom-full left-1/2 -translate-x-1/2 mb-1 w-48 hidden group-hover:block bg-zinc-950 text-zinc-300 text-[10px] p-2 rounded shadow-lg border border-zinc-800 z-10 leading-normal">
                  Common keys: 'default', 'google', 's1', 'key1'.
                </span>
              </span>
            </label>
            <input
              id="dkim-selector-input"
              type="text"
              placeholder="default"
              value={selector}
              onChange={(e) => setSelector(e.target.value)}
              className="w-full bg-zinc-950 border border-zinc-800 rounded-lg px-4 py-2 text-xs text-white placeholder-zinc-600 focus:outline-none focus:border-zinc-700 font-mono"
            />
          </div>
          <div className="md:col-span-3 flex justify-end">
            <button
              id="launch-scanner-btn"
              type="submit"
              disabled={loading}
              className="px-5 py-2 bg-zinc-100 text-zinc-950 hover:bg-zinc-200 text-xs font-bold rounded transition duration-150 flex items-center gap-2 disabled:opacity-50 font-mono tracking-wider"
            >
              {loading ? (
                <>
                  <Loader2 className="w-3.5 h-3.5 animate-spin" />
                  QUERYING DNS...
                </>
              ) : (
                <>
                  <ShieldCheck className="w-3.5 h-3.5" />
                  RUN SECURITY ANALYSIS
                </>
              )}
            </button>
          </div>
        </form>

        {error && (
          <div className="mt-4 p-4 bg-red-500/5 border border-red-500/20 text-red-400 rounded-lg text-xs flex items-start gap-2.5" id="scan-error-alert">
            <AlertCircle className="w-4 h-4 text-red-500 shrink-0 mt-0.5" />
            <div>
              <span className="font-bold">Query Failed:</span> {error}. Ensure you entered a valid domain and that your network environment permits external DNS requests.
            </div>
          </div>
        )}
      </div>

      {loading && (
        <div className="bg-zinc-900/50 border border-indigo-500/20 rounded-xl p-6 shadow-sm animate-entrance space-y-6" id="dns-scanning-diagnostic-box">
          {/* Header block with animation */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="relative flex items-center justify-center">
                <span className="absolute inline-flex h-6 w-6 rounded-full bg-indigo-500/15 animate-radar"></span>
                <span className="relative inline-flex rounded-full h-3.5 w-3.5 bg-indigo-500"></span>
              </div>
              <div>
                <h3 className="text-xs font-bold text-white uppercase tracking-wider font-mono">
                  ACTIVE PACKET ANALYSIS UNDERWAY
                </h3>
                <span className="text-[10px] text-zinc-500 font-mono">Target Domain: {domain || "(identifying)"} • Selector: {selector}</span>
              </div>
            </div>
            
            <div className="text-right">
              <span className="text-sm font-black font-mono text-indigo-400">{scanProgress}%</span>
            </div>
          </div>

          {/* Progress bar */}
          <div className="w-full bg-zinc-950 h-3 rounded-full border border-zinc-850 overflow-hidden relative p-0.5">
            <div 
              className="bg-indigo-500 h-full rounded-full transition-all duration-150 relative overflow-hidden" 
              style={{ width: `${scanProgress}%` }}
            >
              <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent animate-pulse" />
            </div>
          </div>

          {/* Scrolling diagnostic output screen */}
          <div className="bg-zinc-950 p-4 rounded-lg border border-zinc-850/80 font-mono text-[10px] space-y-2 select-none relative overflow-hidden">
            
            {/* Terminal Grid Background lines */}
            <div className="space-y-1.5 text-zinc-400">
              <div className="flex gap-2">
                <span className="text-zinc-650">[0.000s]</span>
                <span className="text-zinc-500">SYS_INIT: Starting audit packet daemon for {domain}...</span>
              </div>
              <div className="flex gap-2">
                <span className="text-zinc-650">[0.180s]</span>
                <span className="text-indigo-450">DNS_RESOLV: Contacting authoritative root servers... [RESOLVED]</span>
              </div>
              
              {scanProgress >= 25 && (
                <div className="flex gap-2 animate-entrance">
                  <span className="text-zinc-650">[0.450s]</span>
                  <span className="text-emerald-400">SPF_PARSER: Scanning TXT records. Checking designated IP arrays...</span>
                </div>
              )}

              {scanProgress >= 50 && (
                <div className="flex gap-2 animate-entrance">
                  <span className="text-zinc-650">[0.890s]</span>
                  <span className="text-emerald-400">DKIM_PARSER: Resolving public key for selector key: '{selector}'...</span>
                </div>
              )}

              {scanProgress >= 75 && (
                <div className="flex gap-2 animate-entrance">
                  <span className="text-zinc-650">[1.220s]</span>
                  <span className="text-amber-400">DMARC_POLICY: Auditing alignment indices (strict/relaxed)...</span>
                </div>
              )}

              {scanProgress >= 90 && (
                <div className="flex gap-2 animate-entrance font-bold text-indigo-300">
                  <span className="text-zinc-650">[1.540s]</span>
                  <span>DECISION_TREE: Injecting simulated classification weights...</span>
                </div>
              )}
            </div>

            {/* Current rolling status line flashing */}
            <div className="pt-2 border-t border-zinc-900 flex items-center justify-between text-white font-bold animate-pulse text-[11px]">
              <span className="flex items-center gap-1.5 text-indigo-400 uppercase">
                <Loader2 className="w-3.5 h-3.5 animate-spin" />
                {activeLog}
              </span>
              <span className="text-zinc-500 text-[9px]">DIAG_PORT_3000</span>
            </div>
            
          </div>

        </div>
      )}

      {result && (
        <>
          {/* Download & Action Banner */}
          <div className="flex flex-wrap items-center justify-between gap-4 bg-zinc-900/50 border border-zinc-800 p-4 rounded-xl shadow-sm animate-fade-in" id="dns-actions-bar">
            <div className="flex items-center gap-2.5">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse shrink-0"></span>
              <span className="text-xs text-zinc-300 font-sans">
                Audit complete for target: <strong className="text-white font-mono">{result.domain}</strong>
              </span>
            </div>
            <button
              onClick={() => generateDomainReport(result)}
              className="px-4 py-1.5 bg-zinc-100 text-zinc-950 hover:bg-zinc-200 text-xs font-bold rounded transition duration-150 flex items-center gap-1.5 font-mono tracking-wider cursor-pointer"
            >
              <FileText className="w-3.5 h-3.5" />
              DOWNLOAD PDF REPORT
            </button>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 animate-fade-in" id="dns-scan-results">
          
          {/* Risk Dial Card - Bento Box */}
          <div className="bg-zinc-900/50 border border-zinc-800 rounded-xl p-6 flex flex-col items-center justify-between shadow-sm">
            <label className="text-[10px] uppercase tracking-widest text-zinc-500 font-bold self-start">AI Risk Assessment</label>
            
            <div className="relative flex items-center justify-center my-6 w-44 h-44">
              <svg className="w-full h-full transform -rotate-90">
                <circle
                  cx="88"
                  cy="88"
                  r="78"
                  className="stroke-zinc-800"
                  strokeWidth="10"
                  fill="transparent"
                />
                <circle
                  cx="88"
                  cy="88"
                  r="78"
                  className={`transition-all duration-1000 ${
                    result.score < 35 ? "stroke-emerald-500" : result.score < 75 ? "stroke-amber-500" : "stroke-red-500"
                  }`}
                  strokeWidth="12"
                  fill="transparent"
                  strokeDasharray={490}
                  strokeDashoffset={490 - (490 * (100 - result.score)) / 100}
                />
              </svg>
              <div className="absolute flex flex-col items-center justify-center">
                <span className="text-5xl font-extrabold text-white tracking-tight">{result.score}</span>
                <span className="text-[10px] text-zinc-400 mt-1 uppercase font-mono tracking-wider">
                  {result.score < 35 ? "LOW RISK" : result.score < 75 ? "SUSPICIOUS" : "CRITICAL RISK"}
                </span>
              </div>
            </div>

            <div className="text-center w-full">
              <div className="grid grid-cols-3 gap-3 w-full border-t border-zinc-800 pt-4 mb-4">
                <div>
                  <div className="text-[9px] text-zinc-500 font-bold">SPF</div>
                  <div className={`text-xs font-bold font-mono ${result.spf.status === "Pass" ? "text-emerald-400" : "text-red-400"}`}>
                    {result.spf.status === "Pass" ? "ACTIVE" : "FAIL"}
                  </div>
                </div>
                <div>
                  <div className="text-[9px] text-zinc-500 font-bold">DKIM</div>
                  <div className={`text-xs font-bold font-mono ${result.dkim.status === "Pass" ? "text-emerald-400" : "text-red-400"}`}>
                    {result.dkim.status === "Pass" ? "ACTIVE" : "FAIL"}
                  </div>
                </div>
                <div>
                  <div className="text-[9px] text-zinc-500 font-bold">DMARC</div>
                  <div className={`text-xs font-bold font-mono ${result.dmarc.status === "Pass" ? "text-emerald-400" : "text-red-400"}`}>
                    {result.dmarc.status === "Pass" ? result.dmarc.policy.toUpperCase() : "NONE"}
                  </div>
                </div>
              </div>

              <p className="text-zinc-500 text-[11px] leading-relaxed">
                {result.score < 35 
                  ? "Highly hardened defensive profile. High-fidelity filtering policies successfully block unauthorized sender IPs." 
                  : result.score < 75 
                  ? "Vulnerable to bypasses. Records exist but with soft-fail variables or warning indicators that can permit masquerading." 
                  : "Critical Exposure! Cryptographically unverified structure allows bad actors to broadcast unauthorized emails spoofing this domain."
                }
              </p>
            </div>
          </div>

          {/* Protocol Alignment Check Bento Box */}
          <div className="bg-zinc-900/50 border border-zinc-800 rounded-xl p-6 lg:col-span-2 space-y-6 shadow-sm">
            <label className="text-[10px] uppercase tracking-widest text-zinc-500 font-bold block">Protocol Alignment Details</label>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="p-4 bg-zinc-950 border border-zinc-800 rounded-lg">
                <span className="text-[10px] font-bold text-zinc-500 uppercase block mb-1 font-mono">SPF Configuration Status</span>
                <div className="flex items-center gap-2">
                  <span className={`w-2 h-2 rounded-full ${result.spf.status === "Pass" ? "bg-emerald-500" : "bg-red-500"}`}></span>
                  <span className="font-bold text-white text-xs font-mono">{result.spf.status === "Pass" ? "VALID RECORD" : "MISSING / FAILING"}</span>
                </div>
                <p className="text-[10px] text-zinc-500 mt-2 leading-relaxed">
                  Validation: check if SPF (TXT starting with v=spf1) is deployed in key records.
                </p>
              </div>

              <div className="p-4 bg-zinc-950 border border-zinc-800 rounded-lg">
                <span className="text-[10px] font-bold text-zinc-500 uppercase block mb-1 font-mono">DKIM Configuration Status</span>
                <div className="flex items-center gap-2">
                  <span className={`w-2 h-2 rounded-full ${result.dkim.status === "Pass" ? "bg-emerald-500" : "bg-red-500"}`}></span>
                  <span className="font-bold text-white text-xs font-mono">{result.dkim.status === "Pass" ? "VALID RECORD" : "MISSING Selector"}</span>
                </div>
                <p className="text-[10px] text-zinc-500 mt-2 leading-relaxed">
                  Target: Checked on selector key <strong className="text-zinc-300 font-mono">'{selector}'</strong>. Alternate selectors may contain records.
                </p>
              </div>

              <div className="p-4 bg-zinc-950 border border-zinc-800 rounded-lg">
                <span className="text-[10px] font-bold text-zinc-500 uppercase block mb-1 font-mono">DMARC Policy Configuration</span>
                <div className="flex items-center gap-2">
                  <span className={`w-2 h-2 rounded-full ${result.dmarc.status === "Pass" ? "bg-emerald-500" : "bg-red-500"}`}></span>
                  <span className="font-bold text-white text-xs font-mono">
                    {result.dmarc.status === "Pass" ? `Policy: '${result.dmarc.policy.toUpperCase()}'` : "DMARC VULNERABLE"}
                  </span>
                </div>
                <p className="text-[10px] text-zinc-500 mt-2 leading-relaxed">
                  DMARC maps incoming SPF/DKIM flags to decide delivery (reject, quarantine, or none).
                </p>
              </div>

              <div className="p-4 bg-zinc-950 border border-zinc-800 rounded-lg">
                <span className="text-[10px] font-bold text-zinc-500 uppercase block mb-1 font-mono">MX Records Check</span>
                <div className="flex items-center gap-2">
                  <span className={`w-2 h-2 rounded-full ${result.mx.hasMx ? "bg-emerald-500" : "bg-red-500"}`}></span>
                  <span className="font-bold text-white text-xs font-mono">{result.mx.hasMx ? `${result.mx.records.length} servers cataloged` : "No outbound MX servers"}</span>
                </div>
                <p className="text-[10px] text-zinc-500 mt-2 leading-relaxed">
                  Presence of Mail Exchange servers signals that the domain actively deploys active email clients.
                </p>
              </div>
            </div>

            {/* Simulated ML Feature Extraction Block */}
            <div className="p-4 bg-zinc-950 border border-zinc-800 rounded-lg">
              <span className="text-xs font-bold text-zinc-300 block mb-2 font-mono">Simulated ML Feature Extraction Matrix</span>
              <div className="text-zinc-300 text-[10px] font-mono grid grid-cols-2 md:grid-cols-4 gap-2 leading-relaxed">
                <div className="border border-zinc-805 bg-zinc-900/30 p-1.5 rounded"><code className="text-zinc-500">spf_present:</code> {result.mlFeatures.spf_present}</div>
                <div className="border border-zinc-805 bg-zinc-900/30 p-1.5 rounded"><code className="text-zinc-500">spf_qual_code:</code> {result.mlFeatures.spf_qualifier_code}</div>
                <div className="border border-zinc-805 bg-zinc-900/30 p-1.5 rounded"><code className="text-zinc-500">dkim_present:</code> {result.mlFeatures.dkim_present}</div>
                <div className="border border-zinc-805 bg-zinc-900/30 p-1.5 rounded"><code className="text-zinc-500">dmarc_present:</code> {result.mlFeatures.dmarc_present}</div>
                <div className="border border-zinc-805 bg-zinc-900/30 p-1.5 rounded"><code className="text-zinc-500">dmarc_strength:</code> {result.mlFeatures.dmarc_policy_strength}</div>
                <div className="border border-zinc-805 bg-zinc-900/30 p-1.5 rounded"><code className="text-zinc-500">mx_present:</code> {result.mlFeatures.mx_present}</div>
                <div className="border border-zinc-805 bg-zinc-900/30 p-1.5 rounded"><code className="text-zinc-500">spf_dkim_align:</code> {result.mlFeatures.spf_dkim_alignment}</div>
                <div className="border border-zinc-805 bg-zinc-900/30 p-1.5 rounded"><code className="text-zinc-500">risk_score:</code> {result.mlFeatures.calculated_risk_score}</div>
              </div>
              <p className="text-zinc-500 text-[10px] mt-2 leading-relaxed">These discrete variables map DNS protocols to structured training inputs for our Decision Tree scoring calculations.</p>
            </div>
          </div>

          {/* DNS TXT RECORDS LIST */}
          <div className="bg-zinc-900/50 border border-zinc-800 rounded-xl p-6 lg:col-span-3 space-y-4 shadow-sm">
            <label className="text-[10px] uppercase tracking-widest text-zinc-500 font-bold block mb-2 underline underline-offset-4">Retrieved DNS Records Details</label>
            
            {/* SPF Record View */}
            <div className="space-y-2 border-b border-zinc-800 pb-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="px-2 py-0.5 bg-zinc-950 border border-zinc-800 text-zinc-400 text-[9px] font-mono rounded font-bold">SPF TXT</span>
                  <span className="text-xs font-semibold text-zinc-300">Sender Policy Framework</span>
                </div>
                {result.spf.raw && result.spf.status === "Pass" && (
                  <button 
                    onClick={() => copyToClipboard(result.spf.raw, "spf")}
                    className="p-1 text-zinc-500 hover:text-zinc-300 rounded transition"
                    title="Copy record"
                  >
                    {copiedRecord === "spf" ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  </button>
                )}
              </div>
              <div className="bg-zinc-950 p-2.5 rounded border border-zinc-800 font-mono text-[10px] text-zinc-300 whitespace-pre-wrap break-all">
                {result.spf.raw}
              </div>
              <ul className="list-disc pl-5 text-zinc-400 text-[11px] gap-1 flex flex-col leading-relaxed">
                {result.spf.details.map((detail, idx) => (
                  <li key={idx}>{detail}</li>
                ))}
              </ul>
            </div>

            {/* DKIM Record View */}
            <div className="space-y-2 border-b border-zinc-800 pb-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="px-2 py-0.5 bg-zinc-950 border border-zinc-800 text-zinc-400 text-[9px] font-mono rounded font-bold">DKIM TXT</span>
                  <span className="text-xs font-semibold text-zinc-300">DomainKeys Identified Mail (Selector: {selector})</span>
                </div>
                {result.dkim.raw && result.dkim.status === "Pass" && (
                  <button 
                    onClick={() => copyToClipboard(result.dkim.raw, "dkim")}
                    className="p-1 text-zinc-500 hover:text-zinc-300 rounded transition"
                  >
                    {copiedRecord === "dkim" ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  </button>
                )}
              </div>
              <div className="bg-zinc-950 p-2.5 rounded border border-zinc-800 font-mono text-[10px] text-zinc-300 whitespace-pre-wrap break-all">
                {result.dkim.raw}
              </div>
              <ul className="list-disc pl-5 text-zinc-400 text-[11px] gap-1 flex flex-col leading-relaxed">
                {result.dkim.details.map((detail, idx) => (
                  <li key={idx}>{detail}</li>
                ))}
              </ul>
            </div>

            {/* DMARC Record View */}
            <div className="space-y-2 border-b border-zinc-800 pb-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="px-2 py-0.5 bg-zinc-950 border border-zinc-800 text-zinc-400 text-[9px] font-mono rounded font-bold">DMARC TXT</span>
                  <span className="text-xs font-semibold text-zinc-300">Domain-based Message Authentication</span>
                </div>
                {result.dmarc.raw && result.dmarc.status === "Pass" && (
                  <button 
                    onClick={() => copyToClipboard(result.dmarc.raw, "dmarc")}
                    className="p-1 text-zinc-500 hover:text-zinc-300 rounded transition"
                  >
                    {copiedRecord === "dmarc" ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  </button>
                )}
              </div>
              <div className="bg-zinc-950 p-2.5 rounded border border-zinc-800 font-mono text-[10px] text-zinc-300 whitespace-pre-wrap break-all">
                {result.dmarc.raw}
              </div>
              <ul className="list-disc pl-5 text-zinc-400 text-[11px] gap-1 flex flex-col leading-relaxed">
                {result.dmarc.details.map((detail, idx) => (
                  <li key={idx}>{detail}</li>
                ))}
              </ul>
            </div>
            
            {/* MX record list */}
            {result.mx.hasMx && (
              <div className="space-y-2">
                <span className="text-xs font-semibold text-zinc-300">Outbound Mail Servers (MX Records)</span>
                <div className="bg-zinc-950 p-2.5 rounded border border-zinc-800">
                  <ul className="font-mono text-[10px] text-zinc-400 space-y-1">
                    {result.mx.records.map((mxRec, idx) => (
                      <li key={idx} className="flex gap-4">
                        <span className="text-zinc-650">priority:</span>
                        <span>{mxRec}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            )}
          </div>

        </div>
        </>
      )}
    </div>
  );
}
