export interface SpfAnalysis {
  raw: string;
  status: "Pass" | "Fail";
  details: string[];
  qualifier: "fail" | "softfail" | "neutral" | "allowall" | "none";
  mechanisms: string[];
}

export interface DkimAnalysis {
  raw: string;
  status: "Pass" | "Fail";
  details: string[];
  selector: string;
}

export interface DmarcAnalysis {
  raw: string;
  status: "Pass" | "Fail";
  details: string[];
  policy: "reject" | "quarantine" | "none";
  pct: number;
  rua: string;
}

export interface MxAnalysis {
  records: string[];
  hasMx: boolean;
}

export interface AlignmentAnalysis {
  spfAligned: boolean;
  dkimAligned: boolean;
  status: string;
}

export interface DomainAnalysis {
  domain: string;
  spf: SpfAnalysis;
  dkim: DkimAnalysis;
  dmarc: DmarcAnalysis;
  mx: MxAnalysis;
  alignment: AlignmentAnalysis;
  score: number;
  classification: "Safe" | "Suspicious" | "Spoofed / Highly Vulnerable";
  mlFeatures: {
    spf_present: number;
    spf_qualifier_code: number;
    dkim_present: number;
    dmarc_present: number;
    dmarc_policy_strength: number;
    mx_present: number;
    spf_dkim_alignment: number;
    calculated_risk_score: number;
  };
}

export interface HeaderAnalysis {
  from: string;
  fromDomain: string;
  returnPath: string;
  returnPathDomain: string;
  replyTo: string;
  subject: string;
  messageId: string;
  hasDkimHeader: boolean;
  dkimHeader: string;
  receivedSpf: string;
  spfStatus: string;
  dkimStatus: string;
  spfAligned: boolean;
  dkimAligned: boolean;
  riskLevel: "Safe" | "Suspicious" | "Spoofed";
  score: number;
  reasons: string[];
}

export interface ScanItem {
  id: string;
  type: "domain" | "header";
  target: string;
  timestamp: string;
  score: number;
  classification: string;
  data: any;
}
