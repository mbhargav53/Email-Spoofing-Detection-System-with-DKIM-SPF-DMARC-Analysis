import express from "express";
import path from "path";
import fs from "fs";
import dns from "dns";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, Type } from "@google/genai";
import { fileURLToPath } from "url";

const app = express();
const PORT = 3000;

app.use(express.json({ limit: "5mb" }));

// Resolve paths for ES Modules
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const HISTORY_FILE = path.join(process.cwd(), "scan_history.json");

// Helper to trace and load scan history
function readHistory() {
  try {
    if (fs.existsSync(HISTORY_FILE)) {
      const data = fs.readFileSync(HISTORY_FILE, "utf-8");
      return JSON.parse(data);
    }
  } catch (error) {
    console.error("Error reading scan history:", error);
  }
  return [];
}

function writeHistory(history: any[]) {
  try {
    fs.writeFileSync(HISTORY_FILE, JSON.stringify(history, null, 2), "utf-8");
  } catch (error) {
    console.error("Error writing scan history:", error);
  }
}

// Lazy initializer for Gemini Client
let aiInstance: GoogleGenAI | null = null;
function getGeminiClient(): GoogleGenAI | null {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey || apiKey === "MY_GEMINI_API_KEY" || apiKey.trim() === "") {
    return null;
  }
  if (!aiInstance) {
    aiInstance = new GoogleGenAI({
      apiKey: apiKey,
      httpOptions: {
        headers: {
          "User-Agent": "aistudio-build",
        },
      },
    });
  }
  return aiInstance;
}

// Helper: Query Cloudflare DoH (DNS over HTTPS) as primary/fallback to avoid sandbox blockages
async function queryDnsViaHttps(name: string, type: string): Promise<string[]> {
  try {
    const url = `https://cloudflare-dns.com/dns-query?name=${encodeURIComponent(name)}&type=${type}`;
    const response = await fetch(url, {
      headers: {
        Accept: "application/dns-json",
      },
    });
    if (!response.ok) return [];
    const json = (await response.json()) as any;
    if (json.Answer && Array.isArray(json.Answer)) {
      return json.Answer.map((answer: any) => {
        // Remove enclosing double quotes if present in TXT
        let data = answer.data || "";
        if (data.startsWith('"') && data.endsWith('"')) {
          data = data.substring(1, data.length - 1);
        }
        return data;
      });
    }
  } catch (e) {
    console.error(`DoH lookup failed for ${name} (${type}):`, e);
  }
  return [];
}

// Helper: Query native DNS as secondary fallback
function queryDnsNative(name: string, type: "TXT" | "MX"): Promise<string[]> {
  return new Promise((resolve) => {
    if (type === "TXT") {
      dns.resolveTxt(name, (err, records) => {
        if (err || !records) return resolve([]);
        const flat = records.map((rec) => rec.join(""));
        resolve(flat);
      });
    } else if (type === "MX") {
      dns.resolveMx(name, (err, records) => {
        if (err || !records) return resolve([]);
        const sorted = records
          .sort((a, b) => a.priority - b.priority)
          .map((rec) => `${rec.priority} ${rec.exchange}`);
        resolve(sorted);
      });
    } else {
      resolve([]);
    }
  });
}

// Resolve TXT records with fallbacks
async function resolveTxtRecords(name: string): Promise<string[]> {
  const httpsRecords = await queryDnsViaHttps(name, "TXT");
  if (httpsRecords.length > 0) return httpsRecords;
  return queryDnsNative(name, "TXT");
}

// Resolve MX records with fallbacks
async function resolveMxRecords(name: string): Promise<string[]> {
  const httpsRecords = await queryDnsViaHttps(name, "MX");
  if (httpsRecords.length > 0) return httpsRecords;
  return queryDnsNative(name, "MX");
}

// Core Analytical SPF/DKIM/DMARC Analysis & ML Scoring Mechanism
function analyzeDnsSecurity(
  domain: string,
  spfRecords: string[],
  dkimRecords: string[],
  dmarcRecords: string[],
  selectorUsed: string,
  mxRecords: string[]
) {
  const results: any = {
    domain,
    spf: {
      raw: spfRecords.join(" | ") || "No SPF Record Found",
      status: "Fail",
      details: [] as string[],
      qualifier: "none",
      mechanisms: [] as string[],
    },
    dkim: {
      raw: dkimRecords.join(" | ") || "No DKIM Record Found",
      status: "Fail",
      details: [] as string[],
      selector: selectorUsed,
    },
    dmarc: {
      raw: dmarcRecords.join(" | ") || "No DMARC Record Found",
      status: "Fail",
      details: [] as string[],
      policy: "none",
      pct: 100,
      rua: "",
    },
    mx: {
      records: mxRecords,
      hasMx: mxRecords.length > 0,
    },
    alignment: {
      spfAligned: false,
      dkimAligned: false,
      status: "Failed",
    },
    score: 0, // Spoofing Vulnerability Risk Score (0 = Completely Secure/Safe, 100 = Highly Vulnerable/Spoofable)
    classification: "Suspicious", // Safe, Suspicious, spoofed
    mlFeatures: {} as any,
  };

  // 1. Analyze SPF
  if (spfRecords.length > 0) {
    const spf = spfRecords.find((r) => r.startsWith("v=spf1")) || spfRecords[0];
    results.spf.raw = spf;
    if (spf.startsWith("v=spf1")) {
      results.spf.status = "Pass";
      results.spf.details.push("Valid SPF version header (v=spf1) detected.");

      // Check qualifiers
      if (spf.includes("-all")) {
        results.spf.qualifier = "fail";
        results.spf.details.push("Hard Fail (-all) configured: highly secure policy rejecting unauthorized IPs.");
      } else if (spf.includes("~all")) {
        results.spf.qualifier = "softfail";
        results.spf.details.push("Soft Fail (~all) configured: suspicious mail flagged but accepted.");
      } else if (spf.includes("?all")) {
        results.spf.qualifier = "neutral";
        results.spf.details.push("Neutral (?all) configured: no screening policy (vulnerable).");
      } else if (spf.includes("+all")) {
        results.spf.qualifier = "allowall";
        results.spf.details.push("Allow All (+all) detected! This explicitly permits any server to spoof this domain.");
      } else {
        results.spf.qualifier = "none";
        results.spf.details.push("No explicit default 'all' qualifier found.");
      }

      // Check standard tags
      const mechanisms = spf.split(/\s+/);
      results.spf.mechanisms = mechanisms;
      if (mechanisms.length > 10) {
        results.spf.details.push("Warning: DNS lookup limit exceeded. SPF record contains more than 10 mechanisms.");
      }
    } else {
      results.spf.details.push("Invalid SPF record structure. SPF record must start with 'v=spf1'.");
    }
  } else {
    results.spf.details.push("Critical: SPF Record is missing. Fraudsters can impersonate your sender IP.");
  }

  // 2. Analyze DKIM
  if (dkimRecords.length > 0) {
    const dkim = dkimRecords.find((r) => r.includes("p=")) || dkimRecords[0];
    results.dkim.raw = dkim;
    results.dkim.status = "Pass";
    results.dkim.details.push(`DKIM public key published under selector '${selectorUsed}'.`);
    
    if (dkim.includes("k=rsa")) {
      results.dkim.details.push("Algorithm: RSA encryption detected.");
    }
    if (dkim.includes("p=")) {
      const pKey = dkim.split("p=")[1]?.split(";")[0]?.trim() || "";
      if (pKey.length < 100) {
        results.dkim.details.push("Warning: DKIM Key size appears short or vulnerable.");
      } else {
        results.dkim.details.push("Cryptographic Signature: Active public key verified.");
      }
    }
  } else {
    results.dkim.details.push(`No DKIM signature found on common selector '${selectorUsed}'. Custom selectors should be tested.`);
  }

  // 3. Analyze DMARC
  if (dmarcRecords.length > 0) {
    const dmarc = dmarcRecords.find((r) => r.startsWith("v=DMARC1")) || dmarcRecords[0];
    results.dmarc.raw = dmarc;
    if (dmarc.startsWith("v=DMARC1")) {
      results.dmarc.status = "Pass";
      results.dmarc.details.push("Valid DMARC header (v=DMARC1) detected.");

      // Check Policy Tag (p)
      const pMatch = dmarc.match(/p=(reject|quarantine|none)/i);
      if (pMatch) {
        const policy = pMatch[1].toLowerCase();
        results.dmarc.policy = policy;
        if (policy === "reject") {
          results.dmarc.details.push("Strong enforcement policy: 'reject' blocks all unaligned emails.");
        } else if (policy === "quarantine") {
          results.dmarc.details.push("Moderate enforcement policy: 'quarantine' sends unaligned emails to spam.");
        } else if (policy === "none") {
          results.dmarc.details.push("Monitoring-only policy: 'none' permits spoofed emails to land in users' inboxes.");
        }
      } else {
        results.dmarc.details.push("Warning: Missing or invalid policy 'p=' directive.");
      }

      // Check percentage tag (pct)
      const pctMatch = dmarc.match(/pct=(\d+)/i);
      if (pctMatch) {
        results.dmarc.pct = parseInt(pctMatch[1], 10);
        results.dmarc.details.push(`Policy application: configured to apply to ${results.dmarc.pct}% of emails.`);
      }

      // Check reporting uri (rua)
      const ruaMatch = dmarc.match(/rua=mailto:([^;]+)/i);
      if (ruaMatch) {
        results.dmarc.rua = ruaMatch[1];
        results.dmarc.details.push(`DMARC aggregate XML telemetry is active. Sending reports to: ${results.dmarc.rua}`);
      } else {
        results.dmarc.details.push("Consider adding 'rua' to collect aggregate DMARC analytical reports.");
      }
    } else {
      results.dmarc.details.push("Invalid DMARC record. DMARC must start with 'v=DMARC1'.");
    }
  } else {
    results.dmarc.details.push("Critical: DMARC record is missing. Recipient mail servers are left blind with no fallback security directives.");
  }

  // 4. Calculate alignment & ML scores
  // Let's implement SPF alignment & DKIM alignment simulation based on status
  // Alignment is typically handled on header inspection, but we assume default domain matches.
  results.alignment.spfAligned = results.spf.status === "Pass";
  results.alignment.dkimAligned = results.dkim.status === "Pass";
  if (results.alignment.spfAligned && results.alignment.dkimAligned) {
    results.alignment.status = "Fully Aligned";
  } else if (results.alignment.spfAligned || results.alignment.dkimAligned) {
    results.alignment.status = "Partially Aligned";
  } else {
    results.alignment.status = "Unaligned / Missing";
  }

  // Calculate Vulnerability Risk Score (0 = Safe, 100 = Highly Vulnerable/Spoofable)
  let riskScore = 100;

  // Deduct risk for having good records:
  if (results.spf.status === "Pass") {
    riskScore -= 20;
    if (results.spf.qualifier === "fail") riskScore -= 10; // -all is best
    if (results.spf.qualifier === "softfail") riskScore -= 5; // ~all is ok
    if (results.spf.qualifier === "allowall") riskScore += 15; // +all makes it highly spoofable
  }
  if (results.dkim.status === "Pass") {
    riskScore -= 25;
  }
  if (results.dmarc.status === "Pass") {
    riskScore -= 15;
    if (results.dmarc.policy === "reject") {
      riskScore -= 30;
    } else if (results.dmarc.policy === "quarantine") {
      riskScore -= 15;
    } else {
      riskScore -= 5; // p=none helps very little with spoof integrity
    }
  }
  if (!results.mx.hasMx) {
    // If no MX records, domain is a non-sending domain, security profile varies, but let's assume it increases vulnerability if user targets it
    riskScore += 10;
  }

  results.score = Math.max(0, Math.min(100, riskScore));

  // Predict email classification: Safe, Suspicious, Spoofed
  // Safe: Good SPF, DKIM, and DMARC rejecting/quarantining (Risk score < 30)
  // Suspicious: Some records found, but weak default or missing protection (Risk score between 30 and 70)
  // Spoofed/Highly Spoofable: No SPF, No DMARC or extremely weak parameters (+all or p=none with no alignment) (Risk score > 70)
  if (results.score < 35) {
    results.classification = "Safe";
  } else if (results.score < 75) {
    results.classification = "Suspicious";
  } else {
    results.classification = "Spoofed / Highly Vulnerable";
  }

  // Machine Learning Simulated Feature Output (for our Python ML dataset compatibility)
  results.mlFeatures = {
    spf_present: results.spf.status === "Pass" ? 1 : 0,
    spf_qualifier_code: results.spf.qualifier === "fail" ? 3 : results.spf.qualifier === "softfail" ? 2 : results.spf.qualifier === "neutral" ? 1 : 0,
    dkim_present: results.dkim.status === "Pass" ? 1 : 0,
    dmarc_present: results.dmarc.status === "Pass" ? 1 : 0,
    dmarc_policy_strength: results.dmarc.policy === "reject" ? 3 : results.dmarc.policy === "quarantine" ? 2 : results.dmarc.policy === "none" ? 1 : 0,
    mx_present: results.mx.hasMx ? 1 : 0,
    spf_dkim_alignment: results.alignment.status === "Fully Aligned" ? 2 : results.alignment.status === "Partially Aligned" ? 1 : 0,
    calculated_risk_score: results.score,
  };

  return results;
}

// ----------------------------------------------------------------------
// API ROUTES
// ----------------------------------------------------------------------

// 1. Analyze Email Domain DNS Authentication Records
app.post("/api/analyze-domain", async (req, res) => {
  try {
    let { domain, selector } = req.body;
    if (!domain) {
      return res.status(400).json({ error: "Domain parameter is required." });
    }

    // Clean domain string
    domain = domain.trim().toLowerCase().replace(/^(https?:\/\/)?(www\.)?/, "").split("/")[0];
    const selectorUsed = (selector || "default").trim();

    // Fire lookups in parallel
    const [spfRecords, mxRecords, dmarcRecords, dkimRecords] = await Promise.all([
      resolveTxtRecords(domain),
      resolveMxRecords(domain),
      resolveTxtRecords(`_dmarc.${domain}`),
      resolveTxtRecords(`${selectorUsed}._domainkey.${domain}`),
    ]);

    const analysis = analyzeDnsSecurity(
      domain,
      spfRecords,
      dkimRecords,
      dmarcRecords,
      selectorUsed,
      mxRecords
    );

    // Save to local scan history automatically
    const history = readHistory();
    const newScan = {
      id: "scan_" + Date.now(),
      type: "domain",
      target: domain,
      timestamp: new Date().toISOString(),
      score: analysis.score,
      classification: analysis.classification,
      data: analysis,
    };
    history.unshift(newScan);
    writeHistory(history.slice(0, 50)); // Keep last 50 records in the file

    res.json({ success: true, analysis, scanId: newScan.id });
  } catch (error: any) {
    console.error("Domain scan API error:", error);
    res.status(500).json({ error: error.message || "An error occurred during domain analysis." });
  }
});

// 2. Parse and Analyze E-mail RFC Header Files
app.post("/api/analyze-headers", async (req, res) => {
  try {
    const { headersText } = req.body;
    if (!headersText || headersText.trim() === "") {
      return res.status(400).json({ error: "Email header text is empty." });
    }

    // Extract headers systematically
    const lines = headersText.split(/\r?\n/);
    const headersMap: Record<string, string> = {};
    let lastKey = "";

    for (const line of lines) {
      if (line.startsWith(" ") || line.startsWith("\t")) {
        // Folded line continuation
        if (lastKey) {
          headersMap[lastKey] += " " + line.trim();
        }
      } else {
        const colonIdx = line.indexOf(":");
        if (colonIdx > 0) {
          lastKey = line.substring(0, colonIdx).trim().toLowerCase();
          const value = line.substring(colonIdx + 1).trim();
          headersMap[lastKey] = value;
        }
      }
    }

    // Extract crucial fields
    const fromVal = headersMap["from"] || "";
    const returnPathVal = headersMap["return-path"] || "";
    const replyToVal = headersMap["reply-to"] || "";
    const receivedSpfVal = headersMap["received-spf"] || headersMap["authentication-results"] || "";
    const dkimSignatureVal = headersMap["dkim-signature"] || "";
    const messageId = headersMap["message-id"] || "";
    const subject = headersMap["subject"] || "";

    // Regular expressions for domain parsing
    const extractDomain = (emailStr: string): string => {
      const match = emailStr.match(/@([a-zA-Z0-9.\-_]+)/);
      return match ? match[1].toLowerCase().replace(/[>]/g, "").trim() : "";
    };

    const fromDomain = extractDomain(fromVal);
    const returnPathDomain = extractDomain(returnPathVal);

    // Initial parsing findings
    const findings: any = {
      from: fromVal,
      fromDomain,
      returnPath: returnPathVal,
      returnPathDomain,
      replyTo: replyToVal,
      subject,
      messageId,
      hasDkimHeader: !!dkimSignatureVal,
      dkimHeader: dkimSignatureVal,
      receivedSpf: receivedSpfVal,
      spfStatus: "Unknown",
      dkimStatus: "Unknown",
      spfAligned: false,
      dkimAligned: false,
      riskLevel: "Suspicious",
      score: 50,
      reasons: [] as string[],
    };

    // Evaluate SPF status in headers
    if (receivedSpfVal) {
      const lowerSpf = receivedSpfVal.toLowerCase();
      if (lowerSpf.includes("pass")) {
        findings.spfStatus = "Pass";
      } else if (lowerSpf.includes("fail")) {
        findings.spfStatus = "Fail";
      } else if (lowerSpf.includes("softfail")) {
        findings.spfStatus = "Softfail";
      } else {
        findings.spfStatus = "Neutral/None";
      }
    }

    // Evaluate Alignment
    if (fromDomain && returnPathDomain && fromDomain === returnPathDomain) {
      findings.spfAligned = true;
      findings.reasons.push("SPF Alignment PASS: Envelope Sender (Return-Path) matches From domain.");
    } else if (fromDomain && returnPathDomain) {
      findings.spfAligned = false;
      findings.reasons.push("SPF Alignment FAIL: Envelope Sender domain does not match Header From domain.");
    }

    // Evaluate DKIM signature present
    if (dkimSignatureVal) {
      findings.dkimStatus = "Present (Unverified)";
      // Parse DKIM header for d= domain alignment
      const dMatch = dkimSignatureVal.match(/d=([a-zA-Z0-9.-]+)/);
      if (dMatch) {
         const dDomain = dMatch[1].toLowerCase().trim();
         if (dDomain === fromDomain) {
           findings.dkimAligned = true;
           findings.reasons.push(`DKIM Alignment PASS: Signature domain 'd=${dDomain}' aligns with From domain.`);
         } else {
           findings.dkimAligned = false;
           findings.reasons.push(`DKIM Alignment FAIL: Signature domain 'd=${dDomain}' does NOT align with From domain '${fromDomain}'.`);
         }
      }
    } else {
      findings.reasons.push("DKIM Header is missing. Cryptographic proof of origin not available.");
    }

    // Phishing / Spoof indicators
    if (fromDomain && returnPathDomain && fromDomain !== returnPathDomain) {
      findings.score += 25;
      findings.reasons.push("Spoof Alert: Return-Path has a different domain than From header. Common phishing tactic.");
    }

    if (replyToVal && extractDomain(replyToVal) !== fromDomain) {
      findings.score += 15;
      findings.reasons.push("Spoof Alert: Reply-To points to a completely different domain than the Sender From header.");
    }

    if (findings.spfStatus === "Fail") {
      findings.score += 20;
      findings.reasons.push("Envelope verification: SPF status is reported as FAILED in headers.");
    } else if (findings.spfStatus === "Pass") {
      findings.score -= 20;
    }

    if (findings.dkimAligned) {
      findings.score -= 15;
    } else {
      findings.score += 15;
    }

    // Final calculations
    findings.score = Math.max(0, Math.min(100, findings.score));
    if (findings.score < 30) {
      findings.riskLevel = "Safe";
    } else if (findings.score < 70) {
      findings.riskLevel = "Suspicious";
    } else {
      findings.riskLevel = "Spoofed";
    }

    // Save scan to history
    const history = readHistory();
    const newScan = {
      id: "scan_" + Date.now(),
      type: "header",
      target: fromVal || "Raw Header Scan",
      timestamp: new Date().toISOString(),
      score: findings.score,
      classification: findings.riskLevel,
      data: findings,
    };
    history.unshift(newScan);
    writeHistory(history.slice(0, 50));

    res.json({ success: true, findings, scanId: newScan.id });
  } catch (error: any) {
    console.error("Header analyzer API error:", error);
    res.status(500).json({ error: error.message || "An error occurred during header analysis." });
  }
});

// 3. AI Module: generate deep report and recommendations with Gemini
app.post("/api/gemini-explain", async (req, res) => {
  try {
    const { analysis, type } = req.body;
    if (!analysis) {
      return res.status(400).json({ error: "Analysis data is required for Gemini explanation." });
    }

    const ai = getGeminiClient();
    if (!ai) {
      // Graceful local expert fallback if key is missing
      let fallbackText = `### Cybersecurity Expert Analysis & Recommendations (Fallback Mode)

*Notice: GEMINI_API_KEY is not defined in the workspace secrets. Providing the expert-engineered rule-based cybersecurity recommendations engine.*

#### 1. Technical Assessment Summary
- **Target Component**: ${type === "header" ? analysis.from : analysis.domain} 
- **Spoofing Vulnerability Score**: ${analysis.score}/100 [Vulnerability classification: **${analysis.classification || analysis.riskLevel}**]
- **Alignment Summary**: ${type === "header" ? analysis.reasons?.join(" ") : analysis.alignment?.status}

#### 2. Risk Evaluation
- ${analysis.score > 70 
  ? "🔥 **CRITICAL THREAT**: This configuration leaves the sender domain entirely vulnerable to automated spoofing, brand abuse, and spear-phishing campaigns." 
  : analysis.score > 35 
  ? "⚠️ **MODERATE RISK**: Partial defenses are in place but weak validation allows sub-domain vulnerabilities or suspicious routing flags." 
  : "✅ **ROBUST POSTURE**: SPF, DKIM, and DMARC are properly configured with strict alignment, providing excellent cryptographic protection against spoofing attacks."}

#### 3. Immediate Cybersecurity Remediation Plan
1. **SPF Hardening**: Always mandate strict fail qualifiers (\`-all\`) instead of soft qualifiers(\`~all\`) if mailing ranges are static and cataloged.
2. **DMARC Progression**: If DMARC policy is currently \`p=none\`, implement a coordinated plan to transition to \`p=quarantine\` and eventually \`p=reject\` (100% block) to fully shut down impersonation.
3. **DKIM Cryptographic Auditing**: Routinely rotate DKIM keys (minimally every 6 months) with keys sized to 2048-bits. Use structured selectors to avoid exposure in leaked directories.
4. **Aggregate Telemetry XML Monitoring**: Consistently review aggregate XML data sent via the DMARC \`rua=\` mailboxes to analyze misaligned, failing mail agents.`;
      
      return res.json({ explanation: fallbackText });
    }

    // Design Prompt tailored to cybersecurity context
    let promptText = "";
    if (type === "header") {
      promptText = `You are a Senior Full-Stack Cybersecurity Engineer and academic research advisor.
Analyze the following email header analysis results and generate a rigorous security report.
Target Sender: ${analysis.from}
Return Path: ${analysis.returnPath}
SPF Status: ${analysis.spfStatus}
DKIM Status: ${analysis.dkimStatus}
SPF Aligned: ${analysis.spfAligned}
DKIM Aligned: ${analysis.dkimAligned}
Risk Score: ${analysis.score}/100
Classification: ${analysis.riskLevel}

Provide your expert response formatted as standard Markdown. It should have:
1. **Security Vulnerability Assessment**: Critically assess the threat level of this header and any alignment spoof indicators.
2. **Threat Classification and Machine Learning Insights**: Explain why a machine learning classifier model (like XGBoost or Random Forest) fed with these authentication features flags it as ${analysis.riskLevel}.
3. **Remediation Steps**: Concrete instructions for fixing any issues.`;
    } else {
      promptText = `You are a Senior Full-Stack Cybersecurity Engineer and academic research advisor.
Analyze the following DNS security analysis results for the domain: ${analysis.domain}
SPF Record: ${analysis.spf.raw} (Qualifier: ${analysis.spf.qualifier}, Status: ${analysis.spf.status})
DKIM Record: ${analysis.dkim.raw} (Status: ${analysis.dkim.status})
DMARC Record: ${analysis.dmarc.raw} (Policy: ${analysis.dmarc.policy}, Status: ${analysis.dmarc.status})
Alignment status: ${analysis.alignment.status}
Spoof Risk Vulnerability Score: ${analysis.score}/100
Classification: ${analysis.classification}

Provide your expert response formatted as standard Markdown. It should have:
1. **Deep Protocol Review**: Audit the SPF format, DKIM presence, and DMARC policies.
2. **Vulnerability Mechanics**: Explain how a malicious spammer could misuse these configurations to spoof the domain.
3. **Targeted Cybersecurity Recommendations**: Step-by-step instructions to harden the DNS TXT authentication profile.`;
    }

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: promptText,
    });

    const report = response.text || "No report generated.";
    res.json({ explanation: report });
  } catch (error: any) {
    console.error("Gemini explanation API error:", error);
    res.status(500).json({ error: error.message || "An error occurred during AI report compilation." });
  }
});

// 4. Retrieve Scan History Log
app.get("/api/history", (req, res) => {
  res.json({ success: true, history: readHistory() });
});

// 5. Delete individual scan history item
app.delete("/api/history/:id", (req, res) => {
  try {
    const { id } = req.params;
    let history = readHistory();
    history = history.filter((item) => item.id !== id);
    writeHistory(history);
    res.json({ success: true, history });
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

// 6. Bulk clear scan history
app.post("/api/history/clear", (req, res) => {
  try {
    writeHistory([]);
    res.json({ success: true, history: [] });
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});


// ----------------------------------------------------------------------
// Express Dev / Prod server routing
// ----------------------------------------------------------------------

async function startServer() {
  // Mount Vite middleware in development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    // Serve static files in production
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
